#pragma once
#include "interface.capnp.h"
#include "../classes/datamodel/rulemodel.hpp"
#include "../classes/datamodel/eventlogs/eventlog.hpp"
#include "../classes/preprocessing/distributionestimator.hpp"

/// @brief Provides Cap'n Proto services to the clients
class ServerImplementation final : public serial::ProcessDataUpdates::Server
{
    private:
    /// @brief Completely initializes a distribution estimator with the selected histogram
    /// estimation method and histograms initialized from the event log
    /// @param log event log used to initialize histograms from
    /// @param discretizationModeReader whether to use NML- or quantile-based histograms
    /// @return a fully initialized distribution estimator
    std::shared_ptr<DistributionEstimator> initializeDistributionEstimator(
        const EventLog* const log, const serial::DiscretizationMode::Reader& discretizationModeReader);

    /// @brief Throws an exception if the model is cyclic, except for when cyclicity is ignored
    /// @param model model to check for a cycle
    /// @param ignoreCyclic whether to ignore a cyclic model
    void ensureAcyclicity(const RuleModel* const model, bool ignoreCyclic = false);

    /// @brief Determines how many samples the rule predicts in the event log, i.e. how many times
    /// its condition matches
    /// @param log event log to check conditions in
    /// @param rule modification rule with the condition to check
    /// @return number of samples/events that the rule predicts
    int64_t countCoveredSamples(const EventLog* const log, const ModificationRule* const rule);

    public:
    /// @brief Calculates the total MDL encoding length of the given data (event log) and model
    /// @param context input/output object of the RPC call
    /// @return promise for the remote call
    virtual ::kj::Promise<void> calculateMdlScore(CalculateMdlScoreContext context);

    /// @brief (Randomly) generates an event log using the given model and lengths
    /// @param context input/output object of the RPC call
    /// @return promise for the remote call
    virtual ::kj::Promise<void> generateEventLog(GenerateEventLogContext context);

    virtual ::kj::Promise<void> findModel(FindModelContext context);

    virtual ::kj::Promise<void> modelToString(ModelToStringContext context);
    virtual ::kj::Promise<void> encodeRealNumber(EncodeRealNumberContext context);
    virtual ::kj::Promise<void> isModelCyclic(IsModelCyclicContext context);
    virtual ::kj::Promise<void> predictEventLog(PredictEventLogContext context);
    virtual ::kj::Promise<void> predictValueSets(PredictValueSetsContext context);
    virtual ::kj::Promise<void> estimateBitsSaved(EstimateBitsSavedContext context);
    virtual ::kj::Promise<void> predictRealEventLog(PredictRealEventLogContext context);
    virtual ::kj::Promise<void> getPredictingPositions(GetPredictingPositionsContext context);
};
