#include "serverimplementation.hpp"
#include "../classes/serialobjectconverter.hpp"
#include "../classes/scoring/modelencoder.hpp"
#include "../classes/scoring/dataencoder.hpp"
#include "../classes/scoring/dataencodingestimator.hpp"
#include "../classes/preprocessing/cycledetector.hpp"
#include "../classes/datagenerator.hpp"
#include "../classes/search/modelfinder.hpp"
#include "../classes/search/forwardrulegenerator.hpp"
#include "../classes/search/backwardrulegenerator.hpp"
#include "../classes/preprocessing/accuracyestimator.hpp"
#include "../classes/preprocessing/nmlhistogramwrapper.hpp"
#include "../classes/preprocessing/quantilehistogramestimator.hpp"
#include "../classes/applicabilityfinder.hpp"
#include <stdexcept>

std::shared_ptr<DistributionEstimator> ServerImplementation::initializeDistributionEstimator(
    const EventLog *const log, const serial::DiscretizationMode::Reader &discretizationModeReader)
{
    // initialize histogram estimation according to discretization configuration
    std::unique_ptr<HistogramEstimator> histogramEstimator;
    if (discretizationModeReader.isNml())
    {
        histogramEstimator = std::make_unique<NmlHistogramWrapper>();
    }
    else if (discretizationModeReader.isQuantiles())
    {
        histogramEstimator = std::make_unique<QuantileHistogramEstimator>();
    }
    else
    {
        throw std::invalid_argument("Discretization mode not supported");
    }

    // initialize distribution estimator
    auto columnCollector = std::make_unique<ColumnCollector>();
    auto distributionEstimator = std::make_shared<DistributionEstimator>(
        histogramEstimator, columnCollector, false);
    distributionEstimator->calculateGlobalDistributions(log);

    return distributionEstimator;
}

void ServerImplementation::ensureAcyclicity(const RuleModel *const model, bool ignoreCyclic)
{
    CycleDetector detector;
    if (detector.hasCycle(model) && !ignoreCyclic)
    {
        throw std::invalid_argument("Model has a cycle");
    }
}

int64_t ServerImplementation::countCoveredSamples(const EventLog *const log, const ModificationRule *const rule)
{
    ColumnCollector collector;
    if (dynamic_cast<const ValueSetRule*>(rule->getUpdateRule()) != nullptr)
    {
        auto allSamples = collector.collectValuesForModificationRule<std::string>(
            log, rule->getCondition(), rule->getUpdateRule());
        return allSamples.size();
    }
    else
    {
        auto allSamples = collector.collectValuesForModificationRule<double_t>(
            log, rule->getCondition(), rule->getUpdateRule());
        return allSamples.size();
    }
}

::kj::Promise<void> ServerImplementation::calculateMdlScore(CalculateMdlScoreContext context)
{
    try 
    {
        // get inputs as readers
        auto paramReader = context.getParams();
        auto logReader = paramReader.getLog();
        auto modelReader = paramReader.getModel();
        auto discretizationModeReader = paramReader.getDiscretizationMode();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        std::unique_ptr<EventLog> log = converter.eventLogFromSerial(logReader);
        std::unique_ptr<RuleModel> model = converter.ruleModelFromSerial(modelReader);

        // calculate accuracies of numerical variables
        AccuracyEstimator accuracyEstimator;
        accuracyEstimator.initializeAllAccuracies(log.get());

        // ensure acyclicity of model
        this->ensureAcyclicity(model.get());

        // initialize classes for calculation
        auto mdlCalculator = std::make_shared<MdlCalculator>();
        auto distributionEstimator = this->initializeDistributionEstimator(log.get(),
            discretizationModeReader);
        ModelEncoder modelEncoder(mdlCalculator, log->getVariables().size());
        DataEncoder dataEncoder(mdlCalculator, distributionEstimator);

        // calculate code lengths
        const double_t modelLength = modelEncoder.encodeRuleModel(model.get());
        const double_t dataLength = dataEncoder.encodeEventLog(log.get(), model.get());

        // send result to caller
        auto resultBuilder = context.getResults();
        resultBuilder.setResult(modelLength + dataLength);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::generateEventLog(GenerateEventLogContext context)
{
    try 
    {
        // get inputs
        auto paramReader = context.getParams();
        auto modelReader = paramReader.getModel();
        auto variablesReader = modelReader.getVariables();
        const int64_t numberOfTraces = paramReader.getNumberOfTraces();
        const int64_t traceLength = paramReader.getTraceLength();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        auto variables = converter.variablesFromSerial(variablesReader);
        std::unique_ptr<RuleModel> model = converter.ruleModelFromSerial(modelReader);

        // generate event log
        DataGenerator generator;
        auto logUsages = generator.generateEventLog(
            variables, model.get(), numberOfTraces, traceLength);

        // send result to caller
        auto resultBuilder = context.getResults();
        auto logBuilder = resultBuilder.initLog();
        auto usagesBuilder = resultBuilder.initRuleUsage(logUsages.second.size());
        converter.eventLogToSerial(logUsages.first.get(), logBuilder);
        converter.usageStatisticsToSerial(logUsages.second, usagesBuilder);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::findModel(FindModelContext context)
{
    try 
    {
        // get inputs
        auto paramReader = context.getParams();
        auto logReader = paramReader.getLog();
        auto searchModeReader = paramReader.getSearchMode();
        auto discretizationModeReader = paramReader.getDiscretizationMode();
        auto targetVariablesReader = paramReader.getTargetVariables();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        std::unique_ptr<EventLog> log = converter.eventLogFromSerial(logReader);
        auto targetVariables = converter.variableReferencesFromSerial(targetVariablesReader);

        // calculate accuracies of numerical variables
        AccuracyEstimator accuracyEstimator;
        accuracyEstimator.initializeAllAccuracies(log.get());

        // initialize distribution estimator
        auto distributionEstimator = this->initializeDistributionEstimator(log.get(),
            discretizationModeReader);

        // initialize rule generator accoring to search mode configuration
        std::unique_ptr<RuleGenerator> ruleGenerator;
        if (searchModeReader.isConditionFirst())
        {
            auto condition = std::make_unique<Condition>();
            ruleGenerator = std::make_unique<ForwardRuleGenerator>(
                distributionEstimator, log.get(), condition.get(), paramReader.getConditionCount());
        }
        else if (searchModeReader.isUpdateRuleFirst())
        {
            ruleGenerator = std::make_unique<BackwardRuleGenerator>(distributionEstimator);
        }

        // find model
        ModelFinder finder;
        std::unique_ptr<RuleModel> model = finder.findRuleModel(
            log.get(), ruleGenerator.get(), paramReader.getMaxLength(), targetVariables);

        // send result to caller
        auto resultBuilder = context.getResults();
        auto modelBuilder = resultBuilder.initModel();
        converter.ruleModelToSerial(model.get(), modelBuilder);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::modelToString(ModelToStringContext context)
{
    try 
    {
        // get inputs as readers
        auto paramReader = context.getParams();
        auto modelReader = paramReader.getModel();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        std::unique_ptr<RuleModel> model = converter.ruleModelFromSerial(modelReader);

        // convert rule model to string
        std::string result = model->toString();

        // send result to caller
        auto resultBuilder = context.initResults();
        resultBuilder.setString(result);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::encodeRealNumber(EncodeRealNumberContext context)
{
    try 
    {
        // get inputs
        auto paramReader = context.getParams();
        double_t realNumber = paramReader.getRealNumber();
        int64_t precision = paramReader.getPrecision();

        // compute code length
        MdlCalculator calc;
        double_t codeLength = calc.codeReal(realNumber, precision);

        // send result to caller
        auto resultBuilder = context.initResults();
        resultBuilder.setCodeLength(codeLength);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::isModelCyclic(IsModelCyclicContext context)
{
    try 
    {
        // get inputs as readers
        auto paramReader = context.getParams();
        auto modelReader = paramReader.getModel();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        std::unique_ptr<RuleModel> model = converter.ruleModelFromSerial(modelReader);

        // determine cyclicity of model
        CycleDetector detector;
        bool cyclic = detector.hasCycle(model.get());
        
        // send result to caller
        auto resultBuilder = context.initResults();
        resultBuilder.setCyclic(cyclic);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::predictEventLog(PredictEventLogContext context)
{
    try 
    {
        // get inputs as readers
        auto paramReader = context.getParams();
        auto sourceLogReader = paramReader.getSourceLog();
        auto modelReader = paramReader.getModel();
        bool predictMeans = paramReader.getPredictMeans();
        bool modelIsOrderedList = paramReader.getModelIsOrderedList();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        std::unique_ptr<EventLog> sourceLog = converter.eventLogFromSerial(sourceLogReader);
        std::unique_ptr<RuleModel> model = converter.ruleModelFromSerial(modelReader);

        // calculate accuracies of numerical variables
        AccuracyEstimator accuracyEstimator;
        accuracyEstimator.initializeAllAccuracies(sourceLog.get());

        // ensure acyclicity of model
        this->ensureAcyclicity(model.get(), modelIsOrderedList);

        // generate predictions event log
        DataGenerator generator;
        auto resultLog = generator.predictEventLog(
            sourceLog.get(), model.get(), predictMeans, modelIsOrderedList);
        
        // send result to caller
        auto resultBuilder = context.getResults();
        auto logBuilder = resultBuilder.initLog();
        converter.eventLogToSerial(resultLog.get(), logBuilder);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::predictValueSets(PredictValueSetsContext context)
{
    try 
    {
        // get inputs as readers
        auto paramReader = context.getParams();
        auto sourceLogReader = paramReader.getSourceLog();
        auto modelReader = paramReader.getModel();
        bool modelIsOrderedList = paramReader.getModelIsOrderedList();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        std::unique_ptr<EventLog> sourceLog = converter.eventLogFromSerial(sourceLogReader);
        std::unique_ptr<RuleModel> model = converter.ruleModelFromSerial(modelReader);

        // calculate accuracies of numerical variables
        AccuracyEstimator accuracyEstimator;
        accuracyEstimator.initializeAllAccuracies(sourceLog.get());

        // ensure acyclicity of model
        this->ensureAcyclicity(model.get(), modelIsOrderedList);

        // generate value set predictions
        DataGenerator generator;
        auto setPredictions = generator.predictValueSets(
            sourceLog.get(), model.get(), modelIsOrderedList);
        
        // send result to caller
        auto resultBuilder = context.getResults();
        auto setPredictionsBuilder = resultBuilder.initSetPredictions(setPredictions.size());
        converter.setPredictionsToSerial(setPredictions, setPredictionsBuilder);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::estimateBitsSaved(EstimateBitsSavedContext context)
{
    try 
    {
        // get inputs as readers
        auto paramReader = context.getParams();
        auto logReader = paramReader.getLog();
        auto modelReader = paramReader.getModel();
        auto ruleReader = paramReader.getNewRule();
        auto discretizationModeReader = paramReader.getDiscretizationMode();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        std::unique_ptr<EventLog> log = converter.eventLogFromSerial(logReader);
        std::unique_ptr<RuleModel> model = converter.ruleModelFromSerial(modelReader);
        std::unique_ptr<ModificationRule> rule = converter.modificationRuleFromSerial(ruleReader);

        // calculate accuracies of numerical variables
        AccuracyEstimator accuracyEstimator;
        accuracyEstimator.initializeAllAccuracies(log.get());

        // ensure acyclicity of model
        this->ensureAcyclicity(model.get());

        // initialize classes for calculation
        auto mdlCalculator = std::make_shared<MdlCalculator>();
        auto distributionEstimator = this->initializeDistributionEstimator(log.get(),
            discretizationModeReader);
        ModelEncoder modelEncoder(mdlCalculator, log->getVariables().size());
        DataEncoder dataEncoder(mdlCalculator, distributionEstimator);
        DataEncodingEstimator encodingEstimator(mdlCalculator, distributionEstimator);

        // compute samples covered by rule
        int64_t samplesCovered = this->countCoveredSamples(log.get(), rule.get());
        
        // compute estimate
        double_t estimatedBitsSaved =
            encodingEstimator.estimateSavedBits(rule->getUpdateRule(), samplesCovered) -
            modelEncoder.encodeAdditionalModificationRule(model.get(), rule.get());

        // send result to caller
        auto resultBuilder = context.getResults();
        resultBuilder.setResult(estimatedBitsSaved);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::predictRealEventLog(PredictRealEventLogContext context)
{
    try 
    {
        // get inputs as readers
        auto paramReader = context.getParams();
        auto trainingLogReader = paramReader.getTrainingLog();
        auto testLogReader = paramReader.getTestLog();
        auto modelReader = paramReader.getModel();
        bool predictMeans = paramReader.getPredictMeans();
        bool modelIsOrderedList = paramReader.getModelIsOrderedList();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        std::unique_ptr<EventLog> trainingLog = converter.eventLogFromSerial(trainingLogReader);
        std::unique_ptr<EventLog> testLog = converter.eventLogFromSerial(testLogReader);
        std::unique_ptr<RuleModel> model = converter.ruleModelFromSerial(modelReader);

        // calculate accuracies of numerical variables
        AccuracyEstimator accuracyEstimator;
        accuracyEstimator.initializeAllAccuracies(trainingLog.get());

        // ensure acyclicity of model
        this->ensureAcyclicity(model.get(), modelIsOrderedList);

        // get distributions from training log
        ::capnp::MallocMessageBuilder message;
        serial::DiscretizationMode::Builder discretizationMode =
            message.initRoot<serial::DiscretizationMode>();
        discretizationMode.setQuantiles();
        auto distributionEstimator = this->initializeDistributionEstimator(
            trainingLog.get(), discretizationMode.asReader());

        // generate predictions event log
        DataGenerator generator;
        auto resultLog = generator.predictEventLog(
            testLog.get(), model.get(), predictMeans, modelIsOrderedList, distributionEstimator);
        
        // send result to caller
        auto resultBuilder = context.getResults();
        auto logBuilder = resultBuilder.initLog();
        converter.eventLogToSerial(resultLog.get(), logBuilder);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}

::kj::Promise<void> ServerImplementation::getPredictingPositions(GetPredictingPositionsContext context)
{
    try 
    {
        // get inputs as readers
        auto paramReader = context.getParams();
        auto eventLogReader = paramReader.getEventLog();
        auto modelReader = paramReader.getModel();

        // convert input to internal datamodel
        SerialObjectConverter converter;
        std::unique_ptr<EventLog> eventLog = converter.eventLogFromSerial(eventLogReader);
        std::unique_ptr<RuleModel> model = converter.ruleModelFromSerial(modelReader);

        // calculate accuracies of numerical variables
        AccuracyEstimator accuracyEstimator;
        accuracyEstimator.initializeAllAccuracies(eventLog.get());

        // ensure acyclicity of model
        this->ensureAcyclicity(model.get());

        // find predicting positions
        ApplicabilityFinder finder;
        auto positions = finder.findEventsWithApplicableRules(eventLog.get(), model.get());
        
        // send result to caller
        auto resultBuilder = context.getResults();
        auto positionsBuilder = resultBuilder.initPositions(positions.size());
        converter.eventLogPositionsToSerial(positions, positionsBuilder);

        return kj::READY_NOW;
    }
    catch (std::exception& ex)
    {
        KJ_ASSERT(false, ex.what());
    }
    return kj::NEVER_DONE;
}
