#ifndef A_HPP
#define A_HPP

namespace A {

void A();

}

#endif
