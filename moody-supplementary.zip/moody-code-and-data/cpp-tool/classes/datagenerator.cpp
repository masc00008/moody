#include "datagenerator.hpp"
#include <stdexcept>
#include "datamodel/updaterules/valuerule.hpp"
#include "datamodel/updaterules/factorrule.hpp"
#include "datamodel/updaterules/differencerule.hpp"
#include "datamodel/updaterules/valuerangerule.hpp"
#include "datamodel/updaterules/changerangerule.hpp"
#include "datamodel/eventlogs/logcolumn.hpp"
#include "preprocessing/cycledetector.hpp"
#include "utils.hpp"
#include "scoring/rulefinder.hpp"
#include <algorithm>
#include <iostream>

DataGenerator::DataGenerator(const double_t minNumerical,
                             const double_t maxNumerical, const double_t accuracy)
    : minNumerical(minNumerical), maxNumerical(maxNumerical), globalAccuracy(accuracy)
{
}

DataGenerator::DataGenerator(const int64_t seed, const double_t minNumerical,
        const double_t maxNumerical, const double_t accuracy)
    : randomEngine(seed), minNumerical(minNumerical), maxNumerical(maxNumerical),
    globalAccuracy(accuracy)
{
}

void DataGenerator::initializeSamplingDistributions(
    const std::shared_ptr<DistributionEstimator> distributionEstimator,
    const std::vector<std::shared_ptr<LogVariable>>& variables)
{
    for (const auto& variable : variables)
    {
        auto catVariable = std::dynamic_pointer_cast<CategoricalVariable>(variable);
        if (catVariable != nullptr)
        {
            auto distribution = distributionEstimator->getCategoricalDistribution(catVariable);
            // convert map into vector of category frequencies
            std::vector<int64_t> frequencies(distribution.size());
            auto it = distribution.begin();
            for (size_t i = 0; i < frequencies.size(); i++)
            {
                frequencies[i] = it->second;
                ++it;
            }
            // create distribution
            this->samplingDistributions[variable] = std::discrete_distribution<int64_t>(
                frequencies.begin(), frequencies.end());
        }

        auto numVariable = std::dynamic_pointer_cast<NumericalVariable>(variable);
        if (numVariable != nullptr)
        {
            auto distribution = distributionEstimator->getNumericalDistribution(numVariable);
            const double_t accuracy = numVariable->getAccuracy();
            const double_t minValueAdjusted = Utils::round(
                distribution.getRange().first + accuracy / 2, accuracy);
            const double_t maxValue = distribution.getRange().second;
            // compute probabilities for all possible values
            double_t currentValue = minValueAdjusted;
            std::vector<double_t> probabilities;
            while (currentValue < maxValue)
            {
                probabilities.push_back(distribution.getProbability(currentValue, accuracy));
                currentValue += accuracy;
            }
            // create distribution and save min value
            this->samplingDistributions[variable] = std::discrete_distribution<int64_t>(
                probabilities.begin(), probabilities.end());
            this->minValues[numVariable] = minValueAdjusted;
        }
    }
}

double_t DataGenerator::generateValue(
    const Trace* const trace, const size_t index, const UpdateRule* const rule,
    const bool predictMeans)
{
    double_t result;

    // find type of update rule
    const auto valueRule = dynamic_cast<const ValueRule*>(rule);
    const auto factorRule = dynamic_cast<const FactorRule*>(rule);
    const auto differenceRule = dynamic_cast<const DifferenceRule*>(rule);
    const auto valueRangeRule = dynamic_cast<const ValueRangeRule*>(rule);
    const auto changeRangeRule = dynamic_cast<const ChangeRangeRule*>(rule);

    if (valueRule != nullptr)
    {
        result = valueRule->getConstant();
    }
    else if (valueRangeRule != nullptr && predictMeans)
    {
        result = (valueRangeRule->getMax() + valueRangeRule->getMin()) / 2.0;
    }
    else if (valueRangeRule != nullptr && !predictMeans)
    {
        std::uniform_real_distribution distribution(
            valueRangeRule->getMin(), valueRangeRule->getMax());
        result = distribution(this->randomEngine);
    }
    else if (factorRule != nullptr || differenceRule != nullptr || changeRangeRule != nullptr)
    {
        // ensure correct index for rules that depend on a previous value
        if (index == 0)
        {
            throw std::invalid_argument("Update rule depends on previous value but 0 index given");
        }

        // get previous value
        double_t previousValue = Utils::retrieveValue<double_t>(
            rule->getVariable(), trace, index - 1);

        if (factorRule != nullptr)
        {
            result = previousValue * factorRule->getConstant();
        }
        else if (differenceRule != nullptr)
        {
            result = previousValue + differenceRule->getConstant();
        }
        else if (changeRangeRule != nullptr && predictMeans)
        {
            result = previousValue + (changeRangeRule->getMax() + changeRangeRule->getMin()) / 2.0;
        }
        else if (changeRangeRule != nullptr && !predictMeans)
        {
            std::uniform_real_distribution distribution(
                changeRangeRule->getMin(), changeRangeRule->getMax());
            result = previousValue + distribution(this->randomEngine);
        }
    }
    else
    {
        throw std::invalid_argument("No numerical update rule was given");
    }

    // round value to desired accuracy
    return Utils::round(result, this->globalAccuracy);
}

double_t DataGenerator::generateValue(const std::shared_ptr<NumericalVariable>& variable,
        const bool predictMeans)
{
    const double_t accuracy = variable->getAccuracy();
    double_t result;
    if (this->samplingDistributions.find(variable) == this->samplingDistributions.end())
    {
        if (predictMeans)
        {
            result = (this->maxNumerical + this->minNumerical) / 2.0;
        }
        else
        {
            std::uniform_real_distribution distribution(this->minNumerical, this->maxNumerical);
            result = distribution(this->randomEngine);
        }
    }
    else
    {
        auto& distribution = this->samplingDistributions.at(variable);
        const double_t minValue = this->minValues.at(variable);

        const int64_t valueIndex = distribution(this->randomEngine);
        result = minValue + valueIndex * accuracy;
    }
    
    return Utils::round(result, accuracy);
}

std::string DataGenerator::generateValue(const std::shared_ptr<CategoricalVariable>& variable)
{
    const auto& domain = variable->getDomain();
    if (this->samplingDistributions.find(variable) == this->samplingDistributions.end())
    {
        return this->generateValue(domain);
    }
    else
    {
        auto& distribution = this->samplingDistributions.at(variable);
        const int64_t valueIndex = distribution(this->randomEngine);
        return *std::next(domain.begin(), valueIndex);
    }
}

std::string DataGenerator::generateValue(const std::set<std::string> &domain)
{
    std::uniform_int_distribution<int64_t> distribution(0, domain.size() - 1);
    const int64_t valueIndex = distribution(this->randomEngine);
    return *std::next(domain.begin(), valueIndex);
}

DataGenerator::ReverseRuleGraphType DataGenerator::computeRuleGraph(
    const std::vector<std::shared_ptr<LogVariable>> &variables, const RuleModel *const model)
{
    ReverseRuleGraphType ruleGraph;
    // add all variables as nodes (keys)
    for (const auto& variable : variables)
    {
        ruleGraph[variable] = std::vector<const ModificationRule*>();
    }

    // add all rule dependencies
    for (const auto& rule : model->getRules())
    {
        ruleGraph[rule->getUpdateRule()->getVariable()].push_back(rule);
    }

    return ruleGraph;
}

template<typename T> void DataGenerator::appendValueToTrace(
    const Trace *const trace, const std::shared_ptr<LogVariable> variable, const T value)
{
    // get desired type of column and throw an exception for a mismatch
    auto column = dynamic_cast<LogColumn<T>*>(trace->getColumns().at(variable).get());
    if (column == nullptr)
    {
        throw std::invalid_argument("Variable and column type mismatch");
    }
    // append the value
    column->appendEntry(value);
}

template void DataGenerator::appendValueToTrace<double_t>(
    const Trace *const trace, const std::shared_ptr<LogVariable> variable, const double_t value);
template void DataGenerator::appendValueToTrace<std::string>(
    const Trace *const trace, const std::shared_ptr<LogVariable> variable, const std::string value);

void DataGenerator::generateSingleEvent(const ReverseRuleGraphType& ruleGraph,
        const Trace* const trace,
        UsageStatistics& statistics)
{
    // always generate the event at the end of the trace
    const size_t index = trace->size();

    // put variables without dependencies to the frontier
    std::set<std::shared_ptr<LogVariable>> variablesFrontier;
    for (const auto& variableRulesPair : ruleGraph)
    {
        // search for actual dependencies of the update rule
        bool noDependencies = true;
        for (const auto& rule : variableRulesPair.second)
        {
            if (rule->getCondition()->getElements().size() > 0)
            {
                // dependency found, exit loop
                noDependencies = false;
                break;
            }
        }
        if (noDependencies)
        {
            variablesFrontier.insert(variableRulesPair.first);
        }
    }
    // no variable is set in the beginning
    std::set<std::shared_ptr<LogVariable>> setVariables;

    // generate values as long as variables are in the frontier (todo list)
    while (variablesFrontier.size() > 0)
    {
        // remove the variable from the frontier
        auto variable = *variablesFrontier.begin();
        variablesFrontier.erase(variable);
        
        // generate and set value for variable
        this->generateValueInTrace(
            ruleGraph, trace, trace, index, variable, setVariables, statistics);

        // add variables to the frontier that can be generated with the newly set variable
        const auto newVarialbes = this->findNewlyEnabledVariables(
            ruleGraph, setVariables, variable);
        variablesFrontier.insert(newVarialbes.begin(), newVarialbes.end());
        // add newly set variable to the set variables
        setVariables.insert(variable);
    }
}

void DataGenerator::generateValueInTrace(const ReverseRuleGraphType &ruleGraph,
    const Trace *const conditionTrace, const Trace *const targetTrace, size_t index,
    const std::shared_ptr<LogVariable> targetVariable,
    const std::set<std::shared_ptr<LogVariable>>& setVariables, UsageStatistics &statistics,
    const bool predictMeans, const bool modelIsOrderedList,
    const std::shared_ptr<DistributionEstimator> distributionEstimator)
{
    // find rules that apply for generating the variable's value
    auto activeRules = this->findActiveGenerationRules(
        ruleGraph, conditionTrace, index, targetVariable, setVariables);
    
    // no rules apply, generate value using its global domain or distribution
    if (activeRules.size() == 0)
    {
        auto catVariable = std::dynamic_pointer_cast<CategoricalVariable>(targetVariable);
        if (catVariable != nullptr)
        {
            std::string value = this->generateValue(catVariable);
            this->appendValueToTrace(targetTrace, catVariable, value);
        }

        auto numVariable = std::dynamic_pointer_cast<NumericalVariable>(targetVariable);
        if (numVariable != nullptr)
        {
            double_t value = this->generateValue(numVariable, predictMeans);
            this->appendValueToTrace(targetTrace, numVariable, value);
        }
    }
    // at least one rule applies, use it/them to generate data
    else
    {
        // choose rule (first one for ordered lists)
        int64_t selectedRuleIndex = 0;
        if (!modelIsOrderedList)
        {
            // pick random rule for unordered set
            std::uniform_int_distribution<int64_t> distribution(0, activeRules.size() - 1);
            selectedRuleIndex = distribution(this->randomEngine);
        }
        // count usage of the modification rule
        statistics[activeRules[selectedRuleIndex]]++;
        // generate data in trace
        auto updateRule = activeRules[selectedRuleIndex]->getUpdateRule();
        auto valueSetRule = dynamic_cast<const ValueSetRule*>(updateRule);
        if (valueSetRule != nullptr)
        {
            this->appendValueToTrace(targetTrace, updateRule->getVariable(),
                this->generateValue(valueSetRule->getSet()));
        }
        else if (predictMeans)
        {
            std::vector<const ModificationRule *> overlappingRules;
            if (modelIsOrderedList)
            {
                // no overlap for ordered list of rules
                overlappingRules = {activeRules[selectedRuleIndex]};
            }
            else
            {
                // rules only overlap if our model is a set of rules
                overlappingRules = activeRules;
            }

            // average over all numerical rule's predictions if we do not want random samples
            double_t sumPredictions = 0.0;
            for (const auto& rule : overlappingRules)
            {
                sumPredictions += this->generateValue(
                    conditionTrace, index, rule->getUpdateRule(), predictMeans);
            }
            this->appendValueToTrace(targetTrace, updateRule->getVariable(),
                sumPredictions / overlappingRules.size());
        }
        else
        {
            this->appendValueToTrace(targetTrace, updateRule->getVariable(),
                this->generateValue(conditionTrace, index, updateRule, predictMeans));
        }
    }
}

std::set<std::string> DataGenerator::generateValueSet(const ReverseRuleGraphType& ruleGraph,
        const Trace* const conditionTrace, size_t index,
        const std::shared_ptr<CategoricalVariable> targetVariable,
        const std::set<std::shared_ptr<LogVariable>>& setVariables,
        const bool modelIsOrderedList)
{
    // find rules that apply for generating the variable's value
    auto activeRules = this->findActiveGenerationRules(
        ruleGraph, conditionTrace, index, targetVariable, setVariables);
    
    // no rules apply, return global domain
    if (activeRules.size() == 0)
    {
        return targetVariable->getDomain();
    }
    // at least one rule applies, return union of all overlapping rules
    else
    {
        std::set<std::string> result;
        for (const auto& rule : activeRules)
        {
            auto valueSetRule = static_cast<const ValueSetRule*>(rule->getUpdateRule());
            result.insert(valueSetRule->getSet().begin(), valueSetRule->getSet().end());
            // if we have an ordered list of rules, only consider the prediction of the first one
            if (modelIsOrderedList)
            {
                break;
            }
        }
        return result;
    }
}

std::vector<std::shared_ptr<LogVariable>> DataGenerator::findNewlyEnabledVariables(
    const ReverseRuleGraphType& ruleGraph,
    const std::set<std::shared_ptr<LogVariable>> &previouslySetVariables,
    const std::shared_ptr<LogVariable> &newlySetVariable)
{
    std::vector<std::shared_ptr<LogVariable>> enabledVariables;

    // search through all modification rules (i.e. edges in the variable graph)
    for (const auto& variableRulesPair : ruleGraph)
    {
        // collect the variables of all conditions
        std::set<std::shared_ptr<LogVariable>> conditionVariables;
        for (const auto& rule : variableRulesPair.second)
        {
            const auto variables = rule->getCondition()->getVariables();
            conditionVariables.insert(variables.begin(), variables.end());
        }

        // find variables that prior to the newly set variable were missing in the condition of the
        // update rule
        std::vector<std::shared_ptr<LogVariable>> previouslyMissingVariables;
        std::set_difference(conditionVariables.begin(), conditionVariables.end(),
            previouslySetVariables.begin(), previouslySetVariables.end(),
            std::back_inserter(previouslyMissingVariables));
        
        // determine variables that are set after setting the new variable
        std::set<std::shared_ptr<LogVariable>> currentlySetVariables(previouslySetVariables);
        currentlySetVariables.insert(newlySetVariable);

        // find variables that after setting the new variable are still missing in the condition of
        // the update rule
        std::vector<std::shared_ptr<LogVariable>> currentlyMissingVariables;
        std::set_difference(conditionVariables.begin(), conditionVariables.end(),
            currentlySetVariables.begin(), currentlySetVariables.end(),
            std::back_inserter(currentlyMissingVariables));

        // only add a variable to the result if previously just one variable was missing in the
        // condition but no variables are missing currently
        if (previouslyMissingVariables.size() == 1 && currentlyMissingVariables.size() == 0)
        {
            enabledVariables.push_back(variableRulesPair.first);
        }
    }

    return enabledVariables;
}

std::vector<const ModificationRule *> DataGenerator::findActiveGenerationRules(
    const ReverseRuleGraphType& ruleGraph, const Trace *const trace, size_t index,
    const std::shared_ptr<LogVariable> targetVariable,
    const std::set<std::shared_ptr<LogVariable>> &setVariables)
{
    std::vector<const ModificationRule*> result;
    RuleFinder finder;

    // search through all modification rules
    for (const auto& rule : ruleGraph.at(targetVariable))
    {
        // find variables in the condition of the rule that are currently not set
        const auto conditionVariables = rule->getCondition()->getVariables();
        std::vector<std::shared_ptr<LogVariable>> currentlyMissingVariables;
        std::set_difference(conditionVariables.begin(), conditionVariables.end(),
            setVariables.begin(), setVariables.end(),
            std::back_inserter(currentlyMissingVariables));
        
        // only add a rule if all its condition variables are set and it applies
        if (currentlyMissingVariables.size() == 0 &&
            finder.checkRuleApplies(rule, targetVariable.get(), trace, index))
        {
            result.push_back(rule);
        }
    }

    return result;
}

DataGenerator::EventLogUsageStatistics DataGenerator::generateEventLog(
    const std::vector<std::shared_ptr<LogVariable>>& variables,
    const RuleModel* const model, const int64_t numberOfTraces, const int64_t traceLength)
{
    // check input parameters
    Utils::checkNull(model);
    if (numberOfTraces < 1)
    {
        throw std::invalid_argument("numberOfTraces has to be at least 1");
    }
    if (traceLength < 1)
    {
        throw std::invalid_argument("traceLength has to be at least 1");
    }

    // ensure acyclicity of model
    CycleDetector detector;
    if (detector.hasCycle(model))
    {
        throw std::invalid_argument("Rule model has a cycle");
    }

    // set the accuracies of all numerical variables
    for (auto& var : variables)
    {
        const auto numVariable = std::dynamic_pointer_cast<NumericalVariable>(var);
        if (numVariable != nullptr)
        {
            numVariable->setAccuracy(this->globalAccuracy);
        }
    }

    UsageStatistics statistics;

    // find graph structure of which variables depend on which modification rules
    const auto ruleGraph = this->computeRuleGraph(variables, model);

    EventLog::TracesType traces;
    // create desired number of traces
    for (int64_t i = 0; i < numberOfTraces; i++)
    {
        // create empty trace
        traces[std::to_string(i)] = std::make_unique<Trace>(variables);
        // create desired numer of events per trace
        for (int64_t j = 0; j < traceLength; j++)
        {
            // fill trace with an event
            this->generateSingleEvent(
                ruleGraph, traces[std::to_string(i)].get(), statistics);
        }
    }

    return std::make_pair(std::make_unique<EventLog>(traces), statistics);
}

void DataGenerator::seed(const int64_t seed)
{
    this->randomEngine.seed(seed);
}

std::unique_ptr<EventLog> DataGenerator::predictEventLog(
    const EventLog *const sourceLog, const RuleModel *const model,
    const bool predictMeans, const bool modelIsOrderedList,
    const std::shared_ptr<DistributionEstimator> distributionEstimator)
{
    Utils::checkNull(sourceLog);
    Utils::checkNull(model);

    // ensure acyclicity of model (if it is an unordered set of rules)
    CycleDetector detector;
    if (detector.hasCycle(model) && !modelIsOrderedList)
    {
        throw std::invalid_argument("Rule model has a cycle");
    }

    auto variables = sourceLog->getVariables();
    UsageStatistics statistics;
    // find graph structure of which variables depend on which modification rules
    const auto ruleGraph = this->computeRuleGraph(variables, model);
    // all variables in the source event log are already set
    std::set<std::shared_ptr<LogVariable>> setVariables (variables.begin(), variables.end());

    // initialize distributions if necessary
    if (distributionEstimator != nullptr)
    {
        this->initializeSamplingDistributions(distributionEstimator, variables);
    }

    EventLog::TracesType traces;
    for (const auto& [caseId, sourceTrace] : sourceLog->getTraces())
    {
        // create empty trace
        traces[caseId] = std::make_unique<Trace>(variables);
        // generate trace of the same length
        for (size_t i = 0; i < sourceTrace->size(); i++)
        {
            // generate values for all variables/columns
            for (const auto& variable : variables)
            {
                // generate value
                this->generateValueInTrace(ruleGraph, sourceTrace.get(), traces.at(caseId).get(),
                    i, variable, setVariables, statistics, predictMeans, modelIsOrderedList,
                    distributionEstimator);
            }
        }
    }

    return std::make_unique<EventLog>(traces);
}

DataGenerator::SetPredictions DataGenerator::predictValueSets(
    const EventLog *const sourceLog, const RuleModel *const model, const bool modelIsOrderedList)
{
    Utils::checkNull(sourceLog);
    Utils::checkNull(model);

    // ensure acyclicity of model (if it is an unordered set of rules)
    CycleDetector detector;
    if (detector.hasCycle(model) && !modelIsOrderedList)
    {
        throw std::invalid_argument("Rule model has a cycle");
    }

    auto variables = sourceLog->getVariables();
    // find graph structure of which variables depend on which modification rules
    const auto ruleGraph = this->computeRuleGraph(variables, model);
    // all variables in the source event log are already set
    std::set<std::shared_ptr<LogVariable>> setVariables (variables.begin(), variables.end());

    SetPredictions result;
    // predict value sets for all categorical variables
    for (const auto variable : variables)
    {
        auto catVariable = std::dynamic_pointer_cast<CategoricalVariable>(variable);
        if (catVariable != nullptr)
        {
            // make predictions for each event in each trace
            for (const auto& [caseId, sourceTrace] : sourceLog->getTraces())
            {
                for (size_t i = 0; i < sourceTrace->size(); i++)
                {
                    // predict value set and add it to the result
                    auto valueSet = this->generateValueSet(ruleGraph, sourceTrace.get(), i,
                        catVariable, setVariables, modelIsOrderedList);
                    result[catVariable].push_back(valueSet);
                }
            }
        }
    }

    return result;
}
