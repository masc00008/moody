#include "logger.hpp"
#include "utils.hpp"

Logger::Logger()
    : outStream(std::cout)
{
}

Logger::Logger(std::ostream &outStream)
    : outStream(outStream)
{
}

double_t Logger::computeTimeDeltaInSeconds() const
{
    const auto duration = duration_cast<microseconds>(steady_clock::now() - this->startTime);
    return duration.count() / 1'000'000.0;
}

void Logger::startTimer()
{
    if constexpr (LOGGING && LOG_TIME)
    {
        this->startTime = steady_clock::now();
    }
}

void Logger::newVariable(const LogVariable *const variable)
{
    if constexpr (LOGGING && LOG_STATUS)
    {
        Utils::checkNull(variable);
        outStream << "Current variable: " << variable->getName() << std::endl;
    }
}

void Logger::modificationRulesGenerated(const int64_t numberOfRules)
{
    if constexpr (LOGGING)
    {
        if constexpr (LOG_STATUS)
        {
            outStream << "Generated " << numberOfRules << " modification rules"
                << std::endl;
        }
        if constexpr (LOG_TIME)
        {
            outStream << "Generating modification rules took " << this->computeTimeDeltaInSeconds()
                << " sec" << std::endl;
        }
    }
}

void Logger::rulesEstimated()
{
    if constexpr (LOGGING && LOG_TIME)
    {
        outStream << "Estimating modification rules took " <<
            this->computeTimeDeltaInSeconds() << " sec" << std::endl;
    }
}

void Logger::ruleScored(const double_t bitsActuallySaved, const double_t estimateBitsSaved,
    const ModificationRule* const rule)
{
    if constexpr (LOGGING && LOG_SCORE_ESTIMATE)
    {
        outStream << estimateBitsSaved << "," << bitsActuallySaved << ","
            << rule->getUpdateRule()->getClassName() << std::endl;
    }

    if constexpr (LOGGING && LOG_NON_OPTIMISM)
    {
        Utils::checkNull(rule);
        // log non-optimistic case using relative deviation
        // (more bits saved than estimated)
        if (bitsActuallySaved / estimateBitsSaved - 1.0 > 1e-5)
        {
            outStream << "===== Estimate was not optimistic =====" << std::endl;
            outStream << "Rule: " << rule->toString()
                << std::endl;
            outStream << "Estimate: " << estimateBitsSaved << std::endl;
            outStream << "Actual: " << bitsActuallySaved << std::endl;
        }
    }
}

void Logger::allRulesScored(const int64_t rulesSearched, const double_t bitsSaved,
    const ModificationRule* const bestRule)
{
    if constexpr (LOGGING && LOG_STATUS)
    {
        if (bestRule != nullptr)
        {
            outStream << "Rule: " << bestRule->toString() << std::endl;
        }
        outStream << "Bits saved: " << bitsSaved << std::endl;
        outStream << "Effectively searched " << rulesSearched << " rules" << std::endl;
    }

    if constexpr (LOGGING && LOG_TIME)
    {
        outStream << "Scoring modification rules took " <<
            this->computeTimeDeltaInSeconds() << " sec" << std::endl;
    }
}

void Logger::histogramCreated(const LogVariable* const variable, const Histogram & histogram)
{
    if constexpr (LOGGING && LOG_HISTOGRAM)
    {
        Utils::checkNull(variable);
        outStream << "Histogram for variable: " << variable->getName() << std::endl;
        outStream << histogram.toString() << std::endl;
    }
}

void Logger::allHistogramsCreated()
{
    if constexpr (LOGGING && LOG_TIME)
    {
        outStream << "Creating histograms took " << this->computeTimeDeltaInSeconds()
            << " sec" << std::endl;
    }
}
