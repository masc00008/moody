#include "quantilehistogramestimator.hpp"
#include "../statistics.hpp"
#include <algorithm>
#include <stdexcept>

Histogram QuantileHistogramEstimator::computeHistogram(
    std::vector<double_t> &data, const int64_t maxBins, const double_t dataAccuracy,
    const double_t /*cutPointAccuracy*/)
{
    // check parameters
    if (maxBins <= 0)
    {
        throw std::invalid_argument("maxBins <= 0");
    }
    if (dataAccuracy <= 0)
    {
        throw std::invalid_argument("dataAccuracy is 0 or negative");
    }

    const double_t binLimitOffset = dataAccuracy / 2;
    Statistics statistics;
    std::vector<double_t> binLimits = statistics.getQuantileDivisions(
        data, dataAccuracy, maxBins - 1);
    for (auto& element : binLimits)
    {
        element -= binLimitOffset;
    }

    const double_t minValue = *std::min_element(data.begin(), data.end()) - binLimitOffset;
    if (binLimits.size() == 0 || *binLimits.begin() != minValue)
    {
        binLimits.insert(binLimits.begin(), minValue);
    }

    const double_t maxValue = *std::max_element(data.begin(), data.end()) + binLimitOffset;
    if (*(binLimits.end() - 1) != maxValue)
    {
        binLimits.push_back(maxValue);
    }

    std::vector<int64_t> counts = this->computeHistogramCounts(binLimits, data);

    return Histogram(binLimits, counts);
}
