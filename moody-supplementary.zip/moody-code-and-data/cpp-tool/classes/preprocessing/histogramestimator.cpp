#include "histogramestimator.hpp"
#include <algorithm>

HistogramEstimator::~HistogramEstimator()
{
}

std::vector<int64_t> HistogramEstimator::computeHistogramCounts(
        const std::vector<double_t>& binLimits, std::vector<double_t>& data)
{
    std::sort(data.begin(), data.end());

    std::vector<int64_t> counts(binLimits.size() - 1, 0);
    size_t limitsIndex = 1;

    // loop through ordered data
    for (const auto& d : data)
    {
        // move to next bin if the data point exceeds the current bin limit
        if (limitsIndex - 1 < counts.size() && d > binLimits[limitsIndex])
        {
            limitsIndex++;
        }
        // count data point in current bin
        counts[limitsIndex - 1]++;
    }

    return counts;
}
