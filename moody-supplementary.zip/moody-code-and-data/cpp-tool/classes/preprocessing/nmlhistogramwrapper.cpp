#include "nmlhistogramwrapper.hpp"
#include <algorithm>
#include <stdexcept>
#include "../utils.hpp"
extern "C"
{
    #include "../../libraries/nmlhistograms/NML_histogram.h"
}

Histogram NmlHistogramWrapper::computeHistogram(
    std::vector<double_t>& data, const int64_t maxBins, const double_t dataAccuracy,
    const double_t cutPointAccuracy)
{
    // check parameters
    if (maxBins <= 0)
    {
        throw std::invalid_argument("maxBins <= 0");
    }
    if (dataAccuracy <= 0)
    {
        throw std::invalid_argument("dataAccuracy is 0 or negative");
    }
    if (cutPointAccuracy <= 0)
    {
        throw std::invalid_argument("cutPointAccuracy is 0 or negative");
    }
    if (cutPointAccuracy < dataAccuracy)
    {
        throw std::invalid_argument("cutPointAccuracy < dataAccuracy");
    }

    // prepare data for low-level C functions
    std::sort(data.begin(), data.end()); // sort the values
    // cut off imprecise digits
    for (auto& d : data)
    {
        d = Utils::round(d, dataAccuracy);
    }

    // create NML histogram
    using HistogramSmartPointer = 
        std::unique_ptr<histogram, decltype(&delete_histogram)>;
    HistogramSmartPointer nmlHistogram(
        new_histogram(maxBins, dataAccuracy, cutPointAccuracy),
        delete_histogram);
    // compute NML histogram
    histogram_NML(nmlHistogram.get(), maxBins, data.size(), data.data());

    // construct bin limits
    std::vector<double_t> binLimits (
        nmlHistogram->cut, nmlHistogram->cut + nmlHistogram->nof_bins + 1);
    std::vector<int64_t> counts = this->computeHistogramCounts(binLimits, data);

    return Histogram(binLimits, counts);
}
