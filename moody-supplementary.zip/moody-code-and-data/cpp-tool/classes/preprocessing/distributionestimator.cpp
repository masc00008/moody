#include "distributionestimator.hpp"
#include "../datamodel/eventlogs/logcolumn.hpp"
#include "../utils.hpp"
#include <stdexcept>
#include <algorithm>
#include <cmath>
#include <numeric>
#include <float.h>
#include "../datamodel/updaterules/abstractvaluerule.hpp"
#include "../datamodel/updaterules/abstractrangerule.hpp"
#include <iostream>
#include "nmlhistogramwrapper.hpp"

DistributionEstimator::HistogramCache DistributionEstimator::histogramCache;

DistributionEstimator::DistributionEstimator(std::unique_ptr<HistogramEstimator>& histogramEstimator,
                           std::unique_ptr<ColumnCollector>& collector, const bool cacheHistograms)
    : cacheHistograms(cacheHistograms),
      catDistributionStore(),
      histogramStore(),
      histogramEstimator((Utils::checkNull(histogramEstimator), std::move(histogramEstimator))),
      collector((Utils::checkNull(collector), std::move(collector)))
{   
}

DistributionEstimator::DistributionEstimator()
    : cacheHistograms(true),
      catDistributionStore(),
      histogramStore(),
      histogramEstimator(std::make_unique<NmlHistogramWrapper>()),
      collector(std::make_unique<ColumnCollector>())
{
}

void DistributionEstimator::checkVariableAndValue(
        const std::shared_ptr<CategoricalVariable>& variable, const ValueSetRule::SetType& set,
        const std::string& value)
{
    if (this->catDistributionStore.find(variable) == this->catDistributionStore.end())
    {
        throw std::invalid_argument("Variable does not exist in lookup table");
    }

    if (this->catDistributionStore[variable].find(value) == this->catDistributionStore[variable].end())
    {
        throw std::invalid_argument("Value was never observed for the given variable");
    }

    if (set.find(value) == set.end())
    {
        throw std::invalid_argument("Value is not part of the set");
    }
}

double_t DistributionEstimator::computeProbability(
        const std::shared_ptr<CategoricalVariable>& variable, const ValueSetRule::SetType& set,
        const std::string& value)
{
    Utils::checkNull(variable);
    this->checkVariableAndValue(variable, set, value);

    double_t sum = 0.0;
    for (const auto& valueFrequencyPair : this->catDistributionStore[variable])
    {
        if (set.find(valueFrequencyPair.first) != set.end())
        {
            sum += valueFrequencyPair.second;
        }
    }
    return this->catDistributionStore[variable][value] / sum;
}

void DistributionEstimator::initializeCatDistributionStore(const EventLog* const log)
{
    // make sure the lookup table is empty
    this->catDistributionStore = CatDistributionStoreType();
    // collect all categorical data
    ColumnCollector::MultiColumnsType<std::string> categoricalColumns = 
        this->collector->collectAllColumns<std::string>(log);
    // count occurences of categories
    for (const auto& columnPair : categoricalColumns)
    {
        const std::shared_ptr<CategoricalVariable> variable =
            std::static_pointer_cast<CategoricalVariable>(columnPair.first);
        for (const auto& value : columnPair.second)
        {
            this->catDistributionStore[variable][value]++;
        }
    }
}

void DistributionEstimator::initializeHistogramStore(const EventLog* const log)
{
    // make sure the lookup table is empty
    this->histogramStore = HistogramStoreType();

    // collect all numerical data
    ColumnCollector::MultiColumnsType<double_t> numericalColumns = 
        this->collector->collectAllColumns<double_t>(log);

    logger.startTimer();
    // iterate through all columns
    for (auto& columnPair : numericalColumns)
    {
        // copy the raw entries for the lookup table key
        const std::vector<double_t> rawEntries(columnPair.second);

        const auto variable = std::static_pointer_cast<NumericalVariable>(columnPair.first);
        const double_t accuracy = variable->getAccuracy();

        // used cached histogram if enabled
        if (this->cacheHistograms && histogramCache.find(rawEntries) != histogramCache.end())
        {
            this->histogramStore.insert({variable, histogramCache.at(rawEntries)});
        }
        // only compute histogram bins if they were not cached before
        else
        {
            // compute histogram
            Histogram hist = this->histogramEstimator->computeHistogram(
                    columnPair.second, this->maxNumberOfBins, accuracy, accuracy);
            
            // save histogram in the lookup table
            if (this->cacheHistograms)
            {
                histogramCache.insert({rawEntries, hist});
            }

            this->histogramStore.insert({variable, hist});
        }

        logger.histogramCreated(variable.get(), this->histogramStore.at(variable));
    }
    logger.allHistogramsCreated();
}

void DistributionEstimator::calculateGlobalDistributions(const EventLog* const log)
{
    Utils::checkNull(log);
    this->initializeCatDistributionStore(log);   
    this->initializeHistogramStore(log);
}

double_t DistributionEstimator::getGlobalProbability(
        const std::shared_ptr<CategoricalVariable>& variable, const std::string& value)
{
    return this->computeProbability(variable, variable->getDomain(), value);
}

double_t DistributionEstimator::getRuleProbability(
        const ValueSetRule* const rule, const std::string& value)
{
    Utils::checkNull(rule);
    const std::shared_ptr<CategoricalVariable> catVariable =
        std::static_pointer_cast<CategoricalVariable>(rule->getVariable());
    return this->computeProbability(catVariable, rule->getSet(), value);
}

double_t DistributionEstimator::getGlobalProbability(
    const std::shared_ptr<NumericalVariable>& variable, const double_t value)
{
    // verify inputs
    Utils::checkNull(variable);
    if (this->histogramStore.find(variable) == this->histogramStore.end())
    {
        throw std::invalid_argument("Variable does not exist in lookup table");
    }

    return this->histogramStore.at(variable).getProbability(value, variable->getAccuracy());
}

template <typename T>
double_t DistributionEstimator::getGlobalProbabilityTemplated(
    const std::shared_ptr<LogVariable> &variable, const T &value)
{
    if (!Utils::variableTypeMatches<T>(variable))
    {
        throw std::invalid_argument("Template type and variable type mismatch");
    }

    if constexpr (std::is_same_v<T, std::string>)
    {
        const auto catVariable = std::static_pointer_cast<CategoricalVariable>(variable);
        return this->getGlobalProbability(catVariable, value);
    }

    if constexpr (std::is_same_v<T, double_t>)
    {
        const auto numVariable = std::static_pointer_cast<NumericalVariable>(variable);
        return this->getGlobalProbability(numVariable, value);
    }
}

template double_t DistributionEstimator::getGlobalProbabilityTemplated(
    const std::shared_ptr<LogVariable> &variable, const double_t &value);
template double_t DistributionEstimator::getGlobalProbabilityTemplated(
    const std::shared_ptr<LogVariable> &variable, const std::string &value);

const DistributionEstimator::CatDistributionType& DistributionEstimator::getCategoricalDistribution(
    const std::shared_ptr<CategoricalVariable> &variable) const
{
    return this->catDistributionStore.at(variable);
}

const Histogram &DistributionEstimator::getNumericalDistribution(
    const std::shared_ptr<NumericalVariable> &variable) const
{
    return this->histogramStore.at(variable);
}

double_t DistributionEstimator::getRuleProbability(const UpdateRule *rule)
{
    Utils::checkNull(rule);

    auto valueRule = dynamic_cast<const AbstractValueRule*>(rule);
    if (valueRule != nullptr)
    {
        // value rules are exact, no bits needed (probability 1)
        return 1.0;
    }

    auto rangeRule = dynamic_cast<const AbstractRangeRule*>(rule);
    if (rangeRule != nullptr)
    {
        // compute subdivisions of the range specified by the variable's accuracy
        const auto numVariable = std::static_pointer_cast<NumericalVariable>(rule->getVariable());
        const int64_t possibilities =
            std::ceil((rangeRule->getMax() - rangeRule->getMin()) / numVariable->getAccuracy());
        // TODO potentially one possiblility too little
        return 1.0 / possibilities;
    }
    
    throw std::invalid_argument("Given update rule type not supported");
}

template <typename T>
double_t DistributionEstimator::getRuleProbabilityTemplated(const UpdateRule *rule, const T &value)
{
    if (!Utils::variableTypeMatches<T>(rule->getVariable()))
    {
        throw std::invalid_argument("Template type and variable type mismatch");
    }
    
    if constexpr (std::is_same_v<T, std::string>)
    {
        const auto valueSetRule = static_cast<const ValueSetRule*>(rule);
        return this->getRuleProbability(valueSetRule, value);
    }

    if constexpr (std::is_same_v<T, double_t>)
    {
        return this->getRuleProbability(rule);
    }
}

template double_t DistributionEstimator::getRuleProbabilityTemplated(
    const UpdateRule *rule, const double_t &value);
template double_t DistributionEstimator::getRuleProbabilityTemplated(
    const UpdateRule *rule, const std::string &value);
