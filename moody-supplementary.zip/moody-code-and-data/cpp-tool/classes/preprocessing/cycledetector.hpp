#pragma once
#include <unordered_map>
#include <unordered_set>
#include <cstdint>
#include "../datamodel/rulemodel.hpp"

/// @brief Used for detecting whether a model of data modification rules contains cycles
class CycleDetector
{
    public:
    /// @brief Represents the directed edges in a graph, keys are the node IDs of parent nodes,
    /// the value is the set of child node IDs
    using AdjacencyList = std::unordered_map<std::string, std::unordered_set<std::string>>;

    private:
    /// @brief State of a graph node during the search for cycles
    enum Color {White_unvisited, Gray_visited, Black_dead};

    /// @brief Obtains all node IDs present in the adjacency list
    /// @param adjacencyList adjacency of directed graph to obtain node IDs from
    /// @return set of all node IDs
    std::unordered_set<std::string> collectAllNodeIds(const AdjacencyList& adjacencyList);

    /// @brief Performs the recursive depth-first search step in the search for cycles in a directed
    /// graph
    /// @param nodeId node in the graph to start the search from
    /// @param colors search states of all graph nodes
    /// @param adjacencyList adjacency of directed graph to search
    /// @param foundCycle whether a cycle was found in the graph
    /// @return 
    bool depthFirstSearch(const std::string nodeId, std::unordered_map<std::string, Color>& colors,
        const AdjacencyList& adjacencyList, bool& foundCycle);

    public:
    /// @brief Computes the adjacency list of a directed graph where each node represents an event
    /// log variable and each edge shows that the source node is part of the condition and the sink
    /// node is in the update rule of some modification rule
    /// @param model model of modification rules to obtain directed graph from
    /// @return adjacency list of the directed graph
    AdjacencyList computeAdjacencyList(const RuleModel* const model);

    /// @brief Adds edges from all condition variables to the target variable to the adjacency list
    /// @param list adjacency list to insert into
    /// @param conditionVariables variables where all edges originate from
    /// @param targetVariable variable that all edges point towards
    void addEdgesToAdjacencyList(AdjacencyList& list,
        const std::set<std::shared_ptr<LogVariable>>& conditionVariables,
        const std::shared_ptr<LogVariable>& targetVariable);

    /// @brief Determines whether the directed graph contains at least one cycle
    /// @param adjacencyList adjacency list of the directed graph
    /// @return true if there is at least one cycle, false otherwise
    bool hasCycle(const AdjacencyList& adjacencyList);

    /// @brief Determines whether the model of modification rules contains at least one cycle
    /// @param model model of modification rules to check
    /// @return true if there is at least one cycle, false otherwise
    bool hasCycle(const RuleModel* const model);
};
