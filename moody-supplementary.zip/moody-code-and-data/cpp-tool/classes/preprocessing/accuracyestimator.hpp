#pragma once
#include "../datamodel/eventlogs/eventlog.hpp"
#include <cmath>

/// @brief Collects computations related to the accuracy of numerical variables
class AccuracyEstimator
{
    public:
    /// @brief Computes and sets the accuracies of all numerical variables in the event log
    /// @param log event log to get numerical values from and to set accuracies for
    void initializeAllAccuracies(const EventLog* const log);

    /// @brief Calculates the accuracy of the given data points as the smallest non-zero difference
    /// between data points
    /// @param data values to compute the accuracy for (will be sorted)
    /// @return smallest non-zero difference between data points
    double_t computeAccuracy(std::vector<double_t>& data);
};
