#include "cycledetector.hpp"
#include "../utils.hpp"
#include "../datamodel/conditions/atomiccondition.hpp"

std::unordered_set<std::string> CycleDetector::collectAllNodeIds(const AdjacencyList& adjacencyList)
{
    std::unordered_set<std::string> result;

    // iterate through parent nodes
    for (const auto& [parent, children] : adjacencyList)
    {
        // add parent node to list of node IDs
        result.insert(parent);

        // iterate through child nodes
        for (const auto& child : children)
        {
            // add child node to list of node IDs
            result.insert(child);
        }
    }

    return result;
}

CycleDetector::AdjacencyList CycleDetector::computeAdjacencyList (const RuleModel* const model)
{
    Utils::checkNull(model);
    AdjacencyList result;

    // iterate through all rules in the model
    for (const auto& rule : model->getRules())
    {
        this->addEdgesToAdjacencyList(result, rule->getCondition()->getVariables(),
            rule->getUpdateRule()->getVariable());
    }

    return result;
}

void CycleDetector::addEdgesToAdjacencyList(AdjacencyList &list,
    const std::set<std::shared_ptr<LogVariable>> &conditionVariables,
    const std::shared_ptr<LogVariable> &targetVariable)
{
    for (const auto& conditionVariable : conditionVariables)
    {
        list[conditionVariable->getName()].insert(targetVariable->getName());
    }
}

bool CycleDetector::depthFirstSearch(const std::string nodeId,
        std::unordered_map<std::string, Color>& colors,
        const AdjacencyList& adjacencyList, bool& foundCycle)
{
    // implementation from https://cp-algorithms.com/graph/finding-cycle.html#implementation
    // mark node as visited
    colors[nodeId] = Gray_visited;
    
    if (adjacencyList.find(nodeId) != adjacencyList.end())
    {
        // search through all child nodes (if there are any)
        for(const auto& childNodeId : adjacencyList.at(nodeId))
        {
            // if node is unvisited, recurse search
            if (colors[childNodeId] == White_unvisited)
            {
                if (this->depthFirstSearch(childNodeId, colors, adjacencyList, foundCycle))
                {
                    return true;
                }
            }
            // if node is visited, we found a cycle
            else if (colors[childNodeId] == Gray_visited)
            {
                foundCycle = true;
                return true;
            }
        }
    }

    // mark node as dead
    colors[nodeId] = Black_dead;
    return false;
}

bool CycleDetector::hasCycle(const AdjacencyList& adjacencyList)
{
    // implementation from https://cp-algorithms.com/graph/finding-cycle.html#implementation
    std::unordered_set<std::string> allNodeIds = this->collectAllNodeIds(adjacencyList);

    // initialize all node colors as unvisited
    std::unordered_map<std::string, Color> colors;
    for (const auto& nodeId : allNodeIds)
    {
        colors[nodeId] = White_unvisited;
    }

    // depth first search from each node until a cycle is found
    bool foundCycle = false;
    for (const auto& nodeId : allNodeIds)
    {
        if (colors[nodeId] == White_unvisited &&
            this->depthFirstSearch(nodeId, colors, adjacencyList, foundCycle))
        {
            break;
        }
    }

    return foundCycle;
}

bool CycleDetector::hasCycle(const RuleModel* const model)
{
    return this->hasCycle(this->computeAdjacencyList(model));
}
