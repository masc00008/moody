#pragma once
#include <map>
#include <vector>
#include <cmath>
#include <string>

/// @brief Represents a histogram with variable bin widths
class Histogram
{
    private:
    /// @brief Stores the frequencies of each bin
    std::map<double_t, int64_t> countsStore;
    /// @brief Stores the sum of all bin counts
    int64_t totalCount;
    /// @brief Stores the upper limit in the value range of the histogram
    double_t upperBound;
    /// @brief Throws an error if the value is outside of the value range of the histogram
    /// @param value the value to check
    void checkValue(const double_t value) const;
    /// @brief Throws an error if the given vectors are too small (binLimits < 2 or counts < 1)
    /// @param binLimits vector with bin limits to check
    /// @param counts vector with bin counts to check
    static void checkEmpty(const std::vector<double_t>& binLimits, const std::vector<int64_t>& counts);

    public:
    /// @brief Creates a new histogram
    /// @param binLimits the limits/cutpoints of the bins in the value range, at least 2 elements,
    /// one element more than in counts, strict ascending order
    /// @param counts the counts for each bin, assigned to the bins/binLimits using their order,
    /// at least 1 element, no negative values
    Histogram(const std::vector<double_t>& binLimits, const std::vector<int64_t>& counts);
    /// @brief Determines the bin count for the given value
    /// @param value value to get bin count for, in value range of the histogram
    /// @return count of the bin that the value falls into
    int64_t getCount(const double_t value) const;
    /// @brief Determines the width of the bin for the given value
    /// @param value value to get the bin width for, in value range of the histogram
    /// @return width (i.e. upper limit - lower limit) of the bin that the value falls into
    double_t getBinWidth(const double_t value) const;
    /// @brief Determines the smallest and largest value covered by the histogram
    /// @return pair of smallest and largest value
    std::pair<double_t, double_t> getRange() const;
    /// @brief Determines the smallest and largest value covered by the bin that the value falls into
    /// @param value used to select the histogram's bin
    /// @return pair of smallest and largest value
    std::pair<double_t, double_t> getBinLimits(const double_t value) const;
    /// @brief Computes the probability of a value according to the histogram
    /// @param value value to get the probability for
    /// @param accuracy smallest meaningful difference between two values
    /// @return probability of the value
    double_t getProbability(const double_t value, const double_t accuracy) const;
    /// @brief Determines whether a value is in the range of values that the histogram covers
    /// @param value value to check
    /// @return true if value is in histogram range, false otherwise
    bool inRange(const double_t value) const;

    int64_t getTotalCount() const { return totalCount; }
    std::string toString() const;
};
