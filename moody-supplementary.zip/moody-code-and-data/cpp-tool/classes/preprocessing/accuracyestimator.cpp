#include "accuracyestimator.hpp"
#include "../utils.hpp"
#include <algorithm>
#include "../datamodel/eventlogs/numericalvariable.hpp"
#include "../columncollector.hpp"
#include <stdexcept>

void AccuracyEstimator::initializeAllAccuracies(const EventLog *const log)
{
    Utils::checkNull(log);

    // get variables and numerical values from the event log
    ColumnCollector collector;
    const auto variables = log->getVariables();
    auto numColumns = collector.collectAllColumns<double_t>(log);

    for (auto& [variable, values] : numColumns)
    {
        // compute accuracy and save it to the variable object
        const std::shared_ptr<NumericalVariable> numVariable =
            std::static_pointer_cast<NumericalVariable>(variable);
        const double_t accuracy = this->computeAccuracy(values);

        // sanity check on accuracy
        if (!std::isnormal(accuracy))
        {
            throw std::invalid_argument("Values for variable " + numVariable->getName() +
                " lead to the invalid accuracy " + std::to_string(accuracy) +
                ". Does the variable have more than one numeric value?");
        }

        numVariable->setAccuracy(accuracy);
    }
}

double_t AccuracyEstimator::computeAccuracy(std::vector<double_t>& data)
{
    std::sort(data.begin(), data.end());
    double_t accuracy = std::numeric_limits<double_t>::infinity();
    // loop through all data points
    for (size_t i = 1; i < data.size(); i++)
    {
        // find smallest non-zero difference between two consecutive data points
        if (data[i] - data[i-1] >= std::numeric_limits<double_t>::epsilon()
            && data[i] - data[i-1] < accuracy)
        {
            accuracy = data[i] - data[i-1];
        }
    }

    return accuracy;
}
