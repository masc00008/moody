#pragma once
#include <unordered_map>
#include <map>
#include <cstdint>
#include <string>
#include <memory>
#include <cmath>
#include "../datamodel/eventlogs/eventlog.hpp"
#include "../datamodel/eventlogs/categoricalvariable.hpp"
#include "../datamodel/eventlogs/numericalvariable.hpp"
#include "../datamodel/updaterules/valuesetrule.hpp"
#include "../datamodel/modificationrule.hpp"
#include "../datamodel/rulemodel.hpp"
#include "histogram.hpp"
#include "histogramestimator.hpp"
#include "../columncollector.hpp"
#include "../logger.hpp"

// vector hash implementation from https://stackoverflow.com/questions/37007307/fast-hash-function-for-stdvector
namespace std
{
    template <class T>
    inline void hash_combine(std::size_t& seed, T const& v)
    {
        seed ^= std::hash<T>()(v) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
    }

    template<typename T>
    struct hash<vector<T>>
    {
        typedef vector<T> argument_type;
        typedef std::size_t result_type;
        result_type operator()(argument_type const& in) const
        {
            size_t size = in.size();
            size_t seed = 0;
            for (size_t i = 0; i < size; i++)
                //Combine the hash of the current vector with the hashes of the previous ones
                hash_combine(seed, in[i]);
            return seed;
        }
    };
}

/// @brief Estimates distributions from event logs
class DistributionEstimator
{
    public:
    using CatDistributionType = std::map<std::string, int64_t>;
    using CatDistributionStoreType = std::unordered_map<
        std::shared_ptr<CategoricalVariable>, CatDistributionType>;
    using HistogramStoreType = std::unordered_map<
        std::shared_ptr<NumericalVariable>, Histogram>;
    using HistogramCache = std::unordered_map<std::vector<double_t>, Histogram>;

    private:
    /// @brief Global lookup table for histograms. Used to avoid costly
    /// re-calculation of histogram bins when the data is identical.
    static HistogramCache histogramCache;
    /// @brief Flag for configuring whether the lookup table for histograms should be used
    bool cacheHistograms;
    /// @brief Lookup table for counts of values per categorical log variable
    CatDistributionStoreType catDistributionStore;
    /// @brief Lookup table for the histograms per numerical log variable
    HistogramStoreType histogramStore;
    /// @brief Used to automatically determine the bin limits of a histogram
    std::unique_ptr<HistogramEstimator> histogramEstimator;
    /// @brief Used to collect values from the traces of an event log
    std::unique_ptr<ColumnCollector> collector;
    /// @brief Used to limit precision (and memory/time complexity) of histogram
    const int64_t maxNumberOfBins = 50;
    
    Logger logger;

    /// @brief Throws an exception if the variable is not in the lookup table, if the value was
    /// not observed for the variable, or if the value is not part of the set
    /// @param variable variable to find in the lookup table
    /// @param set set of values, subset of all possible values of the variable
    /// @param value value to check as part of the set or lookup table
    void checkVariableAndValue(
        const std::shared_ptr<CategoricalVariable>& variable, const ValueSetRule::SetType& set,
        const std::string& value);

    /// @brief Computes the probability of the value as the relative frequency of the values in
    /// the lookup table
    /// @param variable log variable to find the probability for
    /// @param set subset of values to restrict the values taken into account for the total
    /// count (100%)
    /// @param value value to find the probability of
    /// @return probability of observing the value given the lookup table and the restricting set
    double_t computeProbability(
        const std::shared_ptr<CategoricalVariable>& variable, const ValueSetRule::SetType& set,
        const std::string& value);

    /// @brief Populates the lookup table for categorical distributions using the data in the
    /// event log
    /// @param log event log to get data from
    void initializeCatDistributionStore(const EventLog* const log);

    /// @brief Populates the lookup table of histograms for continuous values using the data
    /// in the event log
    /// @param log event log to get data from
    void initializeHistogramStore(const EventLog* const log);

    public:
    DistributionEstimator(std::unique_ptr<HistogramEstimator>& histogramEstimator,
        std::unique_ptr<ColumnCollector>& collector, const bool cacheHistograms = true);
    DistributionEstimator();
    virtual ~DistributionEstimator() = default;
    
    /// @brief Calculates the distributions from the event log and stores them in the lookup table
    /// @param log event log to calculate distributions from, not null
    virtual void calculateGlobalDistributions(const EventLog* const log);

    /// @brief Calculates the probability of the value occuring for the variable
    /// \pre lookup table was filled using calculateGlobalDistributions
    /// @param variable categorical variable for which the value occurred
    /// @param value value to get the probability for
    /// @return the probability
    virtual double_t getGlobalProbability(
        const std::shared_ptr<CategoricalVariable>& variable, const std::string& value);

    /// @brief Calculates the probability of the value occuring for the variable
    /// \pre lookup table was filled using calculateGlobalDistributions
    /// @param variable numerical variable for which the value occurred
    /// @param value value to get the probability for
    /// @return the probability
    virtual double_t getGlobalProbability(
        const std::shared_ptr<NumericalVariable>& variable, const double_t value);

    /// @brief Calculates the probability of the value occuring for the variable
    /// \pre lookup table was filled using calculateGlobalDistributions
    /// @tparam T type of the data to get probability for (double_t or std::string)
    /// @param variable variable for which the value occurred
    /// @param value value to get the probability for
    /// @return the probability
    template<typename T> double_t getGlobalProbabilityTemplated(
        const std::shared_ptr<LogVariable>& variable, const T& value);

    /// @brief Calculates the probability of the value occuring for the rule
    /// \pre lookup table was filled using calculateGlobalDistributions
    /// @param rule rule that restricts which values are possible in the current context
    /// @param value value to get the probability of
    /// @return the probability
    virtual double_t getRuleProbability(
        const ValueSetRule* const rule, const std::string& value);

    /// @brief Computes the probability of a a numerical value that matches its
    /// update rule
    /// @param rule update rule that the numerical value matched
    /// @return probability of the value
    virtual double_t getRuleProbability(const UpdateRule* rule);

    /// @brief Calculates the probability of the value occuring for the rule
    /// \pre lookup table was filled using calculateGlobalDistributions
    /// \pre it was checked that the rule matched this value
    /// @param rule rule that restricts which values are possible in the current context
    /// @param value value to get the probability of
    /// @return the probability
    template<typename T> double_t getRuleProbabilityTemplated(
        const UpdateRule* rule, const T& value);

    virtual const CatDistributionType& getCategoricalDistribution(
        const std::shared_ptr<CategoricalVariable>& variable) const;
    virtual const Histogram& getNumericalDistribution(
        const std::shared_ptr<NumericalVariable>& variable) const;
};
