#pragma once
#include "histogramestimator.hpp"

/// @brief Computes histograms from numerical samples using non-interpolated quantiles
class QuantileHistogramEstimator : public HistogramEstimator
{
    public:
    /// @brief Computes a variable width histogram from data using non-interpolated quantiles
    /// @param data samples to compute the histogram for, will be modified by the function (sorting)
    /// @param maxBins how many bins the histogram should have at maximum
    /// @param dataAccuracy smallest difference between samples that is meaningful
    /// @param cutPointAccuracy ignored
    /// @return the histogram
    virtual Histogram computeHistogram(std::vector<double_t>& data,
        const int64_t maxBins, const double_t dataAccuracy, const double_t /*cutPointAccuracy*/);
};
