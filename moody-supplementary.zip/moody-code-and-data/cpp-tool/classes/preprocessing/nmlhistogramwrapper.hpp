#pragma once
#include <memory>
#include <vector>
#include "histogramestimator.hpp"

/// @brief wrapper class for the C library to compute NML histograms
class NmlHistogramWrapper : public HistogramEstimator
{
    public:
    virtual ~NmlHistogramWrapper() = default;
    /// @brief Computes a variable width histogram from data using Normalized Maximum Likelihood (NML)
    /// @param data samples to compute the histogram for, will be modified by the function (sorting and
    /// rounding to a meaningful accuracy)
    /// @param maxBins how many bins the histogram should have at maximum
    /// @param dataAccuracy smallest difference between samples that is meaningful
    /// @param cutPointAccuracy minimum width of a bin in the histogram, >= dataAccuracy
    /// @return the histogram
    virtual Histogram computeHistogram(std::vector<double_t>& data,
        const int64_t maxBins, const double_t dataAccuracy, const double_t cutPointAccuracy);
};
