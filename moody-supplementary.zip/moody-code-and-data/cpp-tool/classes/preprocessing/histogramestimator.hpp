#pragma once
#include "histogram.hpp"

/// @brief Base class for all classes that are capable of estimating histograms for numerical values
class HistogramEstimator
{
    protected:
    /// @brief Counts the number of data points that fall into each histogram bin
    /// @param binLimits the limits/cutpoints of the bins in the value range, in strictly ascending order
    /// @param data values to count (will be sorted)
    /// @return sorted counts for the bins
    std::vector<int64_t> computeHistogramCounts(
        const std::vector<double_t>& binLimits, std::vector<double_t>& data);

    public:
    virtual ~HistogramEstimator() = 0;
    /// @brief Computes a (variable width) histogram from data
    /// @param data samples to compute the histogram for, can be modified by the function
    /// @param maxBins how many bins the histogram should have at maximum
    /// @param dataAccuracy smallest difference between samples that is meaningful
    /// @param cutPointAccuracy minimum width of a bin in the histogram, >= dataAccuracy
    /// @return the histogram
    virtual Histogram computeHistogram(std::vector<double_t>& data,
        const int64_t maxBins, const double_t dataAccuracy, const double_t cutPointAccuracy) = 0;
};
