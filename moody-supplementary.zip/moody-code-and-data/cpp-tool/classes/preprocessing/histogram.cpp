#include "histogram.hpp"
#include <stdexcept>

Histogram::Histogram(const std::vector<double_t>& binLimits, const std::vector<int64_t>& counts)
    : countsStore(),
      totalCount(0),
      upperBound((checkEmpty(binLimits, counts), binLimits[binLimits.size() - 1]))
{
    // check for relationship of sizes
    if (binLimits.size() != counts.size() + 1)
    {
        throw std::invalid_argument("Size of binLimits is not one larger than the size of counts");
    }

    // check for non-negative counts
    for (const auto& count : counts)
    {
        if (count < 0)
        {
            throw std::invalid_argument("Count is negative");
        }
    }

    // check for orderedness
    double_t lastLimit = -std::numeric_limits<double_t>::infinity();
    for (const auto& limit : binLimits)
    {
        if (lastLimit < limit)
        {
            lastLimit = limit;
        }
        else
        {
            throw std::invalid_argument("binLimits do not have a strictly ascending order");
        }
    }

    // initialize count storage
    for (size_t i = 0; i < counts.size(); i++)
    {
        this->countsStore.insert(std::make_pair(binLimits[i], counts[i]));
        this->totalCount += counts[i];
    }
}

void Histogram::checkValue(const double_t value) const
{
    if (!this->inRange(value))
    {
        throw std::invalid_argument("Value is outside the histogram bounds");
    }
}

void Histogram::checkEmpty(const std::vector<double_t>& binLimits, const std::vector<int64_t>& counts)
{
    if (binLimits.size() < 2 || counts.size() < 1)
    {
        throw std::invalid_argument("Histogram cannot be empty");
    }
}

int64_t Histogram::getCount(const double_t value) const
{
    this->checkValue(value);

    auto it = this->countsStore.upper_bound(value);
    return (*(--it)).second;
}

double_t Histogram::getBinWidth(const double_t value) const
{
    std::pair<double_t, double_t> binLimits = this->getBinLimits(value);
    return binLimits.second - binLimits.first;
}

std::pair<double_t, double_t> Histogram::getRange() const
{
    return std::make_pair(this->countsStore.begin()->first, this->upperBound);
}

std::pair<double_t, double_t> Histogram::getBinLimits(const double_t value) const
{
    this->checkValue(value);

    auto it = this->countsStore.upper_bound(value);
    double_t binEnd;
    if (it == this->countsStore.end())
    {
        // last bin bound is stored separately (not in the map)
        binEnd = this->upperBound;
    }
    else
    {
        binEnd = (*it).first;
    }
    const double_t binStart = (*(--it)).first;
    return std::make_pair(binStart, binEnd);
}

double_t Histogram::getProbability(const double_t value, const double_t accuracy) const
{
    const double_t binWidth = this->getBinWidth(value);
    const int64_t count = this->getCount(value);
    const int64_t totalCount = this->getTotalCount();

    // calculate how many sub-bins to divide the histogram bin into
    const int64_t binSubdivisions = std::round(binWidth / accuracy);
    // calculate relative frequency divided by sub-bin count
    return (double_t) count / (double_t) totalCount / (double_t) binSubdivisions;
}

bool Histogram::inRange(const double_t value) const
{
    const std::pair<double_t, double_t> range = this->getRange();
    return range.first <= value && value <= range.second;
}

std::string Histogram::toString() const
{
    std::string result = "";
    for (auto it = this->countsStore.begin(); it != this->countsStore.end();)
    {
        const double_t binStart = it->first;
        const int64_t count = it->second;

        it++;
        double_t binEnd;
        if (it == this->countsStore.end())
        {
            binEnd = this->upperBound;
        }
        else
        {
            binEnd = it->first;
        }

        result += "[" + std::to_string(binStart) + ", " + std::to_string(binEnd) + "]: "
            + std::to_string(count) + "\n";
    }
    return result;
}
