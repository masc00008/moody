#include "updaterulematcher.hpp"
#include "../utils.hpp"
#include "../datamodel/eventlogs/logcolumn.hpp"
#include "../datamodel/updaterules/valuerangerule.hpp"
#include "../datamodel/updaterules/changerangerule.hpp"
#include "../datamodel/updaterules/valuerule.hpp"
#include "../datamodel/updaterules/factorrule.hpp"
#include "../datamodel/updaterules/differencerule.hpp"
#include <stdexcept>

bool UpdateRuleMatcher::matches(const UpdateRule *const rule, const Trace *const trace,
    size_t index)
{
    auto setRule = dynamic_cast<const ValueSetRule*>(rule);
    if (setRule != nullptr)
    {
        return this->matches(setRule, trace, index);
    }

    auto valueRule = dynamic_cast<const AbstractValueRule*>(rule);
    if (valueRule != nullptr)
    {
        return this->matches(valueRule, trace, index);
    }
    
    auto rangeRule = dynamic_cast<const AbstractRangeRule*>(rule);
    if (rangeRule != nullptr)
    {
        return this->matches(rangeRule, trace, index);
    }
    
    throw std::invalid_argument("Rule matches none of the implemented subclasses");
}

bool UpdateRuleMatcher::matches(
    const ValueSetRule *const rule, const Trace *const trace, size_t index)
{
    Utils::checkNull(rule);

    std::string value = Utils::retrieveValue<std::string>(rule->getVariable(), trace, index);
    return rule->getSet().find(value) != rule->getSet().end();
}

bool UpdateRuleMatcher::matches(
    const AbstractRangeRule* const rule, const Trace* const trace, size_t index)
{
    Utils::checkNull(rule);
    Utils::checkNull(trace);
    const double_t accuracy = rule->getVariable()->getAccuracy();

    const ValueRangeRule* valueRule = dynamic_cast<const ValueRangeRule*>(rule);
    if (valueRule != nullptr)
    {
        const double_t value = Utils::retrieveValue<double_t>(rule->getVariable(), trace, index);
        return Utils::inRange(value, valueRule->getMin(), valueRule->getMax(), accuracy);
    }

    const ChangeRangeRule* changeRule = dynamic_cast<const ChangeRangeRule*>(rule);
    if (changeRule != nullptr)
    {
        // change rule never matches at first index (no change yet)
        if (index == 0)
        {
            return false;
        }
        const double_t currentValue = Utils::retrieveValue<double_t>(
            rule->getVariable(), trace, index);
        const double_t previousValue = Utils::retrieveValue<double_t>(
            rule->getVariable(), trace, index - 1);
        const double_t change = currentValue - previousValue;
        return Utils::inRange(
            change, changeRule->getMin(), changeRule->getMax(), accuracy);
    }

    throw std::invalid_argument("Rule matches none of the implemented subclasses");
}

bool UpdateRuleMatcher::matches(const AbstractValueRule *const rule, const Trace *const trace,
    size_t index)
{
    Utils::checkNull(rule);
    Utils::checkNull(trace);

    const double_t value = Utils::retrieveValue<double_t>(rule->getVariable(), trace, index);
    const double_t accuracy = rule->getVariable()->getAccuracy();

    auto valueRule = dynamic_cast<const ValueRule*>(rule);
    auto factorRule = dynamic_cast<const FactorRule*>(rule);
    auto differenceRule = dynamic_cast<const DifferenceRule*>(rule);

    double_t predictedValue;
    if (valueRule != nullptr)
    {
        predictedValue = valueRule->getConstant();
    }
    else if (factorRule != nullptr || differenceRule != nullptr)
    {
        if (index == 0)
        {
            return false;
        }
        else
        {
            const double_t previousValue = Utils::retrieveValue<double_t>(
                rule->getVariable(), trace, index - 1);

            if (factorRule != nullptr)
            {
                predictedValue = previousValue * factorRule->getConstant();
            }
            else if (differenceRule != nullptr)
            {
                predictedValue = previousValue + differenceRule->getConstant();
            }
        }
    }
    else
    {
        throw std::invalid_argument("Rule matches none of the implemented subclasses");
    }

    return Utils::equals(value, predictedValue, accuracy);
}
