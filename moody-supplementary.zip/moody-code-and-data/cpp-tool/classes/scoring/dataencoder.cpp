#include "dataencoder.hpp"
#include "../utils.hpp"
#include <stdexcept>
#include "../datamodel/eventlogs/logcolumn.hpp"
#include <algorithm>

DataEncoder::DataEncoder(std::shared_ptr<MdlCalculator> mdlCalculator,
                 std::shared_ptr<DistributionEstimator> distributionEstimator,
                 std::unique_ptr<RuleFinder>& ruleFinder,
                 std::unique_ptr<UpdateRuleMatcher>& ruleMatcher)
    : mdlCalculator((Utils::checkNull(mdlCalculator), mdlCalculator)),
      distributionEstimator((Utils::checkNull(distributionEstimator), distributionEstimator)),
      ruleFinder((Utils::checkNull(ruleFinder), std::move(ruleFinder))),
      ruleMatcher((Utils::checkNull(ruleMatcher), std::move(ruleMatcher)))
{
}

DataEncoder::DataEncoder(std::shared_ptr<MdlCalculator> mdlCalculator,
        std::shared_ptr<DistributionEstimator> distributionEstimator)
    : mdlCalculator((Utils::checkNull(mdlCalculator), mdlCalculator)),
      distributionEstimator((Utils::checkNull(distributionEstimator), distributionEstimator)),
      ruleFinder(std::make_unique<RuleFinder>()),
      ruleMatcher(std::make_unique<UpdateRuleMatcher>())
{
}

DataEncoder::DataEncoder(std::shared_ptr<MdlCalculator> mdlCalculator)
    : mdlCalculator((Utils::checkNull(mdlCalculator), mdlCalculator)),
      distributionEstimator(std::make_shared<DistributionEstimator>()),
      ruleFinder(std::make_unique<RuleFinder>()),
      ruleMatcher(std::make_unique<UpdateRuleMatcher>())
{
}

double_t DataEncoder::encodeEventLog(const EventLog* const log, const RuleModel* const ruleModel)
{
    Utils::checkNull(log);

    double_t result = 0.0;
    // loop over all variables
    for (const auto& variable : log->getVariables())
    {
        result += this->encodeVariable(log, ruleModel, variable);
    }

    return result;
}

double_t DataEncoder::encodeVariable(const EventLog *const log,
    const RuleModel *const ruleModel, const std::shared_ptr<LogVariable> &variable)
{
    // encode categorical variable
    const std::shared_ptr<CategoricalVariable> catVariable =
        std::dynamic_pointer_cast<CategoricalVariable>(variable);
    if (catVariable != nullptr)
    {
        return this->encodeVariableTemplated<std::string>(log, ruleModel, variable);
    }

    // encode numerical variable
    const std::shared_ptr<NumericalVariable> numVariable =
        std::dynamic_pointer_cast<NumericalVariable>(variable);
    if (numVariable != nullptr)
    {
        return this->encodeVariableTemplated<double_t>(log, ruleModel, variable);
    }

    throw std::invalid_argument("Neither categorical nor numerical variable given");
}

template<typename T> double_t DataEncoder::encodeVariableTemplated(const EventLog *const log,
    const RuleModel *const ruleModel, const std::shared_ptr<LogVariable> &variable)
{
    Utils::checkNull(log);
    Utils::checkNull(ruleModel);
    Utils::checkNull(variable);

    double_t valueStreamLength = 0.0;
    double_t ruleSelectionStreamLength = 0.0;
    ModelStreamType modelStreamCounts = {{true, 0}, {false, 0}};

    // loop over all traces
    for (const auto& tracePair : log->getTraces())
    {
        // loop over all entries in the trace
        for (size_t i = 0; i < tracePair.second->size(); i++)
        {
            // skip if we find a missing value
            if (Utils::isMissingValue(variable, tracePair.second.get(), i))
            {
                continue;
            }

            // get the rules that can be used to predict the current value
            std::vector<const ModificationRule*> rulesThatApply =
                this->ruleFinder->findRulesThatApply(
                    ruleModel, variable.get(), tracePair.second.get(), i);
            
            // no rule found => use global encoding
            if (rulesThatApply.size() == 0)
            {
                const T value = Utils::retrieveValue<T>(variable, tracePair.second.get(), i);
                valueStreamLength += this->mdlCalculator->codeUniformProbability(
                    this->distributionEstimator->getGlobalProbabilityTemplated<T>(variable, value));
            }
            // rule(s) found => encode which rule is used and encode value using it
            else
            {
                ruleSelectionStreamLength +=
                    this->mdlCalculator->codeUniformPossibilities(rulesThatApply.size());
                this->updateStreams(valueStreamLength, modelStreamCounts, this->findBestRule<T>(
                    rulesThatApply, modelStreamCounts, tracePair.second.get(), i));
            }
        }
    }

    // calculate the length of the model stream using prequential codes
    const double_t modelStreamLength = this->mdlCalculator->codePrequential(modelStreamCounts);
    return modelStreamLength + valueStreamLength + ruleSelectionStreamLength;
}

const DistributionEstimator *DataEncoder::getDistributionEstimator() const
{
    return this->distributionEstimator.get();
}

template<typename T> DataEncoder::LengthStatePair DataEncoder::encodeValueWithRule(
        const Trace* const trace, const size_t index, const UpdateRule* const rule)
{
    // determine whether value matches the rule
    const T value = Utils::retrieveValue<T>(rule->getVariable(), trace, index);
    const bool ruleMatches = this->ruleMatcher->matches(rule, trace, index);
    if (ruleMatches)
    {
        // encode value using the matching rule
        const double_t probability = this->distributionEstimator->getRuleProbabilityTemplated<T>(
            rule, value);
        return std::make_pair(this->mdlCalculator->codeUniformProbability(probability), true);
    }
    else
    {
        // encode value without the non-matching rule
        const double_t probability = this->distributionEstimator->getGlobalProbabilityTemplated<T>(
            rule->getVariable(), value);
        return std::make_pair(this->mdlCalculator->codeUniformProbability(probability), false);
    }
}

template<typename T> DataEncoder::LengthStatePair DataEncoder::findBestRule(
    const std::vector<const ModificationRule *>& rules, const ModelStreamType& modelStreamCounts,
    const Trace* const trace, const size_t traceIndex)
{
    // find out how many bits are added by encoding the value with each rule
    std::vector<double_t> bitsAdded(rules.size());
    std::vector<LengthStatePair> updateInformation(rules.size());
    for (size_t i = 0; i < rules.size(); i++)
    {
        updateInformation[i] = this->encodeValueWithRule<T>(
            trace, traceIndex, rules[i]->getUpdateRule());
        bitsAdded[i] = updateInformation[i].first + this->mdlCalculator->codeSinglePrequential(
            modelStreamCounts, updateInformation[i].second);
    }
    // find rule that adds fewest bits
    const size_t bestRuleIndex = std::distance(bitsAdded.begin(), std::min_element(
        bitsAdded.begin(), bitsAdded.end()));

    return updateInformation[bestRuleIndex];
}

void DataEncoder::updateStreams(double_t &valueStreamLength, ModelStreamType &modelStreamCounts,
    const LengthStatePair &updateInformation)
{
    valueStreamLength += updateInformation.first;
    modelStreamCounts[updateInformation.second]++;
}
