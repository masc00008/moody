#include "mdlcalculator.hpp"
#include <stdexcept>
#include <string>

double_t MdlCalculator::codeUniformProbability(const double_t probability)
{
    if (probability <= 0.0 || probability > 1.0)
    {
        throw std::domain_error("probability " + std::to_string(probability) +
            " is not in interval (0, 1]");
    }    
    return -std::log2(probability);
}

double_t MdlCalculator::codeUniformPossibilities (const int64_t possibilities)
{
    if (possibilities < 1)
    {
        throw std::domain_error("possibilities " + std::to_string(possibilities) +
            " is less than 1");
    }
    return std::log2(possibilities);
}

double_t MdlCalculator::codeBinomial (const int64_t total, const int64_t choices)
{
    if (total < 0)
    {
        throw std::domain_error("total " + std::to_string(total) + " is negative");
    }
    else if (choices < 0)
    {
        throw std::domain_error("choices " + std::to_string(choices) + " is negative");
    }
    else if (choices > total)
    {
        throw std::domain_error("choices " + std::to_string(choices) + " is larger than total " +
            std::to_string(total));
    }
    const double_t logGamma = std::lgamma((double_t) total + 1) -
        std::lgamma((double_t) total - choices + 1) - std::lgamma((double_t) choices + 1);
    return logGamma / std::log(2.0);
}

double_t MdlCalculator::codePositiveInteger (const int64_t integer)
{
    if (integer < 1)
    {
        throw std::domain_error("integer " + std::to_string(integer) + " is less than 1");
    }
    // start with constant
    double_t result = LOG_C0;
    // sum recursive logarithm terms as long as they are positive
    double_t logValue = integer;
    // break loop as soon as the value is one or less since its logarithm can only be negative
    while (logValue > 1.0)
    {
        logValue = std::log2(logValue);
        result += logValue;
    }
    return result;
}

double_t MdlCalculator::codeInteger(const int64_t integer)
{
    constexpr int64_t MIN_INPUT = INT64_MIN + 2;
    constexpr int64_t MAX_INPUT = INT64_MAX - 1;
    // check input is in the correct range
    if (integer < MIN_INPUT || integer > MAX_INPUT)
    {
        throw std::domain_error("integer " + std::to_string(integer) + " is not in range ["
            + std::to_string(MIN_INPUT) + ", " + std::to_string(MAX_INPUT) + "]");
    }
    // encode sign in one bit and then integer + 1 to properly encode 0 as well
    return 1 + this->codePositiveInteger(std::abs(integer) + 1);
}

double_t MdlCalculator::codeReal (const double_t real, const int64_t precision)
{
    this->checkPrecision(precision);
    // get absolute value, the sign is encoded later anyways
    double_t absReal = std::abs(real);
    // default shift is 0
    int64_t shift = 0;
    if (absReal < std::numeric_limits<double_t>::epsilon())
    {
        // change value to 0 if value is within double digit precision of 0
        // such small values are most likely numerical artifacts anyway
        absReal = 0.0;
    }
    else
    {
        // calculate shift for non-zero input
        // subtracting one is necessary to get significant digits instead of decimal places
        shift = (int64_t) std::ceil(precision - std::log10(absReal)) - 1;
    }
    // convert real to int with desired precision
    const int64_t intFromReal = std::ceil(absReal * std::pow(10, shift));
    // compute total code length
    const double_t result = this->codeInteger(shift) + this->codeInteger(intFromReal);
    return result;
}

template<typename T> double_t MdlCalculator::codePrequential(
    const std::unordered_map<T, int64_t>& symbolCounts, const double_t initialCount)
{
    if (initialCount <= 0.0)
    {
        throw std::domain_error("initialCount " + std::to_string(initialCount) +
            " is 0 or negative");
    }

    // catch empty vocabulary
    const int64_t vocabularySize = symbolCounts.size();
    if (vocabularySize == 0)
    {
        return 0.0;
    }

    // count elements in the sequence and add them to the current counts
    int64_t sequenceLength = 0;
    for (const auto& pair : symbolCounts)
    {
        sequenceLength += pair.second;
    }

    // implementation inspired by the appendix of
    // Wójciak, Beata Anna "Spaghetti Finding storylines in large collections of documents"
    // but corrected the sign error

    double_t logGamma = std::lgamma(initialCount * vocabularySize + sequenceLength)
        - std::lgamma(initialCount * vocabularySize)
        + vocabularySize * std::lgamma(initialCount);
    // subtract symbols
    for (const auto& pair : symbolCounts)
    {
        logGamma -= std::lgamma(initialCount + pair.second);
    }

    return logGamma / std::log(2.0);
}

template double_t MdlCalculator::codePrequential<std::string>(
    const std::unordered_map<std::string, int64_t>& symbolCounts,
    const double_t initialCount = 0.5);
template double_t MdlCalculator::codePrequential<int64_t>(
    const std::unordered_map<int64_t, int64_t>& symbolCounts,
    const double_t initialCount = 0.5);
template double_t MdlCalculator::codePrequential<bool>(
    const std::unordered_map<bool, int64_t>& symbolCounts,
    const double_t initialCount = 0.5);

template <typename T>
double_t MdlCalculator::codeSinglePrequential(const std::unordered_map<T, int64_t> &symbolCounts,
    const T newSymbol, const double_t initialCount)
{
    if (initialCount <= 0.0)
    {
        throw std::domain_error("initialCount " + std::to_string(initialCount) +
            " is 0 or negative");
    }

    if (symbolCounts.find(newSymbol) == symbolCounts.end())
    {
        throw std::invalid_argument("newSymbol is not part of symbolCounts");
    }

    // compute total count of all symbols as normalizer
    double_t normalizer = symbolCounts.size() * initialCount;
    for (const auto& pair : symbolCounts)
    {
        normalizer += pair.second;
    }

    return this->codeUniformProbability((symbolCounts.at(newSymbol) + initialCount) / normalizer);
}

template double_t MdlCalculator::codeSinglePrequential(
    const std::unordered_map<std::string, int64_t> &symbolCounts, const std::string newSymbol,
    const double_t initialCount);
template double_t MdlCalculator::codeSinglePrequential(
    const std::unordered_map<int64_t, int64_t> &symbolCounts, const int64_t newSymbol,
    const double_t initialCount);
template double_t MdlCalculator::codeSinglePrequential(
    const std::unordered_map<bool, int64_t> &symbolCounts, const bool newSymbol,
    const double_t initialCount);

void MdlCalculator::checkPrecision(const int64_t precision)
{
    if (precision < 0 || precision > DBL_DIG)
    {
        throw std::domain_error("precision " + std::to_string(precision) +
            " is not in interval [0, " + std::to_string(DBL_DIG) + "]");
    }
}
