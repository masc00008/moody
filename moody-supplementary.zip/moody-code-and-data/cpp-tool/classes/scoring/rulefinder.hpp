#pragma once
#include <vector>
#include <memory>
#include "conditionmatcher.hpp"
#include "../datamodel/modificationrule.hpp"
#include "../datamodel/rulemodel.hpp"
#include "../datamodel/eventlogs/trace.hpp"
#include "../datamodel/eventlogs/logvariable.hpp"

/// @brief Filters the rules in the model to those that apply at the current position in a trace
class RuleFinder
{
    private:
    ConditionMatcher matcher;

    public:
    /// @brief Determines whether a rule applies in the current context
    /// @param rule pointer to the rule to check
    /// @param targetVariable pointer to which variable is considered for the update rule
    /// @param trace pointer to the current event log trace for the data values checked against
    /// the condition
    /// @param index where in the trace to check the data against the condition
    /// @return whether the rule applies
    bool checkRuleApplies(const ModificationRule* rule, const LogVariable* const targetVariable,
        const Trace* const trace, size_t index);
    
    /// @brief Filters the rule model for those rules that apply in the current context
    /// @param ruleModel pointer to rule model to get ModificationRules from, not null
    /// @param targetVariable pointer to which variable should be targeted in the update rule, not null
    /// @param trace pointer to the current event log trace for the data values checked against
    /// the condition, not null
    /// @param index where in the trace to check the data against the condition, in the range of the trace
    /// @return 
    virtual std::vector<const ModificationRule*> findRulesThatApply(
        const RuleModel* const ruleModel, const LogVariable* const targetVariable,
        const Trace* const trace, size_t index);
    
    virtual ~RuleFinder() = default;
};
