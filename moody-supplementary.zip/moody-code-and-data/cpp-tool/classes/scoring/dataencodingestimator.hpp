#pragma once
#include "../datamodel/updaterules/updaterule.hpp"
#include "../preprocessing/distributionestimator.hpp"
#include "mdlcalculator.hpp"

/// @brief Quickly estimates how many bits can be saved with an update rule to remove candidate
/// rules early without computing the complete MDL score
class DataEncodingEstimator
{
    private:
    /// @brief member for getting MDL codes
    std::shared_ptr<MdlCalculator> mdlCalculator;
    /// @brief member for estimating distributions in the event log
    std::shared_ptr<DistributionEstimator> distributionEstimator;

    /// @brief Checks whether two values fall into the same bin/category of the histogram
    /// @param histogram histograms whose bins are used
    /// @param value1 first value
    /// @param value2 second value
    /// @return true if both values fall into the same bin, false otherwise
    bool fallsIntoSameBin(const Histogram& histogram, const double_t value1, const double_t value2);
    /// @brief Checks whether two ranges of values have some intersection
    /// @param min1 start of the first range
    /// @param max1 end of the first range
    /// @param min2 start of the second range
    /// @param max2 end of the second range
    /// @return true if ranges intersect, false otherwise
    bool rangesIntersect(
        const double_t min1, const double_t max1, const double_t min2, const double_t max2);
    /// @brief Computes the smallest and largest value that can practically occur in a
    /// histogram bin. Takes into consideration that bin limits are placed inbetween the
    /// accuracy grid.
    /// @param histogram histogram to get the bin from
    /// @param value value to get the bin for
    /// @param accuracy smallest meaningful difference between two values 
    /// @return pair of smallest and largest practical value in the bin
    std::pair<double_t, double_t> getBinValueRange(
        const Histogram& histogram, const double_t value,
        const double_t& accuracy);
    /// @brief Determines whether the given value (or an equivalent one accoring to the histogram)
    /// could potentially be compressed using the update rule.
    /// @tparam T data type of the value (double_t or std::string)
    /// @param value value that could be compressed
    /// @param rule update rule used to compress
    /// @return true if compression is potentially possible, false otherwise
    template<typename T> bool binMatchesRule (const T& value, const UpdateRule* const rule);
    /// @brief Computes how many bits can be saved by encoding the samples with the update rule
    /// instead of the global distribution
    /// @tparam T data type of the values (double_t or std::string)
    /// @param valueCounts multimap with key=probability and value=pair of frequency and data value
    /// @param numberOfSamples how many samples are encoded by the update rule in the best case
    /// @param rule the update rule used to encode samples
    /// @return optimistic estimate of saved bits
    template<typename T> double_t estimateSavedBitsThroughSamples(
        const std::multimap<double_t, std::pair<int64_t, T>>& valueCounts,
        const int64_t numberOfSamples,
        const UpdateRule* const rule);

    public:
    DataEncodingEstimator(std::shared_ptr<MdlCalculator> mdlCalculator,
        std::shared_ptr<DistributionEstimator> distributionEstimator);
    /// @brief Computes how many bits can be saved by encoding the samples with the update rule
    /// instead of the global distribution
    /// @param rule the update rule used to encode samples
    /// @param coveredSamples how many samples are encoded by the update rule in the best case
    /// @return optimistic estimate of saved bits
    double_t estimateSavedBits (const UpdateRule* const rule, const int64_t coveredSamples);
};
