#include "rulefinder.hpp"
#include "../utils.hpp"
#include <algorithm>
#include "../datamodel/updaterules/factorrule.hpp"
#include "../datamodel/updaterules/differencerule.hpp"
#include "../datamodel/updaterules/changerangerule.hpp"

bool RuleFinder::checkRuleApplies(const ModificationRule* rule,
        const LogVariable* const targetVariable, const Trace* const trace, size_t index)
{
    const auto factorRule = dynamic_cast<const FactorRule*>(rule->getUpdateRule());
    const auto differenceRule = dynamic_cast<const DifferenceRule*>(rule->getUpdateRule());
    const auto changeRangeRule = dynamic_cast<const ChangeRangeRule*>(rule->getUpdateRule());

    const bool needsPreviousValue =
        factorRule != nullptr || differenceRule != nullptr || changeRangeRule != nullptr;
    const bool hasPreviousValue = index != 0
        && !Utils::isMissingValue(rule->getUpdateRule()->getVariable(), trace, index - 1);

    const bool hasTarget = rule->getUpdateRule()->getVariable().get() == targetVariable;
    const bool conditionMatches = this->matcher.matches(rule->getCondition(), trace, index);

    // needsPreviousValue implies hasPreviousValue
    return (!needsPreviousValue || hasPreviousValue) && hasTarget && conditionMatches;
}

std::vector<const ModificationRule*> RuleFinder::findRulesThatApply(
        const RuleModel* const ruleModel, const LogVariable* const targetVariable,
        const Trace* const trace, size_t index)
{
    Utils::checkNull(ruleModel);
    Utils::checkNull(targetVariable);

    std::vector<const ModificationRule*> filteredRules;
    std::vector<const ModificationRule*> allRules = ruleModel->getRules();
    std::copy_if(allRules.begin(), allRules.end(), std::back_inserter(filteredRules), 
        [=](const ModificationRule* rule){return this->checkRuleApplies(rule, targetVariable, trace, index);});

    return filteredRules;
}
