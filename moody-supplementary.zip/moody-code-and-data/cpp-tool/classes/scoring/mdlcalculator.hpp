#pragma once
#include <cstdint>
#include <cmath>
#include <unordered_map>
#include <float.h>

/// @brief Bundles several utility functions for computing code lengths for the
/// Minimum Description Length (MDL) principle.
class MdlCalculator
{
    private:
    /// @brief Constant used to satisfy Kraft's inequality for the positive integer code
    static constexpr double_t C0 = 2.865064;
    /// @brief Base 2 logarithm of the constant used to satisfy Kraft's inequality for the
    /// positive integer code
    static constexpr double_t LOG_C0 = std::log2(C0);

    public:
    /// @brief Calculates the code length for a random variable from a uniform distribution
    /// @param probability how likely each value of the random variable occurs, in interval (0, 1]
    /// @return code length to transmit a value of the random variable
    virtual double_t codeUniformProbability (const double_t probability);

    /// @brief Calculates the code length for a random variable from a uniform distribution
    /// @param possibilities how many equally likely values the random variable has, at least 1
    /// @return code length to transmit a value of the random variable
    virtual double_t codeUniformPossibilities (const int64_t possibilities);

    /// @brief Calculates the code length for a binomial coefficient choose(n, k)
    /// @param total the total number of possibilites (n), at least 0
    /// @param choices the number of choices (k), at least 0 and <= n
    /// @return code length to transmit which of the possible choices was used
    virtual double_t codeBinomial (const int64_t total, const int64_t choices);

    /// @brief Calculates the code length for an unbounded positive integer
    /// @param integer the integer to encode, at least 1
    /// @return code length to transmit the integer
    virtual double_t codePositiveInteger (const int64_t integer);

    /// @brief Calculates the code length for a general unbounded integer
    /// @param integer the integer to encode, in range [INT64_MIN + 2, INT64_MAX - 1]
    /// @return code length to transmit the integer
    virtual double_t codeInteger (const int64_t integer);

    /// @brief Calculates the code length for an unbounded real number at a certain precision.
    /// If the absolute input value is less than 10^-DBL_DIG, it will be set to 0.
    /// @param real any real number to encode
    /// @param precision number of decimal significant digits to encode, in interval [0, DBL_DIG]
    /// @return code length to transmit the real number
    virtual double_t codeReal (const double_t real, const int64_t precision);

    /// @brief Calculates the prequential code length of a sequence
    /// A prequential code assumes that initially nothing about the distribution of the symbols
    /// in the sequence is known. Therefore, a uniform distribution is assumed initially. This
    /// distribution is then updated after each symbol was transmitted. This prequential code
    /// implementation is stateless, i.e. all sequences are encoded independent of one another.
    /// @tparam T data type of the symbols transmitted in the sequence
    /// @param symbolCounts dictionary of all symbols with their respective frequencies in the sequence
    /// @param initialCount how many times each symbol is assumed to be observed before actually
    /// observing any symbol (also called smoothing parameter or epsilon), has to be larger than 0
    /// @return encoding length of the complete sequence in bits
    template<typename T> double_t codePrequential(
        const std::unordered_map<T, int64_t>& symbolCounts,
        const double_t initialCount = 0.5);

    /// @brief Calculates the prequential code length of a single symbol
    /// @tparam T data type of the symbols transmitted in the sequence 
    /// @param symbolCounts dictionary of all symbols with their respective frequencies in the
    /// sequence so far
    /// @param newSymbol the new/next symbol to be transmitted (and to compute the code length for)
    /// @param initialCount how many times each symbol is assumed to be observed before actually
    /// observing any symbol (also called smoothing parameter or epsilon), has to be larger than 0 
    /// @return encoding length of the symbol in bits
    template<typename T> double_t codeSinglePrequential(
        const std::unordered_map<T, int64_t>& symbolCounts,
        const T newSymbol, const double_t initialCount = 0.5);

    /// @brief Verifies that the given precision value is inside the allowed interval [0, DBL_DIG].
    /// Throws an exception if the interval is violated.
    /// @param precision precision value to verify
    virtual void checkPrecision(const int64_t precision);
};