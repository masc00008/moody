#pragma once
#include "../datamodel/rulemodel.hpp"
#include "../datamodel/modificationrule.hpp"
#include "../datamodel/updaterules/updaterule.hpp"
#include "../datamodel/conditions/condition.hpp"
#include "../datamodel/eventlogs/categoricalvariable.hpp"
#include "mdlcalculator.hpp"
#include <cmath>
#include <memory>

/// @brief Bundles functionality to calculate the MDL code length of the model L(M)
class ModelEncoder
{
    private:
    /// @brief Object used to perform primitive MDL calculations
    std::shared_ptr<MdlCalculator> calc;
    /// @brief The number of variables in the event log
    int64_t numberOfVariables;
    /// @brief The number of decimal significant digits to encode real numbers, in interval [0, DBL_DIG]
    int64_t precision;
    /// @brief How many different types of update rules exist
    const int64_t numberOfUpdateRuleTypes = 6;
    /// @brief How many different types of condition elements exist
    const int64_t numberOfConditionElementTypes = 7;

    public:
    /// @brief Creates a new ModelEncoder
    /// @param calc Object to perform primitive MDL calculations
    /// @param numberOfVariables The number of variables in the event log
    /// @param precision The number of decimal significant digits to encode real numbers, in interval [0, DBL_DIG]
    ModelEncoder(const std::shared_ptr<MdlCalculator> calc, const int64_t numberOfVariables,
        const int64_t precision = 8);

    /// @brief Calculates the code length that is needed in addition after adding the
    /// modification rule to the rule model
    /// @param ruleModel baseline model of modification rules
    /// @param modificationRule new rule that is about to be added to the rule model
    /// @return how many more bits are needed to encode the model with the new modification rule
    virtual double_t encodeAdditionalModificationRule(
        const RuleModel* const ruleModel, const ModificationRule* const modificationRule);
    /// @brief Calculates the code length for the given rule model
    /// @param ruleModel model to calculate the code length for
    /// @return the model's code length in bits
    virtual double_t encodeRuleModel(const RuleModel* const ruleModel);
    /// @brief Calculates the code length for the given modification rule
    /// @param modificationRule modification rule to calculate the code length for
    /// @return the modification rule's code length in bits
    virtual double_t encodeModificationRule(const ModificationRule* const modificationRule);
    /// @brief Calculates the code length for the given update rule
    /// @param updateRule update rule to calculate the code length for
    /// @return the update rule's code length in bits
    virtual double_t encodeUpdateRule(const UpdateRule* const updateRule);
    /// @brief Calculates the code length for the given condition
    /// @param condition condition to calculate the code length for
    /// @return the condition's code length in bits
    virtual double_t encodeCondition(const Condition* const condition);
};
