#pragma once
#include <float.h>
#include "../datamodel/eventlogs/trace.hpp"
#include "../datamodel/updaterules/valuesetrule.hpp"
#include "../datamodel/updaterules/abstractrangerule.hpp"
#include "../datamodel/updaterules/abstractvaluerule.hpp"

/// @brief Checks whether the values in a trace match an update rule
class UpdateRuleMatcher
{
    public:
    /// @brief Checks whether the rule matches the data in the trace at the given index
    /// @param rule pointer to update rule to check, not null
    /// @param trace pointer to trace to get the data from, not null
    /// @param index which element in the trace should be checked, in range of the trace
    /// @return whether the rule matches
    virtual bool matches(const UpdateRule* const rule, const Trace* const trace, size_t index);
    /// @brief Checks whether the rule matches the data in the trace at the given index
    /// @param rule pointer to update rule to check, not null
    /// @param trace pointer to trace to get the data from, not null
    /// @param index which element in the trace should be checked, in range of the trace
    /// @return whether the rule matches
    virtual bool matches(const ValueSetRule* const rule, const Trace* const trace, size_t index);
    /// @brief Checks whether the rule matches the data in the trace at the given index
    /// @param rule pointer to update rule to check, not null
    /// @param trace pointer to trace to get the data from, not null
    /// @param index which element in the trace should be checked, in range of the trace
    /// @return whether the rule matches
    virtual bool matches(const AbstractRangeRule* const rule, const Trace* const trace, size_t index);
    /// @brief Checks whether the rule matches the data in the trace at the given index
    /// @param rule pointer to update rule to check, not null
    /// @param trace pointer to trace to get the data from, not null
    /// @param index which element in the trace should be checked, in range of the trace
    /// @return whether the rule matches
    virtual bool matches(const AbstractValueRule* const rule, const Trace* const trace, size_t index);

    virtual ~UpdateRuleMatcher() = default;
};
