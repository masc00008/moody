#include "conditionmatcher.hpp"
#include "../utils.hpp"
#include <stdexcept>
#include <stack>
#include "../datamodel/conditions/valuecondition.hpp"
#include "../datamodel/conditions/upperboundcondition.hpp"
#include "../datamodel/conditions/lowerboundcondition.hpp"
#include "../datamodel/conditions/andoperator.hpp"
#include "../datamodel/conditions/oroperator.hpp"
#include "../datamodel/conditions/notoperator.hpp"
#include "../datamodel/eventlogs/logcolumn.hpp"

bool ConditionMatcher::matches(
    const AtomicCondition* const condition, const Trace* const trace, size_t index)
{
    Utils::checkNull(condition);
    Utils::checkNull(trace);
    Utils::checkIndex(
        trace, std::set<std::shared_ptr<LogVariable>>{condition->getVariable()}, index);

    const AbstractValueCondition<double_t>* numValueCondition =
        dynamic_cast<const AbstractValueCondition<double_t>*>(condition);
    if (numValueCondition != nullptr)
    {
        return this->matches(numValueCondition, trace, index);
    }

    const AbstractValueCondition<std::string>* catValueCondition =
        dynamic_cast<const AbstractValueCondition<std::string>*>(condition);
    if (catValueCondition != nullptr)
    {
        return this->matches(catValueCondition, trace, index);
    }

    const TransitionCondition<double_t>* numTransitionCondition = 
        dynamic_cast<const TransitionCondition<double_t>*>(condition);
    if (numTransitionCondition != nullptr)
    {
        return this->matches(numTransitionCondition, trace, index);
    }

    const TransitionCondition<std::string>* catTransitionCondition = 
        dynamic_cast<const TransitionCondition<std::string>*>(condition);
    if (catTransitionCondition != nullptr)
    {
        return this->matches(catTransitionCondition, trace, index);
    }

    throw std::invalid_argument("Condition matches none of the implemented types");
}

template<typename T> bool ConditionMatcher::matches(
    const TransitionCondition<T>* const condition, const Trace* const trace, size_t index)
{
    Utils::checkNull(condition);
    Utils::checkNull(trace);
    Utils::checkIndex(
        trace, std::set<std::shared_ptr<LogVariable>>{condition->getVariable()}, index);

    if (index == 0)
    {
        return false;
    }

    const T currentValue = Utils::retrieveValue<T>(condition->getVariable(), trace, index);
    const T previousValue = Utils::retrieveValue<T>(condition->getVariable(), trace, index - 1);
    const double_t accuracy = condition->getVariable()->getAccuracy();

    return Utils::equals(condition->getBefore(), previousValue, accuracy)
        && Utils::equals(condition->getAfter(), currentValue, accuracy);
}

template bool ConditionMatcher::matches<double_t>(
    const TransitionCondition<double_t>* const condition, const Trace* const trace, size_t index);
template bool ConditionMatcher::matches<std::string>(
    const TransitionCondition<std::string>* const condition, const Trace* const trace, size_t index);

template<typename T> bool ConditionMatcher::matches(
    const AbstractValueCondition<T>* const condition, const Trace* const trace, size_t index)
{
    Utils::checkNull(condition);
    Utils::checkNull(trace);

    const T value = Utils::retrieveValue<T>(condition->getVariable(), trace, index);
    const double_t accuracy = condition->getVariable()->getAccuracy();

    const ValueCondition<T>* valueCondition = dynamic_cast<const ValueCondition<T>*>(condition);
    if (valueCondition != nullptr)
    {
        return Utils::equals(valueCondition->getValue(), value, accuracy);
    }

    return this->matchesBoundConditions(condition, value);
}

template bool ConditionMatcher::matches<double_t>(
    const AbstractValueCondition<double_t>* const condition, const Trace* const trace, size_t index);
template bool ConditionMatcher::matches<std::string>(
    const AbstractValueCondition<std::string>* const condition, const Trace* const trace, size_t index);

bool ConditionMatcher::matchesBoundConditions(
        const AbstractValueCondition<double_t>* const condition, const double_t value)
{
    const double_t accuracy = condition->getVariable()->getAccuracy();
    const LowerBoundCondition* lowerBoundCondition = dynamic_cast<const LowerBoundCondition*>(condition);
    if (lowerBoundCondition != nullptr)
    {
        return Utils::lessEqual(lowerBoundCondition->getValue(), value, accuracy);
    }

    const UpperBoundCondition* upperBoundCondition = dynamic_cast<const UpperBoundCondition*>(condition);
    if (upperBoundCondition != nullptr)
    {
        return Utils::lessEqual(value, upperBoundCondition->getValue(), accuracy);
    }

    throw std::invalid_argument("Condition matches none of the implemented types");
}

bool ConditionMatcher::matchesBoundConditions(
        const AbstractValueCondition<std::string>* const condition, const std::string value)
{
    throw std::invalid_argument("Condition matches none of the implemented types");
}

bool ConditionMatcher::matches(
    const Condition* const condition, const Trace* const trace, size_t index)
{
    Utils::checkNull(condition);
    Utils::checkNull(trace);
    Utils::checkIndex(trace, condition->getVariables(), index);

    // empty condition always matches
    if (condition->getElements().size() == 0)
    {
        return true;
    }

    // never match for missing value
    for (const auto& element : condition->getElements())
    {
        auto atomicCondition = dynamic_cast<const AtomicCondition*>(element.get());
        // current value is missing
        if (atomicCondition != nullptr &&
            Utils::isMissingValue(atomicCondition->getVariable(), trace, index))
        {
            return false;
        }

        auto numTransitionCondition =
            dynamic_cast<const TransitionCondition<double_t>*>(element.get());
        auto catTransitionCondition =
            dynamic_cast<const TransitionCondition<std::string>*>(element.get());
        // previous value for a transition condition is missing
        if ((numTransitionCondition != nullptr || catTransitionCondition != nullptr) &&
            (index == 0 || Utils::isMissingValue(atomicCondition->getVariable(), trace, index - 1)))
        {
            return false;
        }
    }

    // use stack to process formula in postfix notation
    std::stack<bool> computationStack;
    for (const auto& element : condition->getElements())
    {
        // evaluate atomic condition and add result to stack
        const AtomicCondition* atom = dynamic_cast<const AtomicCondition*>(element.get());
        if (atom != nullptr)
        {
            computationStack.push(this->matches(atom, trace, index));
        }

        // apply unary operator (NOT) to operand
        auto notOperator = dynamic_cast<const NotOperator*>(element.get());
        if (notOperator != nullptr)
        {
            if (computationStack.size() < 1)
            {
                throw std::invalid_argument("Not enough operands for operator");
            }

            const bool operand = computationStack.top();
            computationStack.pop();

            computationStack.push(!operand);
        }

        // combine operands with binary operator
        const AndOperator* andOperator = dynamic_cast<const AndOperator*>(element.get());
        const OrOperator* orOperator = dynamic_cast<const OrOperator*>(element.get());
        if (andOperator != nullptr || orOperator != nullptr)
        {
            if (computationStack.size() < 2)
            {
                throw std::invalid_argument("Not enough operands for operator");
            }

            // get operands from stack
            bool operand1 = computationStack.top();
            computationStack.pop();
            bool operand2 = computationStack.top();
            computationStack.pop();

            // compute result
            bool result;
            if (andOperator != nullptr)
            {
                result = operand1 && operand2;
            }
            else if (orOperator != nullptr)
            {
                result = operand1 || operand2;
            }

            // add result to stack
            computationStack.push(result);
        }
    }

    if (computationStack.size() != 1)
    {
        throw std::invalid_argument("Not enough operators for operands");
    }

    return computationStack.top();
}
