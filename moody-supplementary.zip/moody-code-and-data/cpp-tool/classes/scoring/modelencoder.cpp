#include "modelencoder.hpp"
#include "../utils.hpp"
#include "../datamodel/updaterules/valuesetrule.hpp"
#include "../datamodel/updaterules/abstractrangerule.hpp"
#include "../datamodel/updaterules/abstractvaluerule.hpp"
#include "../datamodel/conditions/atomiccondition.hpp"
#include "../datamodel/conditions/abstractvaluecondition.hpp"
#include "../datamodel/conditions/transitioncondition.hpp"
#include <stdexcept>

ModelEncoder::ModelEncoder(const std::shared_ptr<MdlCalculator> calc,
        const int64_t numberOfVariables, const int64_t precision)
    : calc((Utils::checkNull(calc), calc)),
    numberOfVariables(numberOfVariables),
    precision(precision)
{
    this->calc->checkPrecision(precision);
}

double_t ModelEncoder::encodeAdditionalModificationRule(const RuleModel *const ruleModel,
    const ModificationRule *const modificationRule)
{
    Utils::checkNull(ruleModel);
    Utils::checkNull(modificationRule);

    const double_t bitsForModelLength =
        this->calc->codePositiveInteger(ruleModel->getRules().size() + 2)
        - this->calc->codePositiveInteger(ruleModel->getRules().size() + 1);
    return this->encodeModificationRule(modificationRule) + bitsForModelLength;
}

double_t ModelEncoder::encodeRuleModel(const RuleModel* const ruleModel)
{
    Utils::checkNull(ruleModel);
    double_t result = this->calc->codePositiveInteger(ruleModel->getRules().size() + 1);
    for (const auto& rule : ruleModel->getRules())
    {
        result += this->encodeModificationRule(rule);
    }
    return result;
}

double_t ModelEncoder::encodeModificationRule(const ModificationRule* const modificationRule)
{
    Utils::checkNull(modificationRule);
    return this->encodeCondition(modificationRule->getCondition()) +
        this->encodeUpdateRule(modificationRule->getUpdateRule());
}

double_t ModelEncoder::encodeUpdateRule(const UpdateRule* const updateRule)
{
    Utils::checkNull(updateRule);
    double_t result = this->calc->codeUniformPossibilities(this->numberOfUpdateRuleTypes) +
        this->calc->codeUniformPossibilities(this->numberOfVariables);

    // calculation for ValueSetRule
    const ValueSetRule* valueSetRule = dynamic_cast<const ValueSetRule*>(updateRule);
    if (valueSetRule != nullptr)
    {
        const std::shared_ptr<CategoricalVariable> variable = 
            std::static_pointer_cast<CategoricalVariable>(valueSetRule->getVariable());
        result += this->calc->codeUniformPossibilities(variable->getDomain().size() - 1);
        result += this->calc->codeBinomial(variable->getDomain().size(), valueSetRule->getSet().size());
        return result;
    }

    // calculation for range rules
    const AbstractRangeRule* rangeRule = dynamic_cast<const AbstractRangeRule*>(updateRule);
    if (rangeRule != nullptr)
    {
        result += this->calc->codeReal(rangeRule->getMin(), this->precision);
        result += this->calc->codeReal(rangeRule->getMax(), this->precision);
        return result;
    }

    // calculation for value rules
    const AbstractValueRule* valueRule = dynamic_cast<const AbstractValueRule*>(updateRule);
    if (valueRule != nullptr)
    {
        result += this->calc->codeReal(valueRule->getConstant(), this->precision);
        return result;
    }

    throw std::invalid_argument("UpdateRule is not member of any implemented subclass");
}

double_t ModelEncoder::encodeCondition(const Condition* const condition)
{
    Utils::checkNull(condition);
    const double_t numConditions = condition->getElements().size();
    double_t result = this->calc->codePositiveInteger(numConditions + 1) +
        numConditions * this->calc->codeUniformPossibilities(this->numberOfConditionElementTypes);

    // loop over all elements while counting the number of atomic conditions
    double_t atomicConditionCounter = 0;
    for (const auto& element : condition->getElements())
    {
        const AtomicCondition* atom = dynamic_cast<const AtomicCondition*>(element.get());
        if (atom != nullptr)
        {
            atomicConditionCounter++;

            // numeric value condition
            const AbstractValueCondition<double_t>* numValueCondition =
                dynamic_cast<const AbstractValueCondition<double_t>*>(atom);
            if (numValueCondition != nullptr)
            {
                result += this->calc->codeReal(numValueCondition->getValue(), this->precision);
                continue;
            }

            // categorical value condition
            const AbstractValueCondition<std::string>* catValueCondition =
                dynamic_cast<const AbstractValueCondition<std::string>*>(atom);
            if (catValueCondition != nullptr)
            {
                const std::shared_ptr<CategoricalVariable> variable = 
                    std::static_pointer_cast<CategoricalVariable>(catValueCondition->getVariable());
                result += this->calc->codeUniformPossibilities(variable->getDomain().size());
                continue;
            }

            // numeric transition condition
            const TransitionCondition<double_t>* numTransitionCondition =
                dynamic_cast<const TransitionCondition<double_t>*>(atom);
            if (numTransitionCondition != nullptr)
            {
                result += this->calc->codeReal(numTransitionCondition->getBefore(), this->precision);
                result += this->calc->codeReal(numTransitionCondition->getAfter(), this->precision);
                continue;
            }

            // categorical transition condition
            const TransitionCondition<std::string>* catTransitionCondition =
                dynamic_cast<const TransitionCondition<std::string>*>(atom);
            if (catTransitionCondition != nullptr)
            {
                const std::shared_ptr<CategoricalVariable> variable = 
                    std::static_pointer_cast<CategoricalVariable>(catTransitionCondition->getVariable());
                result += 2 * this->calc->codeUniformPossibilities(variable->getDomain().size());
            }
        }
    }
    
    // add code lengths that are identical for all atomic conditions
    result += atomicConditionCounter * this->calc->codeUniformPossibilities(this->numberOfVariables);

    return result;
}
