#include "../datamodel/conditions/condition.hpp"
#include "../datamodel/conditions/atomiccondition.hpp"
#include "../datamodel/conditions/transitioncondition.hpp"
#include "../datamodel/conditions/abstractvaluecondition.hpp"
#include "../datamodel/eventlogs/trace.hpp"

/// @brief Used to check whether conditions match at a certain index in a trace
class ConditionMatcher
{
    private:
    /// @brief Checks whether a bound condition matches a value
    /// @param condition pointer to a bound condition, throws an exception otherwise
    /// @param value value to check the bound against
    /// @return whether the bound condition matches the value
    bool matchesBoundConditions(
        const AbstractValueCondition<double_t>* const condition, const double_t value);
    /// @brief Overload to satisfy the templated function, just throws an exception
    /// @param condition ignored
    /// @param value ignored
    /// @return nothing
    bool matchesBoundConditions(
        const AbstractValueCondition<std::string>* const condition, const std::string value);

    public:
    /// @brief Checks whether a condition matches at a certain index in the trace
    /// @param condition pointer to condition to check, not null
    /// @param trace pointer to trace to get values from, not null
    /// @param index where in the trace to get the value from
    /// @return whether the condition matches
    bool matches(const AtomicCondition* const condition, const Trace* const trace, size_t index);
    /// @brief Checks whether a condition matches at a certain index in the trace
    /// @param condition pointer to condition to check, not null
    /// @param trace pointer to trace to get values from, not null
    /// @param index where in the trace to get the value from
    /// @return whether the condition matches
    template<typename T> bool matches(
        const TransitionCondition<T>* const condition, const Trace* const trace, size_t index);
    /// @brief Checks whether a condition matches at a certain index in the trace
    /// @param condition pointer to condition to check, not null
    /// @param trace pointer to trace to get values from, not null
    /// @param index where in the trace to get the value from
    /// @return whether the condition matches
    template<typename T> bool matches(
        const AbstractValueCondition<T>* const condition, const Trace* const trace, size_t index);
    /// @brief Checks whether a condition matches at a certain index in the trace
    /// @param condition pointer to condition to check, not null
    /// @param trace pointer to trace to get values from, not null
    /// @param index where in the trace to get the value from
    /// @return whether the condition matches
    bool matches(const Condition* const condition, const Trace* const trace, size_t index);
};
