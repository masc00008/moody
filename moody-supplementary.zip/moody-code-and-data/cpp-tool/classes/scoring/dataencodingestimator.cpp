#include "dataencodingestimator.hpp"
#include "../datamodel/updaterules/valuerule.hpp"
#include "../datamodel/updaterules/differencerule.hpp"
#include "../datamodel/updaterules/factorrule.hpp"
#include "../datamodel/updaterules/valuerangerule.hpp"
#include "../datamodel/updaterules/changerangerule.hpp"
#include <stdexcept>
#include "../utils.hpp"

DataEncodingEstimator::DataEncodingEstimator(std::shared_ptr<MdlCalculator> mdlCalculator,
        std::shared_ptr<DistributionEstimator> distributionEstimator)
    : mdlCalculator((Utils::checkNull(mdlCalculator), mdlCalculator)),
    distributionEstimator((Utils::checkNull(distributionEstimator), distributionEstimator))
{
}

bool DataEncodingEstimator::fallsIntoSameBin(
    const Histogram &histogram, const double_t value1, const double_t value2)
{
    return histogram.getBinLimits(value1) == histogram.getBinLimits(value2);
}

bool DataEncodingEstimator::rangesIntersect(
    const double_t min1, const double_t max1, const double_t min2, const double_t max2)
{
    if (min1 > max1 || min2 > max2)
    {
        throw std::invalid_argument("Ranges for intersection are malformed");
    }
    return min1 <= max2 && min2 <= max1;
}

std::pair<double_t, double_t> DataEncodingEstimator::getBinValueRange(
    const Histogram &histogram, const double_t value,
    const double_t& accuracy)
{
    const std::pair<double_t, double_t> range = histogram.getBinLimits(value);
    const double_t offset = accuracy / 2;
    double_t min = range.first + offset;
    double_t max = range.second - offset;
    // swap values if range collapses and has floating point errors
    if (min > max)
    {
        const double_t buffer = min;
        min = max;
        max = buffer;
    }
    return std::make_pair(min, max);
}

template <typename T>
bool DataEncodingEstimator::binMatchesRule(const T &value, const UpdateRule *const rule)
{
    if (!Utils::variableTypeMatches<T>(rule->getVariable()))
    {
        throw std::invalid_argument("Template type and variable type mismatch");
    }

    if constexpr (std::is_same_v<T, std::string>)
    {
        // check whether value is part of the set
        auto valueSetRule = static_cast<const ValueSetRule*>(rule);
        return valueSetRule->getSet().find(value) != valueSetRule->getSet().end();
    }

    if constexpr (std::is_same_v<T, double_t>)
    {
        const auto numVariable =
            std::static_pointer_cast<NumericalVariable>(rule->getVariable());
        const Histogram& histogram =
            this->distributionEstimator->getNumericalDistribution(numVariable);
        const std::pair<double_t, double_t> histogramRange = histogram.getRange();

        auto valueRule = dynamic_cast<const ValueRule*>(rule);
        if (valueRule != nullptr)
        {
            // check whether given value and predicted value fall into the same bin
            return this->fallsIntoSameBin(histogram, value, valueRule->getConstant());
        }

        std::pair<double_t, double_t> binValueRange =
            this->getBinValueRange(histogram, value, numVariable->getAccuracy());
        auto rangeRule = dynamic_cast<const ValueRangeRule*>(rule);
        if (rangeRule != nullptr)
        {
            // check whether some value in the bin is also in the range of the rule
            return this->rangesIntersect(binValueRange.first, binValueRange.second,
                rangeRule->getMin(), rangeRule->getMax());
        }

        auto differenceRule = dynamic_cast<const DifferenceRule*>(rule);
        if (differenceRule != nullptr)
        {
            const double_t previousValueMin = binValueRange.first - differenceRule->getConstant();
            const double_t previousValueMax = binValueRange.second - differenceRule->getConstant();
            // check whether smallest or largest previous value is possible in principle
            // (in the range of the histogram)
            return this->rangesIntersect(histogramRange.first, histogramRange.second,
                previousValueMin, previousValueMax);
        }

        auto factorRule = dynamic_cast<const FactorRule*>(rule);
        if (factorRule != nullptr)
        {
            double_t previousValueMin = binValueRange.first / factorRule->getConstant();
            double_t previousValueMax = binValueRange.second / factorRule->getConstant();
            // swap bounds for negative factor that flips them in the first place
            if (previousValueMin > previousValueMax)
            {
                const double_t buffer = previousValueMax;
                previousValueMax = previousValueMin;
                previousValueMin = buffer;
            }
            // check whether smallest or largest previous value is possible in principle
            // (in the range of the histogram)
            return this->rangesIntersect(histogramRange.first, histogramRange.second,
                previousValueMin, previousValueMax);
        }

        auto changeRangeRule = dynamic_cast<const ChangeRangeRule*>(rule);
        if (changeRangeRule != nullptr)
        {
            const double_t previousValueMin = binValueRange.first - changeRangeRule->getMax();
            const double_t previousValueMax = binValueRange.second - changeRangeRule->getMin();
            // check whether smallest or largest previous value is possible in principle
            // (in the range of the histogram)
            return this->rangesIntersect(histogramRange.first, histogramRange.second,
                previousValueMin, previousValueMax);
        }
    }

    throw std::invalid_argument("Type of update rule not supported");
}

template <typename T> double_t DataEncodingEstimator::estimateSavedBitsThroughSamples(
    const std::multimap<double_t, std::pair<int64_t, T>>& valueCounts,
    const int64_t numberOfSamples,
    const UpdateRule *const rule)
{
    double_t savedBits = 0.0;
    int64_t samplesToCover = numberOfSamples;
    // cover all samples starting with the least likely bins in the distribution (saves most bits)
    for (const auto& [probability, countValuePair] : valueCounts)
    {
        const auto& count = countValuePair.first;
        const auto& value = countValuePair.second;

        // exit loop when all samples were covered
        if (samplesToCover == 0)
        {
            break;
        }
        // we can only use a bin if its value(s) are compressible by the rule
        else if (this->binMatchesRule(value, rule))
        {
            // determine how many bits are required to encode one value without any rules
            const double_t baselineBits = this->mdlCalculator->codeUniformProbability(
                distributionEstimator->getGlobalProbabilityTemplated(rule->getVariable(), value));
            // determine how many bits are required to encode one value with the rule
            const double_t ruleBits = this->mdlCalculator->codeUniformProbability(
                distributionEstimator->getRuleProbabilityTemplated(rule, value));
            
            // compute how many of the bins samples can effectively be covered
            const int64_t newlyCoveredSamples = std::min(samplesToCover, count);
            samplesToCover -= newlyCoveredSamples;
            // compute how many bits can be saved in total using the current bin
            savedBits += newlyCoveredSamples * (baselineBits - ruleBits);
        }
    }

    return savedBits;
}

double_t DataEncodingEstimator::estimateSavedBits(
    const UpdateRule *const rule, const int64_t coveredSamples)
{
    auto valueSetRule = dynamic_cast<const ValueSetRule*>(rule);
    if (valueSetRule != nullptr)
    {
        // get categorical distribution
        const auto catVariable =
            std::static_pointer_cast<CategoricalVariable>(valueSetRule->getVariable());
        const DistributionEstimator::CatDistributionType& distribution =
            this->distributionEstimator->getCategoricalDistribution(catVariable);

        // compute how many samples exist in total
        int64_t totalCount = 0;
        for (const auto& [value, frequency] : distribution)
        {
            totalCount += frequency;
        }

        // compute values and frequencies sorted by probability (=relative frequency)
        std::multimap<double_t, std::pair<int64_t, std::string>> valueCounts;
        for (const auto& [value, frequency] : distribution)
        {
            valueCounts.insert(
                std::make_pair(frequency / totalCount, std::make_pair(frequency, value)));
        }

        // estimate bits that can be saved
        return this->estimateSavedBitsThroughSamples(valueCounts, coveredSamples, valueSetRule);
    }
    else
    {
        // get numerical distribution
        const auto numVariable = std::static_pointer_cast<NumericalVariable>(rule->getVariable());
        const Histogram& histogram =
            this->distributionEstimator->getNumericalDistribution(numVariable);
        const std::pair<double_t, double_t> histogramRange = histogram.getRange();
        const double_t offset = numVariable->getAccuracy() / 2;
        
        // compute values and frequencies sorted by probability
        std::multimap<double_t, std::pair<int64_t, double_t>> binCounts;
        for (double_t value = histogramRange.first + offset;
            value <= histogramRange.second;
            value = histogram.getBinLimits(value).second + offset)
        {
            const int64_t frequency = histogram.getCount(value);
            const double_t probability = histogram.getProbability(value, numVariable->getAccuracy());
            binCounts.insert(std::make_pair(probability, std::make_pair(frequency, value)));
        }

        // estimate bits that can be saved
        return this->estimateSavedBitsThroughSamples(binCounts, coveredSamples, rule);
    }
}
