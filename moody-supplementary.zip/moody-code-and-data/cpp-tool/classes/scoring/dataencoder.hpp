#pragma once
#include <memory>
#include "mdlcalculator.hpp"
#include "../preprocessing/distributionestimator.hpp"
#include "rulefinder.hpp"
#include "updaterulematcher.hpp"

/// @brief Used for encoding the data (event log) given the model (of modification rules)
class DataEncoder
{
    private:
    using LengthStatePair = std::pair<double_t, bool>;
    using ModelStreamType = std::unordered_map<bool, int64_t>;

    /// @brief member for getting MDL codes
    std::shared_ptr<MdlCalculator> mdlCalculator;
    /// @brief member for estimating distributions in the event log
    std::shared_ptr<DistributionEstimator> distributionEstimator;
    /// @brief member for finding rules that apply
    std::unique_ptr<RuleFinder> ruleFinder;
    /// @brief member for determining whether a rule's prediction matches the observed data
    std::unique_ptr<UpdateRuleMatcher> ruleMatcher;

    /// @brief Computes the encoding length of a given value using the prediction
    /// made by the given rule and determines how to modify the model stream
    /// @tparam T type of the data to encode (double_t or std::string)
    /// @param variable event log variable for which the value occurred
    /// @param trace trace in the event log where the value occurred
    /// @param index index in the trace that identifies the value
    /// @param rule update rule that predicts the value in the current context
    /// @return pair of the value stream encoding length in bits and the state for whether/how
    /// to update the model stream
    template<typename T> LengthStatePair encodeValueWithRule(
        const Trace* const trace, const size_t index, const UpdateRule* const rule);

    /// @brief Determines the best of multiple overlapping rules by using the one that adds fewest
    /// bits to the encoding
    /// @tparam T type of the data to encode (double_t or std::string)
    /// @param rules the overlapping modification rules to search
    /// @param modelStreamCounts current counts of the model stream
    /// @param trace trace in the event log where the to-be-encoded value occurred
    /// @param traceIndex index in the trace that identifies the to-be-encoded value
    /// @return pair of the value stream encoding length in bits and the state for how
    /// to update the model stream
    template<typename T> LengthStatePair findBestRule (
        const std::vector<const ModificationRule*>& rules, const ModelStreamType& modelStreamCounts,
        const Trace* const trace, const size_t traceIndex);

    /// @brief Updates the encoding streams with the given new information
    /// @param valueStreamLength to-be-updated length of the value stream in bits
    /// @param modelStreamCounts to-be-updated counts of the model stream
    /// @param updateInformation number of bits to add to the value stream and how to update
    /// the counts of the model stream
    void updateStreams(double_t& valueStreamLength, ModelStreamType& modelStreamCounts,
        const LengthStatePair& updateInformation);

    public:
    /// @brief Creates a new object while transferring the pointer ownership
    /// @param mdlCalculator object for computing MDL code lengths, not null
    /// @param distributionEstimator object for estimating global and local
    /// distributions in the event log, not null
    /// @param ruleFinder object for finding rules that apply, not null
    /// (will be null after the call)
    /// @param ruleMatcher object for determining whether a rule's prediction
    /// matches the observed data, not null (will be null after the call)
    DataEncoder(std::shared_ptr<MdlCalculator> mdlCalculator,
        std::shared_ptr<DistributionEstimator> distributionEstimator,
        std::unique_ptr<RuleFinder>& ruleFinder,
        std::unique_ptr<UpdateRuleMatcher>& ruleMatcher);

    /// @brief Creates a new object while transferring the pointer ownership
    /// @param mdlCalculator object for computing MDL code lengths, not null
    /// @param distributionEstimator object for estimating global and local
    /// distributions in the event log, not null
    DataEncoder(std::shared_ptr<MdlCalculator> mdlCalculator,
        std::shared_ptr<DistributionEstimator> distributionEstimator);

    /// @brief Creates a new object and initializes its remaining members itself
    /// @param mdlCalculator object for computing MDL code lengths, not null
    DataEncoder(std::shared_ptr<MdlCalculator> mdlCalculator);

    /// @brief Calculates the code length of the event log given the rule model
    /// \pre distributions in distributionEstimator were properly initialized
    /// @param log event log to compute code length for
    /// @param ruleModel model to use for compressing the data in the event log
    /// @return the event log's code length in bits
    double_t encodeEventLog(const EventLog* const log, const RuleModel* const ruleModel);

    /// @brief Calculates the code length of a single variable/column of the event log given
    /// the rule model
    /// @param log event log to compute code length for
    /// @param ruleModel model to use for compressing the data in the event log
    /// @param variable the event log variable/column to compute the code length for
    /// @return the code length of the event log's column in bits
    double_t encodeVariable(const EventLog* const log,
        const RuleModel* const ruleModel,
        const std::shared_ptr<LogVariable>& variable);

    /// @brief Calculates the code length of a single variable/column of the event log given
    /// the rule model
    /// @tparam T type of the data to encode (double_t or std::string)
    /// @param log event log to compute code length for
    /// @param ruleModel model to use for compressing the data in the event log
    /// @param variable the event log variable/column to compute the code length for
    /// @return the code length of the event log's column in bits
    template<typename T> double_t encodeVariableTemplated(const EventLog* const log,
        const RuleModel* const ruleModel,
        const std::shared_ptr<LogVariable>& variable);

    const DistributionEstimator* getDistributionEstimator() const;
};
