#pragma once
#include <vector>
#include "datamodel/eventlogs/logvariable.hpp"
#include "datamodel/eventlogs/eventlog.hpp"
#include "datamodel/conditions/condition.hpp"
#include "datamodel/updaterules/abstractvaluerule.hpp"

/// @brief Collects values from the multiple traces of an event log
class ColumnCollector
{
    private:
    template<typename T> std::pair<bool, T> getValueForModificationRule(const Trace* const trace,
        const UpdateRule* const updateRule, const size_t index);

    public:
    template<typename T> using MultiColumnsType = std::map<std::shared_ptr<LogVariable>, std::vector<T>>;
    template<typename T> using MultiTransitionsType =
        std::map<std::shared_ptr<LogVariable>, std::vector<std::pair<T, T>>>;
    virtual ~ColumnCollector() = default;

    /// @brief Collects the values of a single specified column across all traces
    /// @tparam T data type of the column
    /// @param log event log to collect values from
    /// @param variable event log variable to collect the values for
    /// @return all values from the traces
    template<typename T> std::vector<T> collectValues(
        const EventLog* const log, const std::shared_ptr<LogVariable> variable);

    /// @brief Collects the values to construct a modification rule
    /// @tparam T data type of values to collect
    /// @param log event log to collect values from
    /// @param condition when the to-be-constructed modification rule should be applied
    /// @param updateRule update rule of the to-be-constructed modification rule (only its type
    /// is used)
    /// @return values used to construct the modification rule
    template<typename T> std::vector<T> collectValuesForModificationRule(const EventLog* const log,
        const Condition* const condition, const UpdateRule* const updateRule);

    /// @brief Collects the residuals for modification rules that make point predictions
    /// @param log data source to calculate the residuals from
    /// @param condition when the modification rule should be applied
    /// @param updateRule used to calculate the predicted value
    /// @return vector of residuals (actual value - predicted value)
    virtual std::vector<double_t> collectResiduals(const EventLog* const log,
        const Condition* const condition, const AbstractValueRule* const updateRule);

    /// @brief Collect the values for all columns of the same type
    /// @tparam T data type to collect column values for
    /// @param log event log to collect values from
    /// @return all values for all same-type variables and traces
    template<typename T> MultiColumnsType<T> collectAllColumns(
        const EventLog* const log);

    /// @brief Collects the transitions of values across all traces
    /// @tparam T data type of the column
    /// @param log event log to collect transitions from
    /// @param variable event log variable to collect the transitions for
    /// @return all transitions (value before and after) from the traces
    template<typename T> std::vector<std::pair<T, T>> collectTransitions (
        const EventLog* const log, const std::shared_ptr<LogVariable> variable);

    /// @brief Collects the transitions of values for all columns of the same type
    /// @tparam T data type to collect transitions for
    /// @param log event log to collect transitions from
    /// @return all value transitions for all same-type variables and traces
    template<typename T> MultiTransitionsType<T> collectAllTransitions (const EventLog* const log);
};
