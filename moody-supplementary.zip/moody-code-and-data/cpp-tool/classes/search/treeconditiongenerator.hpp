#pragma once
#include <vector>
#include <map>
#include <memory>
#include <mlpack/core.hpp>
#include <mlpack/methods/decision_tree/decision_tree.hpp>
#include "../datamodel/conditions/condition.hpp"
#include "../datamodel/conditions/transitioncondition.hpp"
#include "../datamodel/eventlogs/eventlog.hpp"
#include "../datamodel/updaterules/updaterule.hpp"
#include "../columncollector.hpp"

/// @brief Generates conditions for update rules using decision trees
class TreeConditionGenerator
{
    public:
    /// @brief type to store which index in the decision tree's feature matrix corresponds to which
    /// value transition
    template<typename T> using IndexToTransitionMapType = std::map<size_t, TransitionCondition<T>>;

    private:
    /// @brief stores which index in the decision tree's feature matrix corresponds to which log
    /// variable
    std::map<size_t, std::shared_ptr<LogVariable>> indexToVariable;
    /// @brief stores which index in the decision tree's feature matrix corresponds to which
    /// numerical value transitions
    IndexToTransitionMapType<double_t> indexToNumericalTransition;
    /// @brief stores which index in the decision tree's feature matrix corresponds to which
    /// categorical value transitions
    IndexToTransitionMapType<std::string> indexToCategoricalTransition;

    /// @brief clears all internal lookup tables for mapping feature matrix indices
    void resetLookupTables();
    /// @brief Computes the labels for decision tree learning that show for which samples/events the
    /// update rule applies
    /// @param log event log used to check when the update rules applies
    /// @param rule update rule to check applicability of
    /// @return vector of 0s and 1s where a 1 shows that the update rule applies
    std::vector<size_t> computeLabels(
        const EventLog* const log, const UpdateRule* const rule);
    /// @brief Generates the feature matrix with dataset info to learn a decision tree from
    /// @param log event log to transform into a feature matrix
    /// @param rule update rule to compute the feature matrix for (e.g. used to exclude the update
    /// rule's variable as a feature)
    /// @return feature matrix and dataset info
    std::unique_ptr<std::pair<arma::mat, mlpack::data::DatasetInfo>> computeFeatures(
        const EventLog* const log, const UpdateRule* const rule);
    /// @brief Recursively extracts condition elements from a learned decision tree. Connects
    /// condition elements with logical operators according to tree traversal.
    /// \pre needs internal lookup tables to be initialized
    /// @param tree decision tree to extract condition elements from
    /// @param info information about the feature matrix used to learn the decision tree
    /// @return condition elements and whether they can be used to positively predict the update rule
    std::pair<Condition::ElementsType, bool> extractConditionFromTree(
        const mlpack::DecisionTree<>& tree, const mlpack::data::DatasetInfo& info);
    /// @brief Extracts the condition element of the current tree node for one of its child branches
    /// @param tree current tree node to get condition element for
    /// @param info information about the feature matrix used to learn the decision tree
    /// @param childNodeIndex which of the current node's child node a condition element should be
    /// generated for
    /// @return condition element corresponding to the child node
    std::unique_ptr<ConditionElement> extractConditionForChildNode(
        const mlpack::DecisionTree<>& tree, const mlpack::data::DatasetInfo& info,
        const size_t childNodeIndex);
    /// @brief Computes the size (number of rows and columns) of the feature matrix used to learn
    /// the decision tree
    /// @param rule update rule to compute the feature matrix for (e.g. used to exclude the update
    /// rule's variable as a feature)
    /// @param numericalColumns collected numerical column values
    /// @param categoricalColumns collected categorical column values
    /// @param numericalTransitions collected numerical transition values
    /// @param categoricalTransitions collected categorical transition values
    /// @return number of features and samples of the matrix
    std::pair<size_t, size_t> computeFeatureMatrixDimensions(const UpdateRule* const rule,
        const ColumnCollector::MultiColumnsType<double_t>& numericalColumns,
        const ColumnCollector::MultiColumnsType<std::string>& categoricalColumns,
        const ColumnCollector::MultiTransitionsType<double_t>& numericalTransitions,
        const ColumnCollector::MultiTransitionsType<std::string>& categoricalTransitions);
    /// @brief Initializes the dataset info and internal lookup tables with the data collected from
    /// the event log
    /// @param rule update rule to compute the feature matrix for (e.g. used to exclude the update
    /// rule's variable as a feature)
    /// @param info reference to the dataset info object to fill
    /// @param numericalColumns collected numerical column values
    /// @param categoricalColumns collected categorical column values
    /// @param numericalTransitions collected numerical transition values
    /// @param categoricalTransitions collected categorical transition values
    void fillDatasetInfoAndLookupTables (const UpdateRule* const rule,
        mlpack::data::DatasetInfo& info,
        const ColumnCollector::MultiColumnsType<double_t>& numericalColumns,
        const ColumnCollector::MultiColumnsType<std::string>& categoricalColumns,
        const ColumnCollector::MultiTransitionsType<double_t>& numericalTransitions,
        const ColumnCollector::MultiTransitionsType<std::string>& categoricalTransitions);
    /// @brief Initializes the dataset info and internal lookup tables for transition conditions
    /// with the data collected from the event log
    /// @tparam T data type of the transitions (double_t or std::string)
    /// @param rule update rule to compute the feature matrix for (e.g. used to exclude the update
    /// rule's variable as a feature)
    /// @param info reference to the dataset info object to fill
    /// @param lookupTable reference to the lookup table to fill
    /// @param index current feature index in the matrix (will be modified)
    /// @param transitions collected transition values
    template<typename T> void fillDatasetInfoAndLookupTablesForTransition(
        const UpdateRule* const rule,
        mlpack::data::DatasetInfo& info,
        IndexToTransitionMapType<T>& lookupTable,
        size_t& index,
        const ColumnCollector::MultiTransitionsType<T>& transitions);
    /// @brief Sets the binary features for transition conditions in the feature matrix to learn
    /// the decision tree from
    /// @tparam T data type of the transitions (double_t or std::string)
    /// @param log event log used to check when the transition condition applies
    /// @param rule update rule to compute the feature matrix for (e.g. used to exclude the update
    /// rule's variable as a feature)
    /// @param features feature matrix so fill with data
    /// @param lookupTable which index in the matrix corresponds to which transition condition
    template<typename T> void fillFeaturesForTransitions(
        const EventLog* const log,
        const UpdateRule* const rule,
        arma::mat& features,
        const IndexToTransitionMapType<T>& lookupTable);

    public:
    /// @brief Generates possible conditions for the given update rule using increasingly deeper
    /// decision trees
    /// @param log event log to extract data from
    /// @param rule update rule to generate conditions for
    /// @param maxTreeDepth how many levels the decision tree is allowed to have at maximum
    /// @return the conditions generated from decision trees of different depths
    std::vector<std::unique_ptr<Condition>> generateConditions(
        const EventLog* const log, const UpdateRule* const rule, const int64_t maxTreeDepth = 4);
};
