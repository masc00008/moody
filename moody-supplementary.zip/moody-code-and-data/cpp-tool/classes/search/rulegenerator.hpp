#pragma once
#include <vector>
#include <memory>
#include "../datamodel/modificationrule.hpp"
#include "../columncollector.hpp"
#include "../datamodel/rulemodel.hpp"
#include "../statistics.hpp"
#include "../preprocessing/distributionestimator.hpp"

/// @brief Base class for search candidate generation classes
class RuleGenerator
{
    public:
    using UpdateRulesWithFrequency = std::vector<std::pair<std::unique_ptr<UpdateRule>, int64_t>>;

    virtual ~RuleGenerator() = 0;
    /// @brief Generates a list of candidate modification rules to search
    /// @param log event log to generate modification rules for
    /// @param model current model of modification rules that the candidate modification rules
    /// should be added to
    /// @param targetVariable the variable that should appear in the update rule of the
    /// modification rule
    /// @return vector of modification rule objects that don't cause a cyclic model when added to
    /// the current model
    virtual std::vector<std::unique_ptr<ModificationRule>> generateModificationRules (
        const EventLog* const log, const RuleModel* const model,
        const std::shared_ptr<LogVariable> targetVariable) = 0;
    
    std::shared_ptr<DistributionEstimator> getDistributionEstimator() const
    { return distributionEstimator; }

    protected:
    /// @brief object to estimate variable distributions and accuracies in the event log
    std::shared_ptr<DistributionEstimator> distributionEstimator;
    /// @brief Used to obtain values of a variable from the event log
    ColumnCollector collector;
    /// @brief Used to obtain statistics from lists of values
    Statistics statistics;

    RuleGenerator(const std::shared_ptr<DistributionEstimator> distributionEstimator);

    /// @brief Constructs update rule objects for a given condition of all types (value, value set,
    /// difference etc.)
    /// @param log event log to construct update rules from
    /// @param condition condition to construct update rules for (possibly empty/always true)
    /// @param targetVariable log variable to generate the update rules for
    /// @param amountLimit how many update rules of each type should be constructed at maximum
    /// @return pairs of update rules with the corresponding number of samples that they cover
    UpdateRulesWithFrequency generateUpdateRules (
        const EventLog* const log, const Condition* const condition,
        const std::shared_ptr<LogVariable> targetVariable,
        const size_t amountLimit = 10);

    private:
    /// @brief Generates factor rules with their optimistic frequency estimate. Takes into account
    /// that equality of factors is on a different scale that equality of values.
    /// @param result data structure to add the factor rules and frequencies to
    /// @param log event log to construct factor rules from
    /// @param condition condition to construct factor rule for (possibly empty/always true)
    /// @param targetVariable numerical variable to generate the factor rules for
    /// @param amountLimit how many factor rules should be constructed at maximum
    void generateFactorRules(UpdateRulesWithFrequency& result,
        const EventLog* const log, const Condition* const condition,
        const std::shared_ptr<NumericalVariable>& targetVariable,
        const size_t amountLimit = 10);
    /// @brief Computes the smallest meaningful difference between factors in the best case
    /// (as many factors as possible are equal)
    /// @param variableAccuracy smallest meaningful difference between values of the variable that
    /// the factors are multiplied with
    /// @param numericalDistribution distribution of the numerical variable
    /// @return accuracy to which factors can be considered equal in the best case
    double_t computeOptimisticFactorAccuracy(
        const double_t& variableAccuracy, const Histogram& numericalDistribution);
};
