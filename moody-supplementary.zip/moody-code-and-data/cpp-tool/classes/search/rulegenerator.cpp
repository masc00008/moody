#include "rulegenerator.hpp"
#include <algorithm>
#include "../datamodel/conditions/valuecondition.hpp"
#include "../datamodel/conditions/transitioncondition.hpp"
#include "../datamodel/conditions/lowerboundcondition.hpp"
#include "../datamodel/conditions/upperboundcondition.hpp"
#include "../datamodel/conditions/andoperator.hpp"
#include "../datamodel/updaterules/valuerule.hpp"
#include "../datamodel/updaterules/valuesetrule.hpp"
#include "../datamodel/updaterules/differencerule.hpp"
#include "../datamodel/updaterules/factorrule.hpp"
#include "../datamodel/updaterules/valuerangerule.hpp"
#include "../datamodel/updaterules/changerangerule.hpp"
#include "../utils.hpp"

RuleGenerator::RuleGenerator(const std::shared_ptr<DistributionEstimator> distributionEstimator)
    : distributionEstimator((Utils::checkNull(distributionEstimator), distributionEstimator))
{
}

RuleGenerator::~RuleGenerator()
{
}

RuleGenerator::UpdateRulesWithFrequency RuleGenerator::generateUpdateRules(
    const EventLog *const log, const Condition* const condition,
    const std::shared_ptr<LogVariable> targetVariable,
    const size_t amountLimit)
{
    UpdateRulesWithFrequency result;
    const double_t accuracy = targetVariable->getAccuracy();

    // generate categorical rules
    auto catVariable = std::dynamic_pointer_cast<CategoricalVariable>(targetVariable);
    if (catVariable != nullptr)
    {
        auto rule = std::make_unique<ValueSetRule>(catVariable, ValueSetRule::SetType());
        // get most frequent values of the variable
        const Statistics::ValueFrequencies<std::string> frequentValues =
                this->statistics.getMostFrequentValues(
                    this->collector.collectValuesForModificationRule<std::string>(
                        log, condition, rule.get()),
                    amountLimit, accuracy);
        
        // generate value set rules for the most frequent values
        for (const auto& [value, frequency] : frequentValues)
        {
            result.push_back(std::make_pair(std::make_unique<ValueSetRule>(
                catVariable, ValueSetRule::SetType{value}), frequency));
            // TODO extend set if amountLimit > 1
        }
    }

    // generate numerical rules
    auto numVariable = std::dynamic_pointer_cast<NumericalVariable>(targetVariable);
    if (numVariable != nullptr)
    {
        std::vector<std::unique_ptr<UpdateRule>> pointRules;
        pointRules.push_back(std::make_unique<ValueRule>(numVariable, 0.0));
        pointRules.push_back(std::make_unique<DifferenceRule>(numVariable, 0.0));

        // generate rules with point predictions
        for (const auto& rule : pointRules)
        {
            // get most frequent numerical values
            const Statistics::ValueFrequencies<double_t> frequentValues =
                this->statistics.getMostFrequentValues(
                    this->collector.collectValuesForModificationRule<double_t>(
                        log, condition, rule.get()),
                    amountLimit, accuracy);
            
            // generate each rule type with each frequent value
            for (const auto& [value, frequency] : frequentValues)
            {
                auto copiedRule = std::unique_ptr<UpdateRule>(rule->clone());
                auto pointRule = static_cast<AbstractValueRule*>(copiedRule.get());
                pointRule->setConstant(value);
                result.push_back(std::make_pair(std::move(copiedRule), frequency));
            }
        }
        
        this->generateFactorRules(result, log, condition, numVariable, amountLimit);

        std::vector<std::unique_ptr<UpdateRule>> rangeRules;
        rangeRules.push_back(std::make_unique<ValueRangeRule>(numVariable, 0.0, 1.0));
        rangeRules.push_back(std::make_unique<ChangeRangeRule>(numVariable, 0.0, 1.0));

        // generate rules with range predictions
        for (const auto& rule : rangeRules)
        {
            // collect all values that the range rule applies to
            std::vector<double_t> values = this->collector.collectValuesForModificationRule<double_t>(
                log, condition, rule.get());

            // skip generating the rule when there is no range to represent
            if (values.size() < 2)
            {
                continue;
            }
            
            // get intervals from quantile ranges
            auto quantileIntervals = this->statistics.getQuantileIntervals(
                values, numVariable, amountLimit);

            for (const auto& [interval, frequency] : quantileIntervals)
            {
                // create the range rule
                auto copiedRule = std::unique_ptr<UpdateRule>(rule->clone());
                auto rangeRule = static_cast<AbstractRangeRule*>(copiedRule.get());
                rangeRule->setRange(interval.first, interval.second);
                result.push_back(std::make_pair(std::move(copiedRule), frequency));
            }
        }
    }

    return result;
}

void RuleGenerator::generateFactorRules(UpdateRulesWithFrequency &result, const EventLog *const log,
    const Condition *const condition, const std::shared_ptr<NumericalVariable>& targetVariable,
    const size_t amountLimit)
{
    auto factorRule = std::make_unique<FactorRule>(targetVariable, 1.0);

    // get most frequent factors within perfect accuracy
    const Statistics::ValueFrequencies<double_t> factorsByFrequency =
        this->statistics.getUniqueValuesSortedByFrequency(
            this->collector.collectValuesForModificationRule<double_t>(
                log, condition, factorRule.get()),
            std::numeric_limits<double_t>::epsilon());
    
    const double_t optimisticAccuracy = this->computeOptimisticFactorAccuracy(
        targetVariable->getAccuracy(),
        this->distributionEstimator->getNumericalDistribution(targetVariable));

    size_t rulesGenerated = 0;
    // generate factor rule for each frequent factor with optimistic frequency estimate
    for (const auto& [factor, lowerBoundFrequency] : factorsByFrequency)
    {
        // do not create rules with 0 factor
        if (factor < std::numeric_limits<double_t>::epsilon())
        {
            continue;
        }

        // end loop if the desired number of rules were generated
        if (rulesGenerated == amountLimit)
        {
            break;
        }

        // create rule
        auto copiedRule = std::unique_ptr<FactorRule>(factorRule->clone());
        copiedRule->setConstant(factor);
        // collect all frequencies that this factor could potentially also cover (optimistic)
        int64_t frequency = 0;
        for (const auto& [innerFactor, innerFrequency] : factorsByFrequency)
        {
            if (Utils::equals(factor, innerFactor, optimisticAccuracy))
            {
                frequency += innerFrequency;
            }
        }
        result.push_back(std::make_pair(std::move(copiedRule), frequency));
        rulesGenerated++;
    }
}

double_t RuleGenerator::computeOptimisticFactorAccuracy(
    const double_t &variableAccuracy, const Histogram &numericalDistribution)
{
    const auto range = numericalDistribution.getRange();
    // all factors can in principle be equal if we have zero values
    if (numericalDistribution.inRange(0.0))
    {
        return std::numeric_limits<double_t>::infinity();
    }
    else
    {
        // equality of factors is determined by the smallest absolute value that exists in the data
        const double_t minAbsoluteValuePossible = std::min(
            std::abs(range.first + variableAccuracy / 2),
            std::abs(range.second - variableAccuracy / 2));
        return variableAccuracy / minAbsoluteValuePossible;
    }
}
