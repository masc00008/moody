#include "modelfinder.hpp"
#include "../preprocessing/cycledetector.hpp"
#include "../utils.hpp"
#include "../scoring/mdlcalculator.hpp"
#include "../scoring/modelencoder.hpp"
#include "../scoring/dataencoder.hpp"
#include <algorithm>
#include "forwardrulegenerator.hpp"
#include "backwardrulegenerator.hpp"
#include "../datamodel/updaterules/valuerule.hpp"
#include "../datamodel/updaterules/differencerule.hpp"
#include "../datamodel/updaterules/factorrule.hpp"
#include "../datamodel/updaterules/valuerangerule.hpp"
#include "../datamodel/updaterules/changerangerule.hpp"
#include "../scoring/dataencodingestimator.hpp"

std::unique_ptr<RuleModel> ModelFinder::findRuleModel(
    const EventLog *const log, RuleGenerator *ruleGenerator, const int64_t maxLength,
    const std::vector<std::shared_ptr<LogVariable>> targetVariables)
{
    Utils::checkNull(log);

    // optionally not use the score estimate for pruning the search
    constexpr bool searchAllCandidates = false;

    // initialize objects to compute the MDL score
    auto mdlCalculator = std::make_shared<MdlCalculator>();
    ModelEncoder modelEncoder(mdlCalculator, log->getVariables().size());
    DataEncoder dataEncoder(mdlCalculator, ruleGenerator->getDistributionEstimator());
    DataEncodingEstimator encodingEstimator(
        mdlCalculator, ruleGenerator->getDistributionEstimator());

    // create empty model
    auto model = std::make_unique<RuleModel>();
    
    // obtain possible target variables; if none are given, use all
    std::vector<std::shared_ptr<LogVariable>> activeVariables;
    if (targetVariables.size() == 0)
    {
        activeVariables = log->getVariables();
    }
    else
    {
        activeVariables = targetVariables;
    }
    // sort variables alphabetically by name to get reproducible results
    std::sort(activeVariables.begin(), activeVariables.end(),
        [](const std::shared_ptr<LogVariable>& var1, const std::shared_ptr<LogVariable>& var2)
        { return var1->getName() < var2->getName(); }
    );

    // compute initial MDL code lengths
    std::unordered_map<std::shared_ptr<LogVariable>, double_t> scoreCache;
    for (const auto& variable : activeVariables)
    {
        scoreCache[variable] = dataEncoder.encodeVariable(log, model.get(), variable);
    }

    // search for rules as long as a rule was added in the last iteration
    bool ruleWasAdded = true;
    while (ruleWasAdded)
    {
        ruleWasAdded = false;
        // search for rules for all active variables in the log
        for (auto it = activeVariables.begin(); it != activeVariables.end();)
        {
            logger.newVariable(it->get());
            logger.startTimer();

            // generate the modification rules to search
            auto modificationRules = ruleGenerator->generateModificationRules(
                log, model.get(), *it);

            logger.modificationRulesGenerated(modificationRules.size());

            // build priority queue of candidate rules sorted by their estimated quality
            using EstimateRulePair = std::pair<double_t, std::unique_ptr<ModificationRule>>;
            auto queueCompare = [](const EstimateRulePair& left, const EstimateRulePair& right)
                { return left.first < right.first; };
            std::priority_queue<EstimateRulePair, std::vector<EstimateRulePair>,
                decltype(queueCompare)> queue(queueCompare);

            logger.startTimer();
            for (auto& rule : modificationRules)
            {
                // optimistically estimate how many bits can be saved by each candidate rule
                double_t estimatedBitsSaved =
                    encodingEstimator.estimateSavedBits(
                        rule->getUpdateRule(), rule->getSamplesCovered())
                    - modelEncoder.encodeAdditionalModificationRule(model.get(), rule.get());
                queue.push(std::make_pair(estimatedBitsSaved, std::move(rule)));
            }
            logger.rulesEstimated();

            EstimateRulePair bestCandidate {0.0, std::unique_ptr<ModificationRule>()};
            logger.startTimer();

            // paralellize the bounded search
            #pragma omp parallel
            {
                auto modelCopy = std::unique_ptr<RuleModel>(model->clone());
                bool continueSearch = true;
                // greedily search rules
                while (continueSearch)
                {
                    EstimateRulePair currentCandidate;
                    #pragma omp critical (QueueBestCandidateAccess)
                    {
                        // check whether next candidate is worth checking
                        continueSearch = !queue.empty() && 
                            (searchAllCandidates || queue.top().first > bestCandidate.first);
                        if (continueSearch)
                        {
                            // get the current candidate from the queue
                            currentCandidate = std::make_pair(queue.top().first,
                            std::unique_ptr<ModificationRule>(queue.top().second->clone()));
                            queue.pop();
                        }
                    }

                    // abort search if no new candidate is worth checking
                    if (!continueSearch)
                    {
                        break;
                    }

                    // temporarily add each rule to the model
                    modelCopy->addRule(std::unique_ptr<ModificationRule>(
                        currentCandidate.second->clone()));

                    // compute and save the MDL score change of the model
                    const double_t modelCosts = modelEncoder.encodeAdditionalModificationRule(
                        model.get(), currentCandidate.second.get());
                    const double_t bitsSaved = scoreCache[*it]
                        - dataEncoder.encodeVariable(log, modelCopy.get(), *it)
                        - modelCosts;

                    #pragma omp critical (LogOutput)
                    {
                        logger.ruleScored(bitsSaved, currentCandidate.first,
                            currentCandidate.second.get());
                    }

                    #pragma omp critical (QueueBestCandidateAccess)
                    {
                        // update best candidate if the current candidate is an improvement
                        if (bitsSaved > bestCandidate.first)
                        {
                            bestCandidate = std::make_pair(
                                bitsSaved, std::move(currentCandidate.second));
                        }
                    }
                    
                    // remove temporarily added rule from model
                    modelCopy->removeLastRule();
                }
            }
            logger.allRulesScored(modificationRules.size() - queue.size(), bestCandidate.first,
                bestCandidate.second.get());

            // does the best candidate save bits?
            if (bestCandidate.first > 0.0)
            {
                // permanently add rule => update MDL score caches
                model->addRule(std::move(bestCandidate.second));
                scoreCache[*it] = dataEncoder.encodeVariable(
                    log, model.get(), *it);
                ruleWasAdded = true;
                // move to next target variable
                it++;
            }
            else
            {
                // no rule was found => make variable inactive
                it = activeVariables.erase(it);
            }

            // abort the search if sufficiently many rules were found
            if (model->getRules().size() == maxLength)
            {
                return model;
            }
        }
    }

    return model;
}
