#include "treeconditiongenerator.hpp"
#include "../utils.hpp"
#include "../scoring/updaterulematcher.hpp"
#include <stdexcept>
#include "../datamodel/conditions/lowerboundcondition.hpp"
#include "../datamodel/conditions/upperboundcondition.hpp"
#include "../datamodel/conditions/valuecondition.hpp"
#include "../datamodel/conditions/transitioncondition.hpp"
#include "../datamodel/conditions/andoperator.hpp"
#include "../datamodel/conditions/oroperator.hpp"
#include "../scoring/conditionmatcher.hpp"
#include <iostream>

void TreeConditionGenerator::resetLookupTables()
{
    this->indexToVariable = std::map<size_t, std::shared_ptr<LogVariable>>();
    this->indexToNumericalTransition = IndexToTransitionMapType<double_t>();
    this->indexToCategoricalTransition = IndexToTransitionMapType<std::string>();
}

std::vector<size_t> TreeConditionGenerator::computeLabels(
    const EventLog *const log, const UpdateRule *const rule)
{
    UpdateRuleMatcher matcher;
    std::vector<size_t> labels;
    for (const auto& trace : log->getTraces())
    {
        for (size_t i = 0; i < trace.second->size(); i++)
        {
            // add a label for each event in each trace
            if (matcher.matches(rule, trace.second.get(), i))
            {
                labels.push_back(1);
            }
            else
            {
                labels.push_back(0);
            }
        }
    }
    return labels;
}

std::unique_ptr<std::pair<arma::mat, mlpack::data::DatasetInfo>>
TreeConditionGenerator::computeFeatures(const EventLog* const log, const UpdateRule* const rule)
{
    this->resetLookupTables();

    // collect all values and transitions from the event log
    ColumnCollector collector;
    auto numericalColumns = collector.collectAllColumns<double_t>(log);
    auto categoricalColumns = collector.collectAllColumns<std::string>(log);
    auto numericalTransitions = collector.collectAllTransitions<double_t>(log);
    auto categoricalTransitions = collector.collectAllTransitions<std::string>(log);

    // compute size of the feature matrix
    auto featuresSamplesPair = this->computeFeatureMatrixDimensions(
        rule, numericalColumns, categoricalColumns, numericalTransitions, categoricalTransitions);
    const size_t& numberOfFeatures = featuresSamplesPair.first;
    const size_t& numberOfSamples = featuresSamplesPair.second;

    // initialize pair with matrix and dataset info
    // row represent features/variables, columns represent events/samples
    auto result = std::make_unique<std::pair<arma::mat, mlpack::data::DatasetInfo>>(
        arma::mat(numberOfFeatures, numberOfSamples), mlpack::data::DatasetInfo(numberOfFeatures));

    // initialize dataset info and lookup for transitions and variable objects
    this->fillDatasetInfoAndLookupTables(rule, result->second, numericalColumns, categoricalColumns,
        numericalTransitions, categoricalTransitions);

    size_t i = 0;
    // fill matrix
    for (const auto& columnPair : numericalColumns)
    {
        // skip target variable
        if (columnPair.first != rule->getVariable())
        {
            result->first.row(i) = arma::rowvec(columnPair.second);
            i++;
        }
    }
    for (const auto& columnPair : categoricalColumns)
    {
        // skip target variable
        if (columnPair.first != rule->getVariable())
        {
            size_t j = 0;
            // add all categorical values in their numeric form
            for (const auto& value : columnPair.second)
            {
                result->first(i, j) = result->second.MapString<size_t>(value, i);
                j++;
            }
            i++;
        }
    }

    // fill feature matrix for transitions
    this->fillFeaturesForTransitions(log, rule, result->first, this->indexToNumericalTransition);
    this->fillFeaturesForTransitions(log, rule, result->first, this->indexToCategoricalTransition);
    
    return std::move(result);
}

std::pair<Condition::ElementsType, bool> TreeConditionGenerator::extractConditionFromTree(
        const mlpack::DecisionTree<>& tree, const mlpack::data::DatasetInfo& info)
{
    Condition::ElementsType elements;
    bool predictsUpdateRule = true;
    if (tree.NumChildren() == 0)
    {
        // break recursion at leaf nodes
        predictsUpdateRule = tree.getClassProbabilities()[1] > 0.5;
    }
    else
    {
        bool atLeastOneChildPredicts = false;
        // loop through all children
        for (size_t i = 0; i < tree.NumChildren(); i++)
        {
            // get child node's condition elements and status
            auto conditionPair = this->extractConditionFromTree(tree.Child(i), info);
            // get current condition element
            auto currentElement = this->extractConditionForChildNode(tree, info, i);

            // only construct conditions if the brach positively predicts the update rule and
            // a condition element of the current node exists for the child branch
            if (conditionPair.second && currentElement != nullptr)
            {
                // add condition elements of the child branch
                elements.insert(elements.end(),
                    std::make_move_iterator(conditionPair.first.begin()),
                    std::make_move_iterator(conditionPair.first.end()));

                // add condition element of the current node
                elements.push_back(std::move(currentElement));

                // add and operator if elements along the tree branch need to be combined
                if (conditionPair.first.size() > 0)
                {
                    elements.push_back(std::make_unique<AndOperator>());
                }

                // add or operator if more than one child node predicts the update rule
                if (atLeastOneChildPredicts)
                {
                    elements.push_back(std::make_unique<OrOperator>());
                }

                // keep track of child nodes predicting the target
                atLeastOneChildPredicts = true;
            }
        }
        // propagate that this branch has conditions to predict the update rule
        predictsUpdateRule = atLeastOneChildPredicts;
    }
    return std::make_pair(std::move(elements), predictsUpdateRule);
}

std::unique_ptr<ConditionElement> TreeConditionGenerator::extractConditionForChildNode(
    const mlpack::DecisionTree<>& tree, const mlpack::data::DatasetInfo& info,
        const size_t childNodeIndex)
{
    // was the split performed on a variable's value?
    if (this->indexToVariable.find(tree.SplitDimension()) != this->indexToVariable.end())
    {
        const auto variableType = info.Type(tree.SplitDimension());
        const auto variable = this->indexToVariable.at(tree.SplitDimension());
        // add atomic condition for current numerical split node
        if (variableType == mlpack::data::Datatype::numeric)
        {
            const auto numVariable = std::static_pointer_cast<NumericalVariable>(variable);
            // left branch: value is smaller than the split point
            if (childNodeIndex == 0)
            {
                return std::make_unique<UpperBoundCondition>(
                    numVariable, tree.getClassProbabilities()[0]);
            }
            // right branch: value is large than the split point
            else if (childNodeIndex == 1)
            {
                return std::make_unique<LowerBoundCondition>(
                    numVariable, tree.getClassProbabilities()[0]);
            }
            else
            {
                throw std::invalid_argument("Non-binary split for numerical variable");
            }
        }
        // add atomic condition for current categorical split node
        else if (variableType == mlpack::data::Datatype::categorical)
        {
            const auto catVariable = std::static_pointer_cast<CategoricalVariable>(variable);
            return std::make_unique<ValueCondition<std::string>>(
                catVariable, info.UnmapString(childNodeIndex, tree.SplitDimension()));
        }
        else
        {
            throw std::invalid_argument("Unknown datatype of variable");
        }
    }
    // was the split performed positively on a numerical split feature?
    else if (this->indexToNumericalTransition.find(tree.SplitDimension())
        != this->indexToNumericalTransition.end() && childNodeIndex == 1)
    {
        return std::make_unique<TransitionCondition<double_t>>(
            this->indexToNumericalTransition.at(tree.SplitDimension()));
    }
    // was the split performed positively on a categorical split feature?
    else if (this->indexToCategoricalTransition.find(tree.SplitDimension())
        != this->indexToCategoricalTransition.end() && childNodeIndex == 1)
    {
        return std::make_unique<TransitionCondition<std::string>>(
            this->indexToCategoricalTransition.at(tree.SplitDimension()));
    }
    // negatively condition on transition condition
    else if (childNodeIndex == 0)
    {
        // no condition element can be generated
        return nullptr;
    }
    else
    {
        throw std::invalid_argument("Feature index was not found in any lookup table");
    }
}

std::pair<size_t, size_t> TreeConditionGenerator::computeFeatureMatrixDimensions(
        const UpdateRule* const rule,
        const ColumnCollector::MultiColumnsType<double_t>& numericalColumns,
        const ColumnCollector::MultiColumnsType<std::string>& categoricalColumns,
        const ColumnCollector::MultiTransitionsType<double_t>& numericalTransitions,
        const ColumnCollector::MultiTransitionsType<std::string>& categoricalTransitions)
{
    // start with all numerical and categorical columns except for the target variable
    size_t numberOfFeatures = numericalColumns.size() + categoricalColumns.size() - 1;

    for (const auto& transitions : numericalTransitions)
    {
        // skip target variable
        if (transitions.first != rule->getVariable())
        {
            // add binary features for numerical transitions
            numberOfFeatures += transitions.second.size();
        }
    }
    for (const auto& transitions : categoricalTransitions)
    {
        // skip target variable
        if (transitions.first != rule->getVariable())
        {
            // add binary features for categorical transitions
            numberOfFeatures += transitions.second.size();
        }
    }

    // compute the numer of samples/events in the log
    size_t numberOfSamples;
    if (numericalColumns.size() > 0)
    {
        numberOfSamples = numericalColumns.begin()->second.size();
    }
    else if (categoricalColumns.size() > 0)
    {
        numberOfSamples = categoricalColumns.begin()->second.size();
    }
    else
    {
        throw std::invalid_argument("Neither numerical nor categorical columns");
    }

    return std::make_pair(numberOfFeatures, numberOfSamples);
}

void TreeConditionGenerator::fillDatasetInfoAndLookupTables (const UpdateRule* const rule,
        mlpack::data::DatasetInfo& info,
        const ColumnCollector::MultiColumnsType<double_t>& numericalColumns,
        const ColumnCollector::MultiColumnsType<std::string>& categoricalColumns,
        const ColumnCollector::MultiTransitionsType<double_t>& numericalTransitions,
        const ColumnCollector::MultiTransitionsType<std::string>& categoricalTransitions)
{
    size_t i = 0;
    for (const auto& columnPair : numericalColumns)
    {
        // skip target variable
        if (columnPair.first != rule->getVariable())
        {
            // set all numerical variable types and add mapping in lookup table
            info.Type(i) = mlpack::data::Datatype::numeric;
            this->indexToVariable.insert(std::make_pair(i, columnPair.first));
            i++;
        }
    }
    for (const auto& columnPair : categoricalColumns)
    {
        // skip target variable
        if (columnPair.first != rule->getVariable())
        {
            // set all categorical variable types and add mapping in lookup table
            info.Type(i) = mlpack::data::Datatype::categorical;
            this->indexToVariable.insert(std::make_pair(i, columnPair.first));
            // initialize string-to-integer mapping of categorical variables
            const auto catVariable = std::static_pointer_cast<CategoricalVariable>(columnPair.first);
            for (const auto& value : catVariable->getDomain())
            {
                info.MapString<size_t>(value, i);
            }
            i++;
        }
    }
    // do the same for transitions
    this->fillDatasetInfoAndLookupTablesForTransition(
        rule, info, this->indexToNumericalTransition, i, numericalTransitions);
    this->fillDatasetInfoAndLookupTablesForTransition(
        rule, info, this->indexToCategoricalTransition, i, categoricalTransitions);
}

template<typename T> void TreeConditionGenerator::fillDatasetInfoAndLookupTablesForTransition(
        const UpdateRule* const rule,
        mlpack::data::DatasetInfo& info,
        IndexToTransitionMapType<T>& lookupTable,
        size_t& index,
        const ColumnCollector::MultiTransitionsType<T>& transitions)
{
    // process all transitions
    for (const auto& transitionPair : transitions)
    {
        // skip target variable
        if (transitionPair.first != rule->getVariable())
        {
            for (const auto& transition : transitionPair.second)
            {
                // insert numerical transition condition into lookup table
                if constexpr (std::is_same_v<T, double_t>)
                {
                    const auto numVariable = std::static_pointer_cast<NumericalVariable>(
                        transitionPair.first);
                    lookupTable.insert(std::make_pair(index, TransitionCondition<T>(
                        numVariable, transition.first, transition.second)));
                }

                // insert categorical transition condition into lookup table
                if constexpr (std::is_same_v<T, std::string>)
                {
                    const auto catVariable = std::static_pointer_cast<CategoricalVariable>(
                        transitionPair.first);
                    lookupTable.insert(std::make_pair(index, TransitionCondition<T>(
                        catVariable, transition.first, transition.second)));
                }

                // represent transitions as binary categorical features
                info.Type(index) = mlpack::data::Datatype::categorical;
                info.MapString<size_t>("0", index);
                info.MapString<size_t>("1", index);
                index++;
            }
        }
    }
}

template<typename T> void TreeConditionGenerator::fillFeaturesForTransitions(
        const EventLog* const log,
        const UpdateRule* const rule,
        arma::mat& features,
        const IndexToTransitionMapType<T>& lookupTable)
{
    ConditionMatcher matcher;
    for (const auto& indexConditionPair : lookupTable)
    {
        // skip target variable
        if (indexConditionPair.second.getVariable() != rule->getVariable())
        {
            // iterate through all events in all traces
            size_t i = 0;
            for (const auto& trace : log->getTraces())
            {
                for (size_t j = 0; j < trace.second->size(); j++)
                {
                    // set entry according to whether the transition condition matches
                    if (matcher.matches(&indexConditionPair.second, trace.second.get(), j))
                    {
                        features(indexConditionPair.first, i) = 1;
                    }
                    else
                    {
                        features(indexConditionPair.first, i) = 0;
                    }
                    i++;
                }
            }
        }
    }
}

std::vector<std::unique_ptr<Condition>> TreeConditionGenerator::generateConditions(
    const EventLog *const log, const UpdateRule *const rule, const int64_t maxTreeDepth)
{
    Utils::checkNull(log);
    Utils::checkNull(rule);

    if (maxTreeDepth < 1)
    {
        throw std::invalid_argument("Zero or negative tree depth is not possible");
    }

    // compute labels indicating when the update rule matched
    arma::Row<size_t> labels = this->computeLabels(log, rule);
    
    // compute features to predict the labels with
    auto featuresWithInfo = this->computeFeatures(log, rule);

    // configuration parameters for decision tree learning
    const size_t numberOfClasses = 2; // an update rule can only match or not match => 2 classes
    const size_t minimumLeafSize = 10; // use default
    const double_t minimumGainSplit = 1e-7; // use default

    std::vector<std::unique_ptr<Condition>> result;

    int64_t lastNumberOfConditionElements = -1;
    // create deeper and deeper trees
    for (size_t depth = 1; depth <= maxTreeDepth; depth++)
    {
        // learn tree
        mlpack::DecisionTree<> tree(featuresWithInfo->first, featuresWithInfo->second, labels,
            numberOfClasses, minimumLeafSize, minimumGainSplit, depth);

        // get conditions from split in the tree
        auto conditionElementsPair = this->extractConditionFromTree(
            tree, featuresWithInfo->second);
        // only add the condition to the result if it is larger than for the shallower tree
        if (conditionElementsPair.second
            && (int64_t) conditionElementsPair.first.size() > lastNumberOfConditionElements)
        {
            lastNumberOfConditionElements = conditionElementsPair.first.size();
            result.push_back(std::make_unique<Condition>(conditionElementsPair.first));
        }
    }

    return result;
}
