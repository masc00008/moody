#pragma once
#include "rulegenerator.hpp"
#include "../datamodel/modificationrule.hpp"

/// @brief Generates candidate modification rules by finding conditions for common update rules
class BackwardRuleGenerator : public RuleGenerator
{
    private:
    /// @brief how many update rules of each type should be generated at maximum
    size_t amountLimit;

    public:
    BackwardRuleGenerator(const std::shared_ptr<DistributionEstimator> distributionEstimator,
        const size_t amountLimit = 10);

    /// @brief Generates a list of candidate modification rules to search by first finding common
    /// update rules and then finding their conditions using decision trees
    /// @param log event log to generate modification rules for
    /// @param model current model of modification rules that the candidate modification rules
    /// should be added to
    /// @param targetVariable the variable that should appear in the update rule of the
    /// modification rule
    /// @return vector of modification rule objects that don't cause a cyclic model when added to
    /// the current model
    std::vector<std::unique_ptr<ModificationRule>> generateModificationRules (
        const EventLog* const log, const RuleModel* const model,
        const std::shared_ptr<LogVariable> targetVariable);
};
