#pragma once
#include <vector>
#include <memory>
#include <unordered_map>
#include <cmath>
#include "../datamodel/modificationrule.hpp"
#include "../datamodel/eventlogs/eventlog.hpp"
#include "rulegenerator.hpp"

/// @brief Generates candidate modification rules by enumerating frequent conditions and
/// generating a suitable update rule for each condition
class ForwardRuleGenerator : public RuleGenerator
{
    private:
    /// @brief Collects which values should be searched for each variable
    template<typename T> using ValuesToSearchType =
        std::unordered_map<std::shared_ptr<LogVariable>, std::set<T>>;
    /// @brief Collects which value transitions should be searched for each variable
    /// @tparam T data type of the variable (double_t or std::string)
    template<typename T> using TransitionsType =
        std::unordered_map<std::shared_ptr<LogVariable>, std::set<std::pair<T, T>>>;

    /// @brief Collects which values should be searched for equality of each numerical variable
    ValuesToSearchType<double_t> numValuesToSearch;
    /// @brief Collects which values should be searched for equality of each categorical variable
    ValuesToSearchType<std::string> catValuesToSearch;
    /// @brief Collects which values should be searched for bound conditions of numerical variables
    ValuesToSearchType<double_t> numBoundValuesToSearch;
    /// @brief Collects which value transitions should be searched for each numerical variable
    TransitionsType<double_t> numericalTransitions;
    /// @brief Collects which value transitions should be searched for each categorical variable
    TransitionsType<std::string> categoricalTransitions;
    /// @brief Collects the generated conditions to construct modification rules from
    std::vector<std::unique_ptr<Condition>> conditions;

    /// @brief Finds the most frequent values for each variable in the event log
    /// @param log event log to collect numerical values from
    /// @param numberOfValues how many values should be collected at maximum for each numerical
    /// variable
    /// @return most frequent numerical values
    template<typename T> ValuesToSearchType<T> findMostFrequentValues (
        const EventLog* const log, const size_t numberOfValues = 25);

    /// @brief Finds the numerical values that well cover the quantile ranges of each numerical
    /// variable in the event log.
    /// @param log event log to collect numerical values from
    /// @param numberOfValues how many values should be collected at maximum for each numerical
    /// variable
    /// @return values that cover the quantile ranges
    ValuesToSearchType<double_t> findRangeSpanningNumericalValues (
        const EventLog* const log, const size_t numberOfValues = 50);

    /// @brief Finds the most frequent value transitions for all same-type variables in the event
    /// log
    /// @tparam T data type of the variable
    /// @param log event log to collect value transitions from
    /// @param numberOfTransitions how many transitions should be collected at maximum for each
    /// variable
    /// @return most frequent value transitions
    template<typename T> TransitionsType<T> findMostFrequentTransitions (
        const EventLog* const log, const size_t numberOfTransitions = 25);

    /// @brief Constructs condition objects of all types (categorical, numerical, values,
    /// transitions) that make the previous condition more specific (AND connection). Uses the
    /// internal lookup tables to do so.
    /// @param log event log to construct conditions for
    /// @param previousCondition the previous condition to extend
    /// @return vector of condition objects
    std::vector<std::unique_ptr<Condition>> generateConditions (const EventLog* const log,
        const Condition* const previousCondition);

    public:
    /// @brief Creates a new object
    /// @param distributionEstimator object to estimate variable distributions and accuracies in
    /// the event log, not null and with initialized distributions and accuracies
    /// @param log event log to generate rules for (the same one that is used in later calls)
    /// @param baseCondition condition that is extended to generate candidate conditions
    /// @param conditionCount hyperparameter to specify how many conditions should be generated per
    /// non-target variable and condition type
    ForwardRuleGenerator(const std::shared_ptr<DistributionEstimator> distributionEstimator,
        const EventLog* const log, const Condition* const baseCondition,
        const size_t conditionCount = 50);

    /// @brief Constructs modification rule objects from generated conditions where each condition
    /// is combined with one update rule of each type (value, value set, difference etc.).
    /// @param log event log to construct modification rules for
    /// @param model current model of modification rules that the candidate modification rules
    /// should be added to
    /// @param targetVariable log variable to generate the update rule for
    /// @return vector of modification rule objects that don't cause a cyclic model when added to
    /// the current model
    std::vector<std::unique_ptr<ModificationRule>> generateModificationRules (
        const EventLog* const log, const RuleModel* const model,
        const std::shared_ptr<LogVariable> targetVariable);
};
