#pragma once
#include <memory>
#include "../datamodel/rulemodel.hpp"
#include "../datamodel/eventlogs/eventlog.hpp"
#include "rulegenerator.hpp"
#include "../logger.hpp"
#include <queue>

/// @brief Discovers rule models from event logs by searching over the MDL score
class ModelFinder
{
    private:
    using EstimateRulePair = std::pair<double_t, std::unique_ptr<ModificationRule>>;

    Logger logger;

    public:
    
    /// @brief Searches for good rule models for the event log using the MDL score and a greedy
    /// search strategy 
    /// @param log event log to find rule model for
    /// @param ruleGenerator generator object used to create candidate modification rules
    /// @param maxLength how many rules should be found at most (limits search time)
    /// @param targetVariables specifies which target variables should be considered for the model
    /// (all variables by default)
    /// @return the best rule model that the search could find
    std::unique_ptr<RuleModel> findRuleModel (
        const EventLog* const log, RuleGenerator* ruleGenerator,
        const int64_t maxLength = 0x7fffffffffffffff,
        const std::vector<std::shared_ptr<LogVariable>> targetVariables = {});
};
