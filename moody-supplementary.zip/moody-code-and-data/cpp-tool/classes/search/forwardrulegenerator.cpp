#include "forwardrulegenerator.hpp"
#include "../datamodel/conditions/valuecondition.hpp"
#include "../datamodel/conditions/transitioncondition.hpp"
#include "../datamodel/conditions/lowerboundcondition.hpp"
#include "../datamodel/conditions/upperboundcondition.hpp"
#include "../datamodel/conditions/notoperator.hpp"
#include "../datamodel/updaterules/valuerule.hpp"
#include "../datamodel/updaterules/valuesetrule.hpp"
#include "../datamodel/updaterules/differencerule.hpp"
#include "../datamodel/updaterules/factorrule.hpp"
#include "../datamodel/updaterules/valuerangerule.hpp"
#include "../datamodel/updaterules/changerangerule.hpp"
#include "../utils.hpp"
#include "../preprocessing/cycledetector.hpp"
#include <algorithm>
#include <stdexcept>

ForwardRuleGenerator::ForwardRuleGenerator(
        const std::shared_ptr<DistributionEstimator> distributionEstimator,
        const EventLog* const log, const Condition* const baseCondition,
        const size_t conditionCount)
    : RuleGenerator(distributionEstimator)
{
    Utils::checkNull(log);
    Utils::checkNull(baseCondition);

    const size_t halfConditionCount = conditionCount / 2 + conditionCount % 2;
    this->numValuesToSearch = this->findMostFrequentValues<double_t>(log, halfConditionCount);
    this->catValuesToSearch = this->findMostFrequentValues<std::string>(log, halfConditionCount);
    this->numBoundValuesToSearch = this->findRangeSpanningNumericalValues(log, conditionCount);
    this->numericalTransitions = this->findMostFrequentTransitions<double_t>(
        log, halfConditionCount);
    this->categoricalTransitions = this->findMostFrequentTransitions<std::string>(
        log, halfConditionCount);
    this->conditions = this->generateConditions(log, baseCondition);
}

template<typename T>
ForwardRuleGenerator::ValuesToSearchType<T> ForwardRuleGenerator::findMostFrequentValues (
    const EventLog* const log, const size_t numberOfValues)
{
    // get all values of all numerical variables
    const auto columns = this->collector.collectAllColumns<T>(log);

    // loop through all numerical variables
    ValuesToSearchType<T> result;
    for (const auto& [variable, values] : columns)
    {
        if (!Utils::variableTypeMatches<T>(variable))
        {
            throw std::invalid_argument("Variable type does not match value type");
        }

        // get most frequent values and add them to the result
        auto mostFrequent = this->statistics.getMostFrequentValuesClean(
            values, numberOfValues, variable->getAccuracy());
        result[variable] = std::set<T>(mostFrequent.begin(), mostFrequent.end());
    }
    return result;
}

template ForwardRuleGenerator::ValuesToSearchType<double_t>
ForwardRuleGenerator::findMostFrequentValues (
    const EventLog* const log, const size_t numberOfValues);
template ForwardRuleGenerator::ValuesToSearchType<std::string>
ForwardRuleGenerator::findMostFrequentValues (
    const EventLog* const log, const size_t numberOfValues);

ForwardRuleGenerator::ValuesToSearchType<double_t>
ForwardRuleGenerator::findRangeSpanningNumericalValues(
    const EventLog *const log, const size_t numberOfValues)
{
    // get all values of all numerical variables
    auto numericalColumns = this->collector.collectAllColumns<double_t>(log);

    // loop through all numerical variables
    ValuesToSearchType<double_t> result;
    for (auto& [variable, values] : numericalColumns)
    {
        // get quantile values
        auto numVariable = std::static_pointer_cast<NumericalVariable>(variable);
        auto rangeSpanningValues = this->statistics.getQuantileDivisions(values,
            numVariable->getAccuracy(), numberOfValues);

        // remove values if they are equal to the minimun or maximum value of the domain
        // conditions on them would either select all values or just one value
        if (*rangeSpanningValues.begin() == *std::min_element(values.begin(), values.end()))
        {
            rangeSpanningValues.erase(rangeSpanningValues.begin());
        }
        if (*(rangeSpanningValues.end() - 1) == *std::max_element(values.begin(), values.end()))
        {
            rangeSpanningValues.erase(rangeSpanningValues.end() - 1);
        }

        // add filtered quantile values to the result
        result[numVariable] = std::set<double_t>(
            rangeSpanningValues.begin(), rangeSpanningValues.end());
    }
    return result;
}

std::vector<std::unique_ptr<Condition>> ForwardRuleGenerator::generateConditions(
    const EventLog* const log,
    const Condition *const previousCondition)
{
    std::vector<std::unique_ptr<Condition>> result;
    
    // first use (empty) previous condition
    auto previousConditionCopy = std::unique_ptr<Condition>(previousCondition->clone());
    result.push_back(std::move(previousConditionCopy));

    // generate categorical value conditions
    for (const auto& [variable, values] : this->catValuesToSearch)
    {
        auto catVariable = std::static_pointer_cast<CategoricalVariable>(variable);
        // add a value condition for each value in the domain of the variable
        for (const auto& value : values)
        {
            auto condition = std::unique_ptr<Condition>(previousCondition->clone());
            condition->addElement(
                std::make_unique<ValueCondition<std::string>>(catVariable, value));
            result.push_back(std::move(condition));
        }
    }

    // generate categorical transition conditions
    for (const auto& [variable, transitions] : this->categoricalTransitions)
    {
        auto catVariable = std::static_pointer_cast<CategoricalVariable>(variable);
        // add a transition condition for each transition in the lookup table
        for (const auto& transition : transitions)
        {
            auto condition = std::unique_ptr<Condition>(previousCondition->clone());
            condition->addElement(std::make_unique<TransitionCondition<std::string>>(
                    catVariable, transition.first, transition.second));
            result.push_back(std::move(condition));
        }
    }

    // generate numerical transition conditions
    for (const auto& [variable, transitions] : this->numericalTransitions)
    {
        auto numVariable = std::static_pointer_cast<NumericalVariable>(variable);
        // add a transition condition for each transition in the lookup table
        for (const auto& transition : transitions)
        {
            auto condition = std::unique_ptr<Condition>(previousCondition->clone());
            condition->addElement(std::make_unique<TransitionCondition<double_t>>(
                    numVariable, transition.first, transition.second));
            result.push_back(std::move(condition));
        }
    }

    // generate numerical value conditions
    for (const auto& [variable, values] : this->numValuesToSearch)
    {
        auto numVariable = std::static_pointer_cast<NumericalVariable>(variable);
        std::unique_ptr<Condition> condition;
        // add value condition for each value in the lookup table
        for (const auto& value : values)
        {
            // add value conditions
            condition = std::unique_ptr<Condition>(previousCondition->clone());
            condition->addElement(std::make_unique<ValueCondition<double_t>>(numVariable, value));
            result.push_back(std::move(condition));
        }
    }

    // generate numerical bound conditions
    for (const auto& [variable, values] : this->numBoundValuesToSearch)
    {
        auto numVariable = std::static_pointer_cast<NumericalVariable>(variable);
        std::unique_ptr<Condition> condition;
        // add value condition for each value in the lookup table
        for (const auto& value : values)
        {
            // add bound conditions
            condition = std::unique_ptr<Condition>(previousCondition->clone());
            condition->addElement(std::make_unique<UpperBoundCondition>(numVariable, value));
            result.push_back(std::move(condition));

            condition = std::unique_ptr<Condition>(previousCondition->clone());
            condition->addElement(std::make_unique<LowerBoundCondition>(numVariable, value));
            result.push_back(std::move(condition));
        }
    }

    // add negated rules where necessary (always except for bound conditions)
    std::vector<std::unique_ptr<Condition>> negatedConditions;
    for (const auto& condition : result)
    {
        // skip for empty condition
        if (condition->getElements().size() == 0)
        {
            continue;
        }

        auto& lastElement = *condition->getElements().rbegin();
        auto lowerBoundCondition = dynamic_cast<const LowerBoundCondition*>(lastElement.get());
        auto upperBoundCondition = dynamic_cast<const UpperBoundCondition*>(lastElement.get());

        if (lowerBoundCondition == nullptr && upperBoundCondition == nullptr)
        {
            negatedConditions.push_back(std::unique_ptr<Condition>(condition->clone()));
            (*negatedConditions.rbegin())->addElement(std::make_unique<NotOperator>());
        }
    }
    result.insert(result.end(), std::make_move_iterator(negatedConditions.begin()),
        std::make_move_iterator(negatedConditions.end()));

    return result;
}

template<typename T> ForwardRuleGenerator::TransitionsType<T>
ForwardRuleGenerator::findMostFrequentTransitions(
    const EventLog* const log, const size_t numberOfTransitions)
{
    TransitionsType<T> result;

    for (const auto& variable : log->getVariables())
    {
        // find log variable matching the template type
        if (Utils::variableTypeMatches<T>(variable))
        {
            // get the variable's transitions and add most frequent ones to the result
            auto transitions = this->collector.collectTransitions<T>(log, variable);
            auto mostFrequent = this->statistics.getMostFrequentValuesClean(
                transitions, numberOfTransitions, variable->getAccuracy());
            result[variable] = std::set<std::pair<T, T>>(mostFrequent.begin(), mostFrequent.end());
        }
    }

    return result;
}

std::vector<std::unique_ptr<ModificationRule>> ForwardRuleGenerator::generateModificationRules(
    const EventLog* const log, const RuleModel* const model,
    const std::shared_ptr<LogVariable> targetVariable)
{
    Utils::checkNull(log);
    Utils::checkNull(model);
    Utils::checkNull(targetVariable);

    CycleDetector detector;
    std::vector<std::unique_ptr<ModificationRule>> result;

    #pragma omp parallel for
    for (const auto& condition : this->conditions)
    {
        auto adjacencyList = detector.computeAdjacencyList(model);
        detector.addEdgesToAdjacencyList(adjacencyList, condition->getVariables(), targetVariable);
        if (!detector.hasCycle(adjacencyList))
        {
            // generate update rules for each condition if the model is not cyclic
            auto updateRules = this->generateUpdateRules(
                log, condition.get(), targetVariable, 1);
            for (auto& [updateRule, frequency] : updateRules)
            {
                // add modification rule to the result for each combination of condition and update rule
                auto copiedCondition = std::unique_ptr<Condition>(condition->clone());
                auto modificationRule =
                    std::make_unique<ModificationRule>(copiedCondition, updateRule);
                // use the number of samples covered by the rule as a quality estimate
                modificationRule->setSamplesCovered(frequency);
                #pragma omp critical (InsertModificationRule)
                {
                    result.push_back(std::move(modificationRule));
                }
            }
        }
    }

    return result;
}
