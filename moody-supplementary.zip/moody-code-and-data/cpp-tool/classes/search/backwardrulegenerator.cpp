#include "backwardrulegenerator.hpp"
#include "treeconditiongenerator.hpp"
#include "../utils.hpp"
#include "../preprocessing/cycledetector.hpp"

BackwardRuleGenerator::BackwardRuleGenerator(
    const std::shared_ptr<DistributionEstimator> distributionEstimator, const size_t amountLimit)
    : RuleGenerator(distributionEstimator), amountLimit(amountLimit)
{
}

std::vector<std::unique_ptr<ModificationRule>> BackwardRuleGenerator::generateModificationRules(
    const EventLog *const log, const RuleModel* const model,
    const std::shared_ptr<LogVariable> targetVariable)
{
    Utils::checkNull(log);
    Utils::checkNull(model);
    Utils::checkNull(targetVariable);

    CycleDetector detector;
    std::vector<std::unique_ptr<ModificationRule>> result;

    auto emptyCondition = std::make_unique<Condition>();
    auto updateRules = this->generateUpdateRules(
        log, emptyCondition.get(), targetVariable, this->amountLimit);

    TreeConditionGenerator conditionGenerator;

    for (const auto& [rule, frequency] : updateRules)
    {
        auto conditions = conditionGenerator.generateConditions(log, rule.get());

        for (auto& condition : conditions)
        {
            auto adjacencyList = detector.computeAdjacencyList(model);
            detector.addEdgesToAdjacencyList(adjacencyList, condition->getVariables(), targetVariable);
            if (!detector.hasCycle(adjacencyList))
            {
                result.push_back(std::make_unique<ModificationRule>(std::move(condition),
                    std::unique_ptr<UpdateRule>(rule->clone())));
            }
        }
    }

    return result;
}
