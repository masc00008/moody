#include "serialobjectconverter.hpp"
#include "datamodel/eventlogs/categoricalvariable.hpp"
#include "datamodel/eventlogs/numericalvariable.hpp"
#include "datamodel/eventlogs/logcolumn.hpp"
#include "datamodel/updaterules/valuesetrule.hpp"
#include "datamodel/updaterules/valuerangerule.hpp"
#include "datamodel/updaterules/changerangerule.hpp"
#include "datamodel/updaterules/valuerule.hpp"
#include "datamodel/updaterules/factorrule.hpp"
#include "datamodel/updaterules/differencerule.hpp"
#include "datamodel/conditions/andoperator.hpp"
#include "datamodel/conditions/oroperator.hpp"
#include "datamodel/conditions/notoperator.hpp"
#include "datamodel/conditions/lowerboundcondition.hpp"
#include "datamodel/conditions/upperboundcondition.hpp"
#include "datamodel/conditions/valuecondition.hpp"
#include "datamodel/conditions/transitioncondition.hpp"
#include <stdexcept>
#include <vector>
#include "utils.hpp"

std::pair<std::string, std::unique_ptr<AbstractLogColumn>> SerialObjectConverter::logColumnFromSerial (
    serial::LogColumn::Reader& reader)
{
    const std::string variableName = reader.getVariableName().cStr();
    if (reader.isCategorical())
    {
        auto entriesReader = reader.getCategorical().getEntries();
        std::vector<std::string> entries(entriesReader.size());
        for (size_t i = 0; i < entriesReader.size(); i++)
        {
            entries[i] = entriesReader[i];
        }
        return std::make_pair(variableName, std::make_unique<LogColumn<std::string>>(entries));
    }
    else if (reader.isNumerical())
    {
        auto entriesReader = reader.getNumerical().getEntries();
        std::vector<double_t> entries(entriesReader.size());
        for (size_t i = 0; i < entriesReader.size(); i++)
        {
            entries[i] = entriesReader[i];
        }
        return std::make_pair(variableName, std::make_unique<LogColumn<double_t>>(entries));
    }
    else
    {
        throw std::invalid_argument("Column is neither numerical nor categorical");
    }
}

void SerialObjectConverter::logColumnToSerial (const std::string& variableName,
    const AbstractLogColumn* const column, serial::LogColumn::Builder& builder)
{
    Utils::checkNull(column);

    builder.setVariableName(variableName);
    auto catColumn = dynamic_cast<const LogColumn<std::string>*>(column);
    if (catColumn != nullptr)
    {
        auto cat = builder.initCategorical();
        cat.initEntries(catColumn->size());
        for (size_t i = 0; i < catColumn->size(); i++)
        {
            cat.getEntries().set(i, catColumn->getEntries()[i]);
        }
    }
    auto numColumn = dynamic_cast<const LogColumn<double_t>*>(column);
    if (numColumn != nullptr)
    {
        auto num = builder.initNumerical();
        num.initEntries(numColumn->size());
        for (size_t i = 0; i < numColumn->size(); i++)
        {
            num.getEntries().set(i, numColumn->getEntries()[i]);
        }
    }
}

std::pair<std::string, std::unique_ptr<Trace>> SerialObjectConverter::traceFromSerial (
    serial::Trace::Reader& reader)
{
    std::string caseId = reader.getCaseId();
    Trace::ColumnsType columns;
    for (auto columnReader : reader.getColumns())
    {
        auto columnPair = this->logColumnFromSerial(columnReader);
        columns.insert({this->getVariableFromLookup(columnPair.first), std::move(columnPair.second)});
    }
    return std::make_pair(caseId, std::make_unique<Trace>(columns));
}

void SerialObjectConverter::traceToSerial (const std::string& caseId,
    const Trace* const trace, serial::Trace::Builder& builder)
{
    Utils::checkNull(trace);

    builder.setCaseId(caseId);
    auto columnsBuilder = builder.initColumns(trace->getColumns().size());

    auto it = trace->getColumns().begin();
    for (auto columnBuilder : columnsBuilder)
    {
        this->logColumnToSerial(it->first->getName(), it->second.get(), columnBuilder);
        it++;
    }
}

std::unique_ptr<EventLog> SerialObjectConverter::eventLogFromSerial (
    serial::EventLog::Reader& reader)
{
    this->fillVariableLookup(reader.getVariables());

    EventLog::TracesType traces;
    for (auto traceReader : reader.getTraces())
    {
        traces.insert(this->traceFromSerial(traceReader));
    }
    return std::make_unique<EventLog>(traces);
}

void SerialObjectConverter::eventLogToSerial (
    const EventLog* const log, serial::EventLog::Builder& builder)
{
    Utils::checkNull(log);

    auto entriesBuilder = builder.initTraces(log->getTraces().size());

    auto it = log->getTraces().begin();
    for (auto entryBuilder : entriesBuilder)
    {
        this->traceToSerial(it->first, it->second.get(), entryBuilder);
        it++;
    }

    this->variablesToSerial(builder, log->getVariables());
}

std::unique_ptr<UpdateRule> SerialObjectConverter::updateRuleFromSerial (
    serial::UpdateRule::Reader& reader)
{
    auto variable = this->getVariableFromLookup(reader.getVariable().cStr());
    auto numVariable = std::dynamic_pointer_cast<NumericalVariable>(variable);
    auto catVariable = std::dynamic_pointer_cast<CategoricalVariable>(variable);

    if (reader.isValueSetRule())
    {
        auto setReader = reader.getValueSetRule().getSet();
        std::set<std::string> set;

        for (const auto& element : setReader)
        {
            set.insert(element);
        }

        return std::make_unique<ValueSetRule>(catVariable, set);
    }
    else if (reader.isValueRangeRule())
    {
        auto ruleReader = reader.getValueRangeRule();

        return std::make_unique<ValueRangeRule>(
            numVariable, ruleReader.getMin(), ruleReader.getMax());
    }
    else if (reader.isChangeRangeRule())
    {
        auto ruleReader = reader.getChangeRangeRule();
        
        return std::make_unique<ChangeRangeRule>(
            numVariable, ruleReader.getMin(), ruleReader.getMax());
    }
    else if (reader.isValueRule())
    {
        auto ruleReader = reader.getValueRule();
        
        return std::make_unique<ValueRule>(numVariable, ruleReader.getConstant());
    }
    else if (reader.isFactorRule())
    {
        auto ruleReader = reader.getFactorRule();
        
        return std::make_unique<FactorRule>(numVariable, ruleReader.getConstant());
    }
    else if (reader.isDifferenceRule())
    {
        auto ruleReader = reader.getDifferenceRule();
        
        return std::make_unique<DifferenceRule>(numVariable, ruleReader.getConstant());
    }
    else
    {
        throw std::invalid_argument("Type of update rule not implemented");
    }
}

void SerialObjectConverter::updateRuleToSerial (
    const UpdateRule* const rule, serial::UpdateRule::Builder& builder)
{
    Utils::checkNull(rule);

    builder.setVariable(rule->getVariable()->getName());

    auto valueSetRule = dynamic_cast<const ValueSetRule*>(rule);
    if (valueSetRule != nullptr)
    {
        auto valueSetBuilder = builder.initValueSetRule().initSet(valueSetRule->getSet().size());

        auto it = valueSetRule->getSet().begin();
        for (size_t i = 0; i < valueSetBuilder.size(); i++)
        {
            valueSetBuilder.set(i, *(it++));
        }
        return;
    }

    auto valueRangeRule = dynamic_cast<const ValueRangeRule*>(rule);
    if (valueRangeRule != nullptr)
    {
        auto ruleBuilder = builder.initValueRangeRule();
        ruleBuilder.setMin(valueRangeRule->getMin());
        ruleBuilder.setMax(valueRangeRule->getMax());
        return;
    }

    auto changeRangeRule = dynamic_cast<const ChangeRangeRule*>(rule);
    if (changeRangeRule != nullptr)
    {
        auto ruleBuilder = builder.initChangeRangeRule();
        ruleBuilder.setMin(changeRangeRule->getMin());
        ruleBuilder.setMax(changeRangeRule->getMax());
        return;
    }

    auto valueRule = dynamic_cast<const ValueRule*>(rule);
    if (valueRule != nullptr)
    {
        auto ruleBuilder = builder.initValueRule();
        ruleBuilder.setConstant(valueRule->getConstant());
        return;
    }

    auto factorRule = dynamic_cast<const FactorRule*>(rule);
    if (factorRule != nullptr)
    {
        auto ruleBuilder = builder.initFactorRule();
        ruleBuilder.setConstant(factorRule->getConstant());
        return;
    }

    auto differenceRule = dynamic_cast<const DifferenceRule*>(rule);
    if (differenceRule != nullptr)
    {
        auto ruleBuilder = builder.initDifferenceRule();
        ruleBuilder.setConstant(differenceRule->getConstant());
        return;
    }

    throw std::invalid_argument("Type of update rule not implemented");
}

std::unique_ptr<ConditionElement> SerialObjectConverter::conditionElementFromSerial (
    serial::ConditionElement::Reader& reader)
{
    if (reader.isAndOperator())
    {
        return std::make_unique<AndOperator>();
    }
    else if (reader.isOrOperator())
    {
        return std::make_unique<OrOperator>();
    }
    else if (reader.isNotOperator())
    {
        return std::make_unique<NotOperator>();
    }
    else if (reader.isAtomicCondition())
    {
        auto conditionReader = reader.getAtomicCondition();
        return this->atomicConditionFromSerial(conditionReader);
    }
    else
    {
        throw std::invalid_argument("Condition element is not of an implemented type");
    }
}

void SerialObjectConverter::conditionElementToSerial (
    const ConditionElement* const element, serial::ConditionElement::Builder& builder)
{
    Utils::checkNull(element);

    auto andOperator = dynamic_cast<const AndOperator*>(element);
    if (andOperator != nullptr)
    {
        builder.setAndOperator();
        return;
    }

    auto orOperator = dynamic_cast<const OrOperator*>(element);
    if (orOperator != nullptr)
    {
        builder.setOrOperator();
        return;
    }

    auto notOperator = dynamic_cast<const NotOperator*>(element);
    if (notOperator != nullptr)
    {
        builder.setNotOperator();
        return;
    }

    auto condition = dynamic_cast<const AtomicCondition*>(element);
    if (condition != nullptr)
    {
        auto conditionBuilder = builder.initAtomicCondition();
        this->atomicConditionToSerial(condition, conditionBuilder);
        return;
    }

    throw std::invalid_argument("Condition element is not of an implemented type");
}

std::unique_ptr<AtomicCondition> SerialObjectConverter::atomicConditionFromSerial (
    serial::AtomicCondition::Reader& reader)
{
    auto variable = this->getVariableFromLookup(reader.getVariable().cStr());
    auto numVariable = std::dynamic_pointer_cast<NumericalVariable>(variable);
    auto catVariable = std::dynamic_pointer_cast<CategoricalVariable>(variable);

    if (reader.isLowerBoundCondition())
    {
        auto elementReader = reader.getLowerBoundCondition();
        return std::make_unique<LowerBoundCondition>(numVariable, elementReader.getValue());
    }
    else if (reader.isUpperBoundCondition())
    {
        auto elementReader = reader.getUpperBoundCondition();
        return std::make_unique<UpperBoundCondition>(numVariable, elementReader.getValue());
    }
    else if (reader.isNumericalValueCondition())
    {
        auto elementReader = reader.getNumericalValueCondition();
        return std::make_unique<ValueCondition<double_t>>(numVariable, elementReader.getValue());
    }
    else if (reader.isCategoricalValueCondition())
    {
        auto elementReader = reader.getCategoricalValueCondition();
        return std::make_unique<ValueCondition<std::string>>(catVariable, elementReader.getValue());
    }
    else if (reader.isNumericalTransitionCondition())
    {
        auto elementReader = reader.getNumericalTransitionCondition();
        return std::make_unique<TransitionCondition<double_t>>(
            numVariable, elementReader.getBefore(), elementReader.getAfter());
    }
    else if (reader.isCategoricalTransitionCondition())
    {
        auto elementReader = reader.getCategoricalTransitionCondition();
        return std::make_unique<TransitionCondition<std::string>>(
            catVariable, elementReader.getBefore(), elementReader.getAfter());
    }
    else
    {
        throw std::invalid_argument("Condition is not of an implemented type");
    }
}

void SerialObjectConverter::atomicConditionToSerial (
    const AtomicCondition* const condition, serial::AtomicCondition::Builder& builder)
{
    Utils::checkNull(condition);

    builder.setVariable(condition->getVariable()->getName());

    auto lowerBoundCondition = dynamic_cast<const LowerBoundCondition*>(condition);
    if (lowerBoundCondition != nullptr)
    {
        auto conditionBuilder = builder.initLowerBoundCondition();
        conditionBuilder.setValue(lowerBoundCondition->getValue());
        return;
    }

    auto upperBoundCondition = dynamic_cast<const UpperBoundCondition*>(condition);
    if (upperBoundCondition != nullptr)
    {
        auto conditionBuilder = builder.initUpperBoundCondition();
        conditionBuilder.setValue(upperBoundCondition->getValue());
        return;
    }

    auto numericalValueCondition = dynamic_cast<const ValueCondition<double_t>*>(condition);
    if (numericalValueCondition != nullptr)
    {
        auto conditionBuilder = builder.initNumericalValueCondition();
        conditionBuilder.setValue(numericalValueCondition->getValue());
        return;
    }

    auto categoricalValueCondition = dynamic_cast<const ValueCondition<std::string>*>(condition);
    if (categoricalValueCondition != nullptr)
    {
        auto conditionBuilder = builder.initCategoricalValueCondition();
        conditionBuilder.setValue(categoricalValueCondition->getValue());
        return;
    }

    auto numericalTransitionCondition =
        dynamic_cast<const TransitionCondition<double_t>*>(condition);
    if (numericalTransitionCondition != nullptr)
    {
        auto conditionBuilder = builder.initNumericalTransitionCondition();
        conditionBuilder.setBefore(numericalTransitionCondition->getBefore());
        conditionBuilder.setAfter(numericalTransitionCondition->getAfter());
        return;
    }
    
    auto categoricalTransitionCondition =
        dynamic_cast<const TransitionCondition<std::string>*>(condition);
    if (categoricalTransitionCondition != nullptr)
    {
        auto conditionBuilder = builder.initCategoricalTransitionCondition();
        conditionBuilder.setBefore(categoricalTransitionCondition->getBefore());
        conditionBuilder.setAfter(categoricalTransitionCondition->getAfter());
        return;
    }

    throw std::invalid_argument("Condition is not of an implemented type");
}

std::unique_ptr<Condition> SerialObjectConverter::conditionFromSerial (
    serial::Condition::Reader& reader)
{
    auto elementsReader = reader.getElements();
    Condition::ElementsType elements(elementsReader.size());

    for (size_t i = 0; i < elementsReader.size(); i++)
    {
        auto elementReader = elementsReader[i];
        elements[i] = this->conditionElementFromSerial(elementReader);
    }

    return std::make_unique<Condition>(elements);
}

void SerialObjectConverter::conditionToSerial (
    const Condition* const condition, serial::Condition::Builder& builder)
{
    Utils::checkNull(condition);

    auto elementsBuilder = builder.initElements(condition->getElements().size());
    
    for (size_t i = 0; i < elementsBuilder.size(); i++)
    {
        auto elementBuilder = elementsBuilder[i];
        this->conditionElementToSerial(condition->getElements()[i].get(), elementBuilder);
    }
}

std::unique_ptr<ModificationRule> SerialObjectConverter::modificationRuleFromSerial (
        serial::ModificationRule::Reader& reader)
{
    auto conditionReader = reader.getCondition();
    auto updateRuleReader = reader.getUpdateRule();

    auto condition = this->conditionFromSerial(conditionReader);
    auto updateRule = this->updateRuleFromSerial(updateRuleReader);

    return std::make_unique<ModificationRule>(condition, updateRule);
}

void SerialObjectConverter::modificationRuleToSerial (
        const ModificationRule* const rule, serial::ModificationRule::Builder& builder)
{
    Utils::checkNull(rule);

    auto conditionBuilder = builder.initCondition();
    auto updateRuleBuilder = builder.initUpdateRule();

    this->conditionToSerial(rule->getCondition(), conditionBuilder);
    this->updateRuleToSerial(rule->getUpdateRule(), updateRuleBuilder);
}

std::unique_ptr<RuleModel> SerialObjectConverter::ruleModelFromSerial (
    serial::RuleModel::Reader& reader)
{
    this->fillVariableLookup(reader.getVariables());

    auto rulesReader = reader.getRules();
    RuleModel::RulesType rules(rulesReader.size());

    for (size_t i = 0; i < rulesReader.size(); i++)
    {
        auto ruleReader = rulesReader[i];
        rules[i] = this->modificationRuleFromSerial(ruleReader);
    }

    return std::make_unique<RuleModel>(rules);
}

void SerialObjectConverter::ruleModelToSerial (
    const RuleModel* const model, serial::RuleModel::Builder& builder)
{
    Utils::checkNull(model);

    auto rulesBuilder = builder.initRules(model->getRules().size());

    for (size_t i = 0; i < rulesBuilder.size(); i++)
    {
        auto ruleBuilder = rulesBuilder[i];
        this->modificationRuleToSerial(model->getRules()[i], ruleBuilder);
    }

    auto variables = model->getVariables();
    this->variablesToSerial(builder, std::vector(variables.begin(), variables.end()));
}

std::vector<std::shared_ptr<LogVariable>> SerialObjectConverter::variablesFromSerial(
    capnp::List<serial::LogVariable, capnp::Kind::STRUCT>::Reader &reader)
{
    this->fillVariableLookup(reader);

    std::vector<std::shared_ptr<LogVariable>> result;
    for (auto variableReader : reader)
    {
        result.push_back(this->variableLookup.at(variableReader.getName()));
    }
    return result;
}

std::vector<std::shared_ptr<LogVariable>> SerialObjectConverter::variableReferencesFromSerial(
    capnp::List<capnp::Text, capnp::Kind::BLOB>::Reader &reader)
{
    std::vector<std::shared_ptr<LogVariable>> result;
    for (auto variableReader : reader)
    {
        std::string variableName = variableReader.cStr();
        if (this->variableLookup.find(variableName) == this->variableLookup.end())
        {
            throw std::invalid_argument("Variable name " + variableName +
                " not found in the lookup table. Was it properly initialized " +
                "from an event log or a model?");
        }
        result.push_back(this->variableLookup.at(variableName));
    }
    return result;
}

void SerialObjectConverter::usageStatisticsToSerial(
    const DataGenerator::UsageStatistics &statistics,
    capnp::List<serial::RuleUsageStatistic, capnp::Kind::STRUCT>::Builder &builder)
{
    if (statistics.size() != builder.size())
    {
        throw std::invalid_argument("Sizes of statistics and builder do not match");
    }

    auto it = builder.begin();
    for (const auto& entry : statistics)
    {
        auto ruleBuilder = it->initRule();
        this->modificationRuleToSerial(entry.first, ruleBuilder);
        it->setFrequency(entry.second);
        it++;
    }
}

void SerialObjectConverter::fillVariableLookup (
    capnp::List<serial::LogVariable, capnp::Kind::STRUCT>::Reader reader)
{
    for (auto variableReader : reader)
    {
        const std::string name = variableReader.getName();

        if (this->variableLookup.find(name) != this->variableLookup.end())
        {
            continue;
        }
        else if (variableReader.isCategorical())
        {
            std::set<std::string> domain;
            for (const auto& element : variableReader.getCategorical().getDomain())
            {
                domain.insert(element);
            }
            this->variableLookup[name] = std::make_shared<CategoricalVariable>(name, domain);
        }
        else if (variableReader.isNumerical())
        {
            this->variableLookup[name] = std::make_shared<NumericalVariable>(name);
        }
        else
        {
            throw std::invalid_argument("Variable is neither numerical nor categorical");
        }
    }
}

template<typename T> void SerialObjectConverter::variablesToSerial (
    T builder, const std::vector<std::shared_ptr<LogVariable>>& variables)
{
    auto variablesBuilder = builder.initVariables(variables.size());
    auto it = variables.begin();
    for (auto variableBuilder : variablesBuilder)
    {
        variableBuilder.setName((*it)->getName());

        std::shared_ptr<CategoricalVariable> catVariable =
            std::dynamic_pointer_cast<CategoricalVariable>(*it);
        if (catVariable != nullptr)
        {
            auto cat = variableBuilder.initCategorical();
            auto it = catVariable->getDomain().begin();
            cat.initDomain(catVariable->getDomain().size());

            for (size_t i = 0; i < catVariable->getDomain().size(); i++)
            {
                cat.getDomain().set(i, *(it++));
            }
        }

        std::shared_ptr<NumericalVariable> numVariable =
            std::dynamic_pointer_cast<NumericalVariable>(*it);
        if (numVariable != nullptr)
        {
            variableBuilder.setNumerical();
        }
        it++;
    }
}

std::shared_ptr<LogVariable> SerialObjectConverter::getVariableFromLookup(const std::string& name)
{
    if (this->variableLookup.find(name) == this->variableLookup.end())
    {
        throw std::invalid_argument("Variable name was not found in the lookup table");
    }
    else
    {
        return this->variableLookup.at(name);
    }
}

void SerialObjectConverter::setPredictionsToSerial(
    const DataGenerator::SetPredictions &setPredictions,
    capnp::List<serial::SetPrediction, capnp::Kind::STRUCT>::Builder &builder)
{
    if (setPredictions.size() != builder.size())
    {
        throw std::invalid_argument("Sizes of setPredictions and builder do not match");
    }

    auto mapIt = builder.begin();
    for (const auto& [variable, valueSets] : setPredictions)
    {
        mapIt->setVariable(variable->getName());
        auto outerListBuilder = mapIt->initPredictions(valueSets.size());
        
        size_t i = 0;
        for (const auto& valueSet : valueSets)
        {
            auto innerSetBuilder = outerListBuilder.init(i, valueSet.size());
            size_t j = 0;
            for (const auto& element : valueSet)
            {
                innerSetBuilder.set(j, element);
                j++;
            }
            i++;
        }
        mapIt++;
    }
}

void SerialObjectConverter::eventLogPositionsToSerial(
    const ApplicabilityFinder::EventLogPositions &positions,
    capnp::List<serial::ApplicabilityMapping, capnp::Kind::STRUCT>::Builder &builder)
{
    if (positions.size() != builder.size())
    {
        throw std::invalid_argument("Sizes of positions and builder do not match");
    }

    auto mapIt = builder.begin();
    for (const auto& [variable, twoPartIndices] : positions)
    {
        mapIt->setTargetVariable(variable->getName());
        auto outerListBuilder = mapIt->initPositions(twoPartIndices.size());
        
        auto indexIt = outerListBuilder.begin();
        for (const auto& [caseId, index] : twoPartIndices)
        {
            indexIt->setCaseId(caseId);
            indexIt->setIndex(index);
            indexIt++;
        }
        mapIt++;
    }
}
