#pragma once
#include <utility>
#include <set>
#include <cmath>
#include "datamodel/eventlogs/trace.hpp"

/// @brief Class to bundle utility functions
class Utils
{
    public:
    /// @brief Throws an exception if the given input pointer is null
    /// @tparam T type of the input pointer
    /// @param input input pointer to check
    template<typename T> static void checkNull (const T& input);

    /// @brief Throws an exception if the given input pointer is null
    /// @tparam T type of the input pointer
    /// @param input input pointer to check
    template<typename T> static void checkNull (const T* const input);

    /// @brief Throws an exception if the given input pointer is null
    /// @tparam T type of the key (ignored by this function)
    /// @tparam U type of the input pointer
    /// @param input pair whose second element (pointer) should be checked for null
    template<typename T, typename U> static void checkNull (const std::pair<T, U>& input);

    /// @brief Throws an exception if any of the given input pointers is null
    /// @tparam iterator_type type of the iterator used to go through the container of input pointers
    /// @param it beginning (and later running) iterator of the container
    /// @param end beyond end iterator of the container
    template<class iterator_type> static void checkNull (iterator_type it, const iterator_type end);

    /// @brief Throws an exception if the index is out of range for the trace
    /// @param trace pointer to a trace to get the length from, not null
    /// @param variables the variables in the trace whose columns the index should be used for
    /// @param index index to check
    static void checkIndex(const Trace* const trace,
        const std::set<std::shared_ptr<LogVariable>>& variables, const size_t index);

    /// @brief Obtains a value from a trace at the given variable and index
    /// @tparam T type of the value
    /// @param variable which variable (column) to retrieve the value from, not null
    /// @param trace datasource to obtain values from, not null
    /// @param index index (row) to retrieve value from, in range of trace
    /// @return value from the trace
    template<typename T> static T retrieveValue(
        const std::shared_ptr<LogVariable>& variable, const Trace* const trace, size_t index);

    /// @brief Rounds the given number to the given precision
    /// @param input number to round
    /// @param precision how precise the numer should be, needs to be strictly positive e.g. 0.1
    /// @return rounded number
    static double_t round(const double_t input, const double_t precision);

    /// @brief Checks whether the type of the variable matches the template type
    /// @tparam T template type (double_t or std::string)
    /// @param variable variable to check
    /// @return true if NumericalVariable and double_t, or CategoricalVariable and std::string,
    /// false otherwise
    template<typename T> static bool variableTypeMatches(
        const std::shared_ptr<LogVariable>& variable);

    /// @brief Determines whether a value in the event log is missing
    /// @tparam T data type of the variable (double_t or std::string)
    /// @param input value to check
    /// @return true for a missing value (nan), false otherwise
    template<typename T> static bool isMissingValue (const T& input);

    /// @brief Determines current value is missing
    /// @param variable event log variable to check the value for
    /// @param trace trace where current value occurs
    /// @param index index in the trace where the value occurs
    /// @return true if there is a missing value, false otherwise
    static bool isMissingValue(const std::shared_ptr<LogVariable>& variable,
        const Trace* const trace, const size_t index);

    /// @brief Determines whether any of the pair's values is a missing value in the event log
    /// @tparam T data type of the variable (double_t or std::string)
    /// @param input pair to check
    /// @return true for any missing value (nan), false otherwise
    template<typename T> static bool hasMissingValue (const std::pair<T, T>& input);

    /// @brief Checks whether two floating point values are identical within half
    /// the variable's accuracy
    /// @param value1 first value to compare
    /// @param value2 second value to compare
    /// @param accuracy the smallest meaningful absolute difference between two values
    /// @return value1 == value2 (within half the accuracy)
    static bool equals (const double_t& value1, const double_t& value2,
        const double_t& accuracy);

    /// @brief Checks equality of two strings, convenience method with the same signature as for
    //// the floating point case
    /// @param value1 first value to compare
    /// @param value2 second value to compare
    /// @param accuracy the smallest meaningful absolute difference between two values (ignored)
    /// @return value1 == value2
    static bool equals (const std::string& value1, const std::string& value2,
        const double_t& accuracy);

    template<typename T> static bool equals (const std::pair<T, T>& value1,
        const std::pair<T, T>& value2, const double_t& accuracy);

    /// @brief Checks whether two floating point values are less or equal within half the
    /// variable's accuracy
    /// @param value1 first value to compare
    /// @param value2 second value to compare
    /// @param accuracy the smallest meaningful absolute difference between two values
    /// @return value1 <= value2 (within half the accuracy)
    static bool lessEqual (const double_t& value1, const double_t& value2,
        const double_t& accuracy);

    /// @brief Checks whether a floating point value is within an interval respecting the
    /// variable's accuracy
    /// @param value value to check whether it is in the range
    /// @param min lower bound of the range
    /// @param max upper bound of the range
    /// @param accuracy the smallest meaningful absolute difference between two values
    /// @return min <= value && value <= max (within half the accuracy)
    static bool inRange (const double_t& value, const double_t& min, const double_t& max,
        const double_t& accuracy);
};
