#include "columncollector.hpp"
#include "datamodel/eventlogs/categoricalvariable.hpp"
#include "datamodel/eventlogs/numericalvariable.hpp"
#include "datamodel/eventlogs/logcolumn.hpp"
#include "scoring/conditionmatcher.hpp"
#include "datamodel/updaterules/valuesetrule.hpp"
#include "datamodel/updaterules/valuerule.hpp"
#include "datamodel/updaterules/valuerangerule.hpp"
#include "datamodel/updaterules/changerangerule.hpp"
#include "datamodel/updaterules/factorrule.hpp"
#include "datamodel/updaterules/differencerule.hpp"
#include "utils.hpp"
#include <stdexcept>
#include <algorithm>
#include <float.h>

template<typename T> std::vector<T> ColumnCollector::collectValues(
        const EventLog* const log, const std::shared_ptr<LogVariable> variable)
{
    Utils::checkNull(log);
    Utils::checkNull(variable);

    const auto emptyCondition = std::make_unique<Condition>();
    std::unique_ptr<UpdateRule> updateRule;

    const auto numVariable = std::dynamic_pointer_cast<NumericalVariable>(variable);
    if (numVariable != nullptr)
    {
        updateRule = std::make_unique<ValueRule>(numVariable, 0.0);
    }

    const auto catVariable = std::dynamic_pointer_cast<CategoricalVariable>(variable);
    if (catVariable != nullptr)
    {
        updateRule = std::make_unique<ValueSetRule>(catVariable, catVariable->getDomain());
    }

    return this->collectValuesForModificationRule<T>(log, emptyCondition.get(), updateRule.get());
}

template std::vector<double_t> ColumnCollector::collectValues(
        const EventLog* const log, const std::shared_ptr<LogVariable> variable);
template std::vector<std::string> ColumnCollector::collectValues(
        const EventLog* const log, const std::shared_ptr<LogVariable> variable);

template<typename T> std::vector<T> ColumnCollector::collectValuesForModificationRule(
    const EventLog* const log, const Condition* const condition, const UpdateRule* const updateRule)
{
    Utils::checkNull(log);
    Utils::checkNull(condition);
    Utils::checkNull(updateRule);

    std::vector<T> result;
    ConditionMatcher matcher;

    // only append data to the result if the variable type matches
    if (Utils::variableTypeMatches<T>(updateRule->getVariable()))
    {
        // loop over all columns in all traces
        for (const auto& tracePair : log->getTraces())
        {
            // loop over elements in the trace
            for (size_t i = 0; i < tracePair.second->size(); i++)
            {
                // only add value if the condition matches
                if (matcher.matches(condition, tracePair.second.get(), i))
                {
                    const auto valuePair = this->getValueForModificationRule<T>(
                        tracePair.second.get(), updateRule, i);
                    if (valuePair.first)
                    {
                        result.push_back(valuePair.second);
                    }
                }
            }
        }
    }

    // remove missing/nan values
    result.erase(std::remove_if(result.begin(), result.end(), Utils::isMissingValue<T>),
        result.end());

    return result;
}

template<typename T> std::pair<bool, T> ColumnCollector::getValueForModificationRule(
    const Trace *const trace, const UpdateRule *const updateRule, const size_t index)
{
    throw std::logic_error("Data type to retrieve value for is not implemented");
}

template<> std::pair<bool, double_t> ColumnCollector::getValueForModificationRule(
    const Trace *const trace, const UpdateRule *const updateRule, const size_t index)
{
    const double_t currentValue = Utils::retrieveValue<double_t>(
        updateRule->getVariable(), trace, index);

    auto valueRule = dynamic_cast<const ValueRule*>(updateRule);
    auto valueRangeRule = dynamic_cast<const ValueRangeRule*>(updateRule);
    auto changeRangeRule = dynamic_cast<const ChangeRangeRule*>(updateRule);
    auto factorRule = dynamic_cast<const FactorRule*>(updateRule);
    auto differenceRule = dynamic_cast<const DifferenceRule*>(updateRule);
    
    // add value for value rule or value range rule
    if (valueRule != nullptr || valueRangeRule != nullptr)
    {
        return std::make_pair(true, currentValue);
    }
    // only add change for factor/difference rule if we are not at the first sample
    else if ((factorRule != nullptr || differenceRule != nullptr || changeRangeRule != nullptr)
        && index != 0)
    {
        const double_t previousValue = Utils::retrieveValue<double_t>(
            updateRule->getVariable(), trace, index - 1);
        
        if (factorRule != nullptr)
        {
            if (Utils::equals(currentValue, 0.0, factorRule->getVariable()->getAccuracy()))
            {
                // any previous value times zero is zero
                return std::make_pair(true, 0.0);
            }
            else if (!Utils::equals(previousValue, 0.0, factorRule->getVariable()->getAccuracy()))
            {
                // only calculate factor when previous value is not zero
                return std::make_pair(true, currentValue / previousValue);
            }
        }
        else if (differenceRule != nullptr || changeRangeRule != nullptr)
        {
            return std::make_pair(true, currentValue - previousValue);
        }
    }
    
    return std::make_pair(false, 0.0);
}

template<> std::pair<bool, std::string> ColumnCollector::getValueForModificationRule(
    const Trace *const trace, const UpdateRule *const updateRule, const size_t index)
{
    auto valueSetRule = dynamic_cast<const ValueSetRule*>(updateRule);
    // add value for value set rule
    if (valueSetRule != nullptr)
    {
        std::string value = Utils::retrieveValue<std::string>(
            updateRule->getVariable(), trace, index);
        return std::make_pair(true, value);
    }
    throw std::invalid_argument("No ValueSetRule for retrieving a string value was given");
}

std::vector<double_t> ColumnCollector::collectResiduals(const EventLog* const log,
    const Condition* const condition, const AbstractValueRule* const updateRule)
{
    Utils::checkNull(log);
    Utils::checkNull(condition);
    Utils::checkNull(updateRule);

    std::vector<double_t> result;
    ConditionMatcher matcher;

    // loop over all traces
    for (const auto& tracePair : log->getTraces())
    {
        // loop over elements in the trace
        for (size_t i = 0; i < tracePair.second->size(); i++)
        {
            // only add residual if the condition matches
            if (matcher.matches(condition, tracePair.second.get(), i))
            {
                const double_t currentValue = Utils::retrieveValue<double_t>(
                        updateRule->getVariable(), tracePair.second.get(), i);
                
                auto valueRule = dynamic_cast<const ValueRule*>(updateRule);
                auto factorRule = dynamic_cast<const FactorRule*>(updateRule);
                auto differenceRule = dynamic_cast<const DifferenceRule*>(updateRule);
                
                double_t predicted;
                // add residual for value rule
                if (valueRule != nullptr)
                {
                    predicted = valueRule->getConstant();
                    result.push_back(currentValue - predicted);
                }
                // only add residual for factor/difference rule if we are not at the first sample
                else if ((factorRule != nullptr || differenceRule != nullptr) && i != 0)
                {
                    const double_t previousValue = Utils::retrieveValue<double_t>(
                        updateRule->getVariable(), tracePair.second.get(), i - 1);
                    
                    if (factorRule != nullptr)
                    {
                        predicted = previousValue * factorRule->getConstant();
                    }
                    else if (differenceRule != nullptr)
                    {
                        predicted = previousValue + differenceRule->getConstant();
                    }
                    result.push_back(currentValue - predicted);
                }
            }
        }
    }
    return result;
}

template<typename T> ColumnCollector::MultiColumnsType<T> ColumnCollector::collectAllColumns(
        const EventLog* const log)
{
    Utils::checkNull(log);

    MultiColumnsType<T> result;
    // loop over all columns
    for (const auto& columnPair : log->getTraces().begin()->second->getColumns())
    {
        std::vector<T> entries = this->collectValues<T>(log, columnPair.first);
        // if there are entries for the current variable, add them to the result
        if (entries.size() > 0)
        {
            result[columnPair.first] = entries;
        }
    }
    return result;
}

template ColumnCollector::MultiColumnsType<double_t> ColumnCollector::collectAllColumns<double_t>(
        const EventLog* const log);
template ColumnCollector::MultiColumnsType<std::string> ColumnCollector::collectAllColumns<std::string>(
        const EventLog* const log);

template <typename T> std::vector<std::pair<T, T>> ColumnCollector::collectTransitions(
    const EventLog *const log, const std::shared_ptr<LogVariable> variable)
{
    Utils::checkNull(log);
    Utils::checkNull(variable);

    std::vector<std::pair<T, T>> result;
    // only append data to the result if the variable type matches
    if (Utils::variableTypeMatches<T>(variable))
    {
        // loop over all columns in all traces
        for (const auto& tracePair : log->getTraces())
        {
            for (const auto& columnPair : tracePair.second->getColumns())
            {
                // find variable
                if (columnPair.first == variable)
                {
                    const LogColumn<T>* column = 
                        static_cast<const LogColumn<T>*>(columnPair.second.get());
                    
                    // loop over entries
                    const auto entries = column->getEntries();
                    for (size_t i = 0; i < entries.size() - 1; i++)
                    {
                        // add value transition to result
                        result.push_back(std::make_pair(entries[i], entries[i+1]));
                    }
                }
            }
        }
    }

    // remove NaN values
    result.erase(std::remove_if(result.begin(), result.end(), Utils::hasMissingValue<T>),
        result.end());

    return result;
}

template std::vector<std::pair<double_t, double_t>>
ColumnCollector::collectTransitions<double_t>(
    const EventLog *const log, const std::shared_ptr<LogVariable> variable);
template std::vector<std::pair<std::string, std::string>>
ColumnCollector::collectTransitions<std::string>(
    const EventLog *const log, const std::shared_ptr<LogVariable> variable);

template <typename T>
ColumnCollector::MultiTransitionsType<T> ColumnCollector::collectAllTransitions(
    const EventLog *const log)
{
    Utils::checkNull(log);

    MultiTransitionsType<T> result;
    // loop over all columns
    for (const auto& columnPair : log->getTraces().begin()->second->getColumns())
    {
        std::vector<std::pair<T, T>> entries = this->collectTransitions<T>(log, columnPair.first);
        // if there are transitions for the current variable, add them to the result
        if (entries.size() > 0)
        {
            result[columnPair.first] = entries;
        }
    }
    return result;
}

template ColumnCollector::MultiTransitionsType<double_t> ColumnCollector::collectAllTransitions(
    const EventLog *const log);
template ColumnCollector::MultiTransitionsType<std::string> ColumnCollector::collectAllTransitions(
    const EventLog *const log);
