#include "atomiccondition.hpp"
#include "../../utils.hpp"

AtomicCondition::AtomicCondition(const std::shared_ptr<LogVariable>& variable)
    : variable((Utils::checkNull(variable), variable))
{
}

AtomicCondition::~AtomicCondition()
{
}
