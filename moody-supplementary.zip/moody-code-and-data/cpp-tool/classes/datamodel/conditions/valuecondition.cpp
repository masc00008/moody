#include "valuecondition.hpp"
#include <cmath>
#include <string>

template<typename T> template<typename U> ValueCondition<T>::ValueCondition(
        const std::shared_ptr<NumericalVariable>& variable,
        T value, typename std::enable_if<std::is_same<U, double_t>::value>::type*)
    : AbstractValueCondition<T>(variable, value)
{
}

template<typename T> template<typename U> ValueCondition<T>::ValueCondition(
        const std::shared_ptr<CategoricalVariable>& variable,
        T value, typename std::enable_if<std::is_same<U, std::string>::value>::type*)
    : AbstractValueCondition<T>(variable, value)
{
}

template ValueCondition<double_t>::ValueCondition<double_t>(
        const std::shared_ptr<NumericalVariable>& variable,
        double_t value,
        typename std::enable_if<std::is_same<double_t, double_t>::value>::type*);
template ValueCondition<std::string>::ValueCondition<std::string>(
        const std::shared_ptr<CategoricalVariable>& variable,
        std::string value,
        typename std::enable_if<std::is_same<std::string, std::string>::value>::type*);

template <typename T> std::string ValueCondition<T>::toString() const
{
    std::string valueString;
    if constexpr (std::is_same_v<T, double_t>)
    {
        valueString = std::to_string(this->getValue());
    }
    if constexpr (std::is_same_v<T, std::string>)
    {
        valueString = this->getValue();
    }
    return this->getVariable()->getName() + " = " + valueString;
}
