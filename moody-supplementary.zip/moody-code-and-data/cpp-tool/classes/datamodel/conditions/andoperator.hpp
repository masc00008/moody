#pragma once
#include "conditionelement.hpp"
#include "../clonablemacros.hpp"

/// @brief Represents a logical AND in a condition
class AndOperator : public ConditionElement
{
    public:
    CLONABLE_CHILD(AndOperator)
    virtual std::string toString() const { return "AND"; };
};
