#pragma once
#include "abstractvaluecondition.hpp"
#include <cmath>
#include "../clonablemacros.hpp"

/// @brief Represents a condition that specifies a maximum value for a numerical variable
class UpperBoundCondition : public AbstractValueCondition<double_t>
{
    public:
    UpperBoundCondition(const std::shared_ptr<NumericalVariable>& variable, double_t bound);
    CLONABLE_CHILD(UpperBoundCondition)
    virtual std::string toString() const;
};
