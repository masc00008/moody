#pragma once
#include "atomiccondition.hpp"
#include <cmath>
#include "../eventlogs/numericalvariable.hpp"
#include "../eventlogs/categoricalvariable.hpp"

/// @brief Base class for all atomic conditions containing a single value
/// @tparam T type of the value (number or category)
template<typename T> class AbstractValueCondition : public AtomicCondition
{
    private:
    T value;

    public:
    AbstractValueCondition() = delete;
    template<typename U = T>
    AbstractValueCondition(const std::shared_ptr<NumericalVariable>& variable,
        T value, typename std::enable_if<std::is_same<U, double_t>::value>::type* = nullptr);
    template<typename U = T>
    AbstractValueCondition(const std::shared_ptr<CategoricalVariable>& variable,
        T value, typename std::enable_if<std::is_same<U, std::string>::value>::type* = nullptr);

    T getValue() const { return value; }
    void setValue(const T &value_) { value = value_; }
};
