#pragma once
#include "conditionelement.hpp"
#include "../eventlogs/logvariable.hpp"
#include <memory>

/// @brief Base class for all atomic/elementary conditions specified on some log variable
class AtomicCondition : public ConditionElement
{
    private:
    /// @brief The event log variable that this condition is specified for
    std::shared_ptr<LogVariable> variable;

    public:
    AtomicCondition(const std::shared_ptr<LogVariable>& variable);
    virtual ~AtomicCondition() = 0;

    const std::shared_ptr<LogVariable> getVariable() const { return variable; };
};
