#include "conditionelement.hpp"

ConditionElement::~ConditionElement()
{
}
