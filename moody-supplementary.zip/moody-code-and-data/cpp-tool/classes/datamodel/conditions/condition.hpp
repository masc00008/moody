#pragma once
#include <vector>
#include <memory>
#include <set>
#include "conditionelement.hpp"

/// @brief Represents the condition of a modification rule. Consists of condition elements
/// that specify the condition in postfix notation.
class Condition
{
    public:
    using ElementsType = std::vector<std::unique_ptr<ConditionElement>>;

    private:
    ElementsType elements;

    public:
    Condition();
    /// @brief Creates a new object while transferring the pointer ownership
    /// @param elements the list of condition element pointers, none of which are null
    /// (all will be null after the call)
    Condition(ElementsType& elements);

    const ElementsType& getElements() const;
    /// @brief Updates the list of condition elements while transferring the pointer ownership
    /// @param elements_ the list of condition element pointers, none of which are null
    /// (all will be null after the call)
    void setElements(ElementsType& elements_);

    void addElement(std::unique_ptr<ConditionElement>&& element);

    /// @brief Collects all variables used in this condition
    /// @return set of pointers to variables
    std::set<std::shared_ptr<LogVariable>> getVariables() const;

    Condition* clone() const;
    std::string toString() const;
};
