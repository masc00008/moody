#pragma once
#include "abstractvaluecondition.hpp"
#include <cmath>
#include "../clonablemacros.hpp"

/// @brief Represents a condition that specifies a minimum value for a numerical variable
class LowerBoundCondition : public AbstractValueCondition<double_t>
{
    public:
    LowerBoundCondition(const std::shared_ptr<NumericalVariable>& variable, double_t bound);
    CLONABLE_CHILD(LowerBoundCondition)
    virtual std::string toString() const;
};
