#pragma once
#include "abstractvaluecondition.hpp"
#include "../clonablemacros.hpp"

/// @brief Represents an atomic condition where some log variable can only have a single value
/// @tparam T type of the log variabe / the value
template<typename T> class ValueCondition : public AbstractValueCondition<T>
{
    public:
    ValueCondition() = delete;
    template<typename U = T>
    ValueCondition(const std::shared_ptr<NumericalVariable>& variable,
        T value, typename std::enable_if<std::is_same<U, double_t>::value>::type* = nullptr);
    template<typename U = T>
    ValueCondition(const std::shared_ptr<CategoricalVariable>& variable,
        T value, typename std::enable_if<std::is_same<U, std::string>::value>::type* = nullptr);
    CLONABLE_CHILD(ValueCondition<T>)
    virtual std::string toString() const;
};
