#pragma once
#include "conditionelement.hpp"
#include "../clonablemacros.hpp"

/// @brief Represents a logical NOT in a condition
class NotOperator : public ConditionElement
{
    public:
    CLONABLE_CHILD(NotOperator)
    virtual std::string toString() const { return "NOT"; };
};
