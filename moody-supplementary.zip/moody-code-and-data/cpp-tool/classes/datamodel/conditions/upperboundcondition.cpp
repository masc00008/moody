#include "upperboundcondition.hpp"

UpperBoundCondition::UpperBoundCondition(const std::shared_ptr<NumericalVariable>& variable, double_t bound)
    : AbstractValueCondition<double_t>(variable, bound)
{
}

std::string UpperBoundCondition::toString() const
{
    return this->getVariable()->getName() + " <= " + std::to_string(this->getValue());
}
