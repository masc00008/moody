#include "lowerboundcondition.hpp"

LowerBoundCondition::LowerBoundCondition(const std::shared_ptr<NumericalVariable>& variable, double_t bound)
    : AbstractValueCondition<double_t>(variable, bound)
{
}

std::string LowerBoundCondition::toString() const
{
    return std::to_string(this->getValue()) + " <= " + this->getVariable()->getName();
}
