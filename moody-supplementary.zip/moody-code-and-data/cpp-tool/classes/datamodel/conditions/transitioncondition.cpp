#include "transitioncondition.hpp"
#include <cmath>
#include <string>

template<typename T> template<typename U> TransitionCondition<T>::TransitionCondition(
        const std::shared_ptr<NumericalVariable>& variable,
        T before, T after, typename std::enable_if<std::is_same<U, double_t>::value>::type*)
    : AtomicCondition(variable),
    before(before), after(after)
{
}

template<typename T> template<typename U> TransitionCondition<T>::TransitionCondition(
        const std::shared_ptr<CategoricalVariable>& variable,
        T before, T after, typename std::enable_if<std::is_same<U, std::string>::value>::type*)
    : AtomicCondition(variable),
    before(before), after(after)
{
}

template TransitionCondition<double_t>::TransitionCondition<double_t>(
        const std::shared_ptr<NumericalVariable>& variable,
        double_t before, double_t after,
        typename std::enable_if<std::is_same<double_t, double_t>::value>::type*);
template TransitionCondition<std::string>::TransitionCondition<std::string>(
        const std::shared_ptr<CategoricalVariable>& variable,
        std::string before, std::string after,
        typename std::enable_if<std::is_same<std::string, std::string>::value>::type*);

template <typename T> std::string TransitionCondition<T>::toString() const
{
    std::string beforeString;
    std::string afterString;
    if constexpr (std::is_same_v<T, double_t>)
    {
        beforeString = std::to_string(this->before);
        afterString = std::to_string(this->after);
    }
    if constexpr (std::is_same_v<T, std::string>)
    {
        beforeString = this->before;
        afterString = this->after;
    }
    return this->getVariable()->getName() + ": " + beforeString + " -> " + afterString;
}
