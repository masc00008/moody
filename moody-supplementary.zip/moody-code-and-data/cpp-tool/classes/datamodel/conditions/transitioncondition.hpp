#pragma once
#include "atomiccondition.hpp"
#include <cmath>
#include "../eventlogs/numericalvariable.hpp"
#include "../eventlogs/categoricalvariable.hpp"
#include "../clonablemacros.hpp"

template<typename T> class TransitionCondition : public AtomicCondition
{
    private:
    T before;
    T after;

    public:
    TransitionCondition() = delete;
    template<typename U = T>
    TransitionCondition(const std::shared_ptr<NumericalVariable>& variable,
        T before, T after, typename std::enable_if<std::is_same<U, double_t>::value>::type* = nullptr);
    template<typename U = T>
    TransitionCondition(const std::shared_ptr<CategoricalVariable>& variable,
        T before, T after, typename std::enable_if<std::is_same<U, std::string>::value>::type* = nullptr);

    T getBefore() const { return before; }
    void setBefore(const T &before_) { before = before_; }

    T getAfter() const { return after; }
    void setAfter(const T &after_) { after = after_; }

    CLONABLE_CHILD(TransitionCondition<T>)

    virtual std::string toString() const;
};
