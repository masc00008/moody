#pragma once
#include <memory>
#include "../eventlogs/logvariable.hpp"
#include "../clonablemacros.hpp"

/// @brief Base class for the elements of a condition
class ConditionElement
{
    public:
    virtual ~ConditionElement() = 0;
    virtual const std::shared_ptr<LogVariable> getVariable() const { return nullptr; };
    CLONABLE_PARENT(ConditionElement)
    virtual std::string toString() const = 0;
};
