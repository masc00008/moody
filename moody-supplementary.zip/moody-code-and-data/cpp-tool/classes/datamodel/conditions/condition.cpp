#include "condition.hpp"
#include "../../utils.hpp"
#include <stack>
#include <stdexcept>
#include "atomiccondition.hpp"
#include "notoperator.hpp"

Condition::Condition()
    : elements()
{
}

Condition::Condition(ElementsType& elements)
    : elements((Utils::checkNull(elements.begin(), elements.end()), std::move(elements)))
{
}

const Condition::ElementsType& Condition::getElements() const
{
    return this->elements;
}

void Condition::setElements(ElementsType& elements_)
{
    Utils::checkNull(elements_.begin(), elements_.end());
    this->elements = std::move(elements_);
}

void Condition::addElement(std::unique_ptr<ConditionElement> &&element)
{
    Utils::checkNull(element);
    this->elements.push_back(std::move(element));
}

std::set<std::shared_ptr<LogVariable>> Condition::getVariables() const
{
    std::set<std::shared_ptr<LogVariable>> result;
    for (const auto& element: this->elements)
    {
        auto variable = element->getVariable();
        if (variable != nullptr)
        {
            result.insert(variable);
        }
    }
    return result;
}

Condition *Condition::clone() const
{
    ElementsType elements;
    for (const auto& element : this->elements)
    {
        elements.push_back(std::unique_ptr<ConditionElement>(element->clone()));
    }
    return new Condition(elements);
}

std::string Condition::toString() const
{
    if (this->elements.size() == 0)
    {
        return "TRUE";
    }

    std::stack<std::string> resultStack;

    for (const auto& element : this->elements)
    {
        auto conditionOperand = dynamic_cast<const AtomicCondition*>(element.get());
        auto unaryOperator = dynamic_cast<const NotOperator*>(element.get());
        // convert atomic condition to string
        if (conditionOperand != nullptr)
        {
            resultStack.push(conditionOperand->toString());
        }
        // convert unary operator (NOT) to string
        else if (unaryOperator != nullptr)
        {
            if (resultStack.size() < 1)
            {
                throw std::invalid_argument("Not enough operands for operator");
            }

            const std::string operand = resultStack.top();
            resultStack.pop();

            resultStack.push(element->toString() + " (" + operand + ")");
        }
        // convert binary operator (AND/OR) to string
        else
        {
            if (resultStack.size() < 2)
            {
                throw std::invalid_argument("Not enough operands for operator");
            }

            const std::string operand1 = resultStack.top();
            resultStack.pop();
            const std::string operand2 = resultStack.top();
            resultStack.pop();

            resultStack.push("(" + operand1 + ") " + element->toString() + " (" + operand2 + ")");
        }
    }

    if (resultStack.size() != 1)
    {
        throw std::invalid_argument("Not enough operators for operands");
    }

    return resultStack.top();
}
