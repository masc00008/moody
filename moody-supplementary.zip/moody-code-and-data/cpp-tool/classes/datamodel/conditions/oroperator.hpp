#pragma once
#include "conditionelement.hpp"
#include "../clonablemacros.hpp"

/// @brief Represents a logical OR in a condition
class OrOperator : public ConditionElement
{
    public:
    CLONABLE_CHILD(OrOperator)
    virtual std::string toString() const { return "OR"; };
};
