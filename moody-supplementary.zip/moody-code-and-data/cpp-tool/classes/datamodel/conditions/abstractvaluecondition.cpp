#include "abstractvaluecondition.hpp"
#include <cmath>
#include <string>

template<typename T> template<typename U> AbstractValueCondition<T>::AbstractValueCondition(
        const std::shared_ptr<NumericalVariable>& variable,
        T value, typename std::enable_if<std::is_same<U, double_t>::value>::type*)
    : AtomicCondition(variable),
    value(value)
{
}

template<typename T> template<typename U> AbstractValueCondition<T>::AbstractValueCondition(
        const std::shared_ptr<CategoricalVariable>& variable,
        T value, typename std::enable_if<std::is_same<U, std::string>::value>::type*)
    : AtomicCondition(variable),
    value(value)
{
}

template AbstractValueCondition<double_t>::AbstractValueCondition<double_t>(
        const std::shared_ptr<NumericalVariable>& variable,
        double_t value,
        typename std::enable_if<std::is_same<double_t, double_t>::value>::type*);
template AbstractValueCondition<std::string>::AbstractValueCondition<std::string>(
        const std::shared_ptr<CategoricalVariable>& variable,
        std::string value,
        typename std::enable_if<std::is_same<std::string, std::string>::value>::type*);
