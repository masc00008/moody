#pragma once
#include "modificationrule.hpp"
#include <vector>
#include <memory>
#include <set>

/// @brief Represents the complete model of data modification rules
class RuleModel
{
    public:
    using RulesType = std::vector<std::unique_ptr<ModificationRule>>;

    private:
    /// @brief All contained data modification rules (not a set because hashing the polymorphic
    /// class hierarchy is hard to implement and expensive at runtime)
    RulesType rules;

    public:
    RuleModel();
    /// @brief Creates a new object while transferring the pointer ownership
    /// @param rules the list of modification rule pointers, none of which are null
    /// (all will be null after the call)
    RuleModel(RulesType& rules);

    std::vector<const ModificationRule*> getRules() const;
    /// @brief Updates the list of modification rules while transferring the pointer ownership
    /// @param rules_ the list of modification rule pointers, none of which are null
    /// (all will be null after the call)
    void setRules(RulesType &rules_);

    /// @brief Collects all variables used in the model
    /// @return set of pointers to variables
    std::set<std::shared_ptr<LogVariable>> getVariables() const;

    void addRule(std::unique_ptr<ModificationRule>&& rule);
    void removeLastRule();

    RuleModel* clone() const;
    std::string toString() const;
};
