#pragma once
#include "abstractvaluerule.hpp"
#include "../clonablemacros.hpp"
#include "../classnamemacros.hpp"

/// @brief Represents an update rule specifying that a numerical variable gets a specific value
class ValueRule : public AbstractValueRule
{
    public:
    ValueRule(const std::shared_ptr<NumericalVariable>& variable, double_t value);
    NAME_DERIVED_CLASS
    CLONABLE_CHILD(ValueRule)
    virtual std::string toString() const;
};
