#pragma once
#include "../eventlogs/logvariable.hpp"
#include <memory>
#include "../clonablemacros.hpp"
#include "../classnamemacros.hpp"

/// @brief Base class for all types of update rules that specify how a log variable is changed
/// through the business process. Represents the effect of a modification rule.
class UpdateRule
{
    private:
    /// @brief The event log variable that this update rule is specified for
    std::shared_ptr<LogVariable> variable;

    public:
    UpdateRule(const std::shared_ptr<LogVariable>& variable);
    virtual ~UpdateRule() = 0;

    NAME_BASE_CLASS
    CLONABLE_PARENT(UpdateRule)
    virtual std::string toString() const = 0;

    const std::shared_ptr<LogVariable> getVariable() const;
    // no setter since child classes need a more specific type
};
