#include "differencerule.hpp"

DifferenceRule::DifferenceRule(
        const std::shared_ptr<NumericalVariable>& variable, double_t difference)
    : AbstractValueRule(variable, difference)
{
}

std::string DifferenceRule::toString() const
{
    const std::string varName = this->getVariable()->getName();
    const std::string absConstant = std::to_string(std::abs(this->getConstant()));
    if (this->getConstant() < 0)
    {
        return varName + " = " + varName + "_prev" + " - " + absConstant;
    }
    else
    {
        return varName + " = " + varName + "_prev" + " + " + absConstant;
    }
}
