#include "valuerule.hpp"

ValueRule::ValueRule(const std::shared_ptr<NumericalVariable>& variable, double_t value)
    : AbstractValueRule(variable, value)
{
}

std::string ValueRule::toString() const
{
    return this->getVariable()->getName() + " = " + std::to_string(this->getConstant());
}
