#include "updaterule.hpp"
#include "../../utils.hpp"

UpdateRule::~UpdateRule()
{
}

UpdateRule::UpdateRule(const std::shared_ptr<LogVariable>& variable)
    : variable((Utils::checkNull(variable), variable))
{
}

const std::shared_ptr<LogVariable> UpdateRule::getVariable() const
{
    return this->variable;
}
