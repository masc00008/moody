#pragma once
#include "updaterule.hpp"
#include "../eventlogs/numericalvariable.hpp"
#include <cmath>

/// @brief Base class for update rules that specify an interval/range
class AbstractRangeRule : public UpdateRule
{
    private:
    /// @brief Lower interval bound
    double_t min;
    /// @brief Upper interval bound
    double_t max;

    public:
    AbstractRangeRule(const std::shared_ptr<NumericalVariable>& variable, double_t min, double_t max);
    virtual ~AbstractRangeRule() = 0;

    double_t getMin() const { return min; }
    double_t getMax() const { return max; }
    void setRange(const double_t &min, const double_t &max);
};
