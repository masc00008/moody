#include "valuesetrule.hpp"

ValueSetRule::ValueSetRule(const std::shared_ptr<CategoricalVariable>& variable, const SetType& set)
    : UpdateRule(variable),
      set(set)
{   
}

std::string ValueSetRule::toString() const
{
    std::string result = this->getVariable()->getName() + " IN {";
    for (const auto& item : this->set)
    {
        result += item + ", ";
    }
    return result.substr(0, result.size() - 2) + "}";
}
