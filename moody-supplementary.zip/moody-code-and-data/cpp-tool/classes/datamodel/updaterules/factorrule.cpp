#include "factorrule.hpp"
#include <stdexcept>

void FactorRule::checkFactor(const double_t &factor)
{
    if (std::abs(factor) < std::numeric_limits<double_t>::epsilon())
    {
        throw std::invalid_argument("Factor " + std::to_string(factor) + " cannot be (close to) 0");
    }
}

FactorRule::FactorRule(const std::shared_ptr<NumericalVariable> &variable, double_t factor)
    : AbstractValueRule(variable, (checkFactor(factor), factor))
{
}

std::string FactorRule::toString() const
{
    const std::string varName = this->getVariable()->getName();
    const std::string absConstant = std::to_string(std::abs(this->getConstant()));
    if (this->getConstant() < 0)
    {
        return varName + " = " + varName + "_prev" + " * (-" + absConstant + ")";
    }
    else
    {
        return varName + " = " + varName + "_prev" + " * " + absConstant;
    }
}

void FactorRule::setConstant(const double_t &constant_)
{
    checkFactor(constant_);
    AbstractValueRule::setConstant(constant_);
}
