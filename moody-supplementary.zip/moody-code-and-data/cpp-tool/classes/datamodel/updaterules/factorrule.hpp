#pragma once
#include "abstractvaluerule.hpp"
#include "../clonablemacros.hpp"
#include "../classnamemacros.hpp"

/// @brief Represents an update rule specifying that a numerical variable is changed
/// by multiplying a constant
class FactorRule : public AbstractValueRule
{
    public:
    FactorRule(const std::shared_ptr<NumericalVariable>& variable, double_t factor);
    NAME_DERIVED_CLASS
    CLONABLE_CHILD(FactorRule)
    virtual std::string toString() const;
    /// @brief Sets the factor of this rule if it is valid (not 0)
    /// @param constant_ new factor
    virtual void setConstant(const double_t &constant_);
    /// @brief Checks whether a factor is valid (not 0), throws an exception otherwise
    /// @param factor factor to check
    static void checkFactor(const double_t& factor);
};
