#include "changerangerule.hpp"

ChangeRangeRule::ChangeRangeRule(
        const std::shared_ptr<NumericalVariable>& variable, double_t min, double_t max)
    : AbstractRangeRule(variable, min, max)
{    
}

std::string ChangeRangeRule::toString() const
{
    return "DELTA " + this->getVariable()->getName() + " IN [" + std::to_string(this->getMin())
        + ", " + std::to_string(this->getMax()) + "]";
}
