#include "abstractvaluerule.hpp"

AbstractValueRule::AbstractValueRule(const std::shared_ptr<NumericalVariable>& variable, double_t constant)
    : UpdateRule(variable),
      constant(constant)
{
}

AbstractValueRule::~AbstractValueRule()
{
}
