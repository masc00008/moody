#include "abstractrangerule.hpp"
#include <stdexcept>

AbstractRangeRule::AbstractRangeRule(const std::shared_ptr<NumericalVariable>& variable, double_t min, double_t max)
    : UpdateRule(variable),
      min(min),
      max(max)
{
    if (min >= max)
    {
        throw std::invalid_argument("Invalid range (min >= max)");
    }
}

AbstractRangeRule::~AbstractRangeRule()
{
}

void AbstractRangeRule::setRange(const double_t &min, const double_t &max)
{
    if (min >= max)
    {
        throw std::invalid_argument("Invalid range (min >= max)");
    }
    this->min = min;
    this->max = max;
}
