#pragma once
#include "abstractrangerule.hpp"
#include "../clonablemacros.hpp"
#include "../classnamemacros.hpp"

/// @brief Represents an update rule specifying that a numerical variable's value lies in an interval
class ValueRangeRule : public AbstractRangeRule
{
    public:
    ValueRangeRule(const std::shared_ptr<NumericalVariable>& variable, double_t min, double_t max);
    NAME_DERIVED_CLASS
    CLONABLE_CHILD(ValueRangeRule)
    virtual std::string toString() const;
};
