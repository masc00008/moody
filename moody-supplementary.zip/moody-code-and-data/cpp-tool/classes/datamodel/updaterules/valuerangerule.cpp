#include "valuerangerule.hpp"

ValueRangeRule::ValueRangeRule(
        const std::shared_ptr<NumericalVariable>& variable, double_t min, double_t max)
    : AbstractRangeRule(variable, min, max)
{
}

std::string ValueRangeRule::toString() const
{
    return this->getVariable()->getName() + " IN [" + std::to_string(this->getMin()) + ", "
        + std::to_string(this->getMax()) + "]";
}
