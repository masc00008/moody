#pragma once
#include "updaterule.hpp"
#include "../eventlogs/numericalvariable.hpp"
#include <cmath>

/// @brief Base class for update rules that contain a single numerical constant
class AbstractValueRule : public UpdateRule
{
    private:
    double_t constant;

    public:
    AbstractValueRule(const std::shared_ptr<NumericalVariable>& variable, double_t constant);
    virtual ~AbstractValueRule() = 0;

    double_t getConstant() const { return constant; }
    virtual void setConstant(const double_t &constant_) { constant = constant_; }
};
