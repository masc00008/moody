#pragma once
#include "abstractvaluerule.hpp"
#include "../clonablemacros.hpp"
#include "../classnamemacros.hpp"

/// @brief Represents an update rule specifying that a numerical variable is
/// changed by an additive constant
class DifferenceRule : public AbstractValueRule
{
    public:
    DifferenceRule(const std::shared_ptr<NumericalVariable>& variable, double_t difference);
    NAME_DERIVED_CLASS
    CLONABLE_CHILD(DifferenceRule)
    virtual std::string toString() const;
};
