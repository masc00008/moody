#pragma once
#include "updaterule.hpp"
#include <set>
#include <string>
#include "../eventlogs/categoricalvariable.hpp"
#include "../clonablemacros.hpp"
#include "../classnamemacros.hpp"

/// @brief Represents an update rule for a categorical variable that specifies a set of possible
// values for this variable
class ValueSetRule : public UpdateRule
{
    public:
    using SetType = std::set<std::string>;

    private:
    SetType set;

    public:
    ValueSetRule(const std::shared_ptr<CategoricalVariable>& variable, const SetType& set);

    NAME_DERIVED_CLASS
    CLONABLE_CHILD(ValueSetRule)
    virtual std::string toString() const;

    const SetType& getSet() const { return set; }
    void setSet(const SetType &set_) { set = set_; }
};
