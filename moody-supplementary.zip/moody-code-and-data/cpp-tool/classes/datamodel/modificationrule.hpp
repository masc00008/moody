#pragma once
#include "updaterules/updaterule.hpp"
#include "conditions/condition.hpp"
#include <memory>
#include <set>
#include <cmath>

/// @brief Represents a modification rule that describes how variable values are changed
/// in the process event log
class ModificationRule
{
    private:
    /// @brief Describes the cases in which the update rule can be applied
    std::unique_ptr<Condition> condition;
    /// @brief Describes how the variable is modified in the event log
    std::unique_ptr<UpdateRule> updateRule;
    /// @brief Stores how many samples/events in the log this rule can be applied to
    int64_t samplesCovered = 0;

    public:
    /// @brief Creates a new object while moving the pointer ownership to this new object
    /// @param condition condition of the modification rule
    /// @param updateRule pointer to update rule, not nullptr (will be nullptr after the call)
    ModificationRule(std::unique_ptr<Condition>& condition, std::unique_ptr<UpdateRule>& updateRule);
    ModificationRule(std::unique_ptr<Condition>&& condition, std::unique_ptr<UpdateRule>&& updateRule);

    const UpdateRule* getUpdateRule() const;
    /// @brief Updates the update rule member while moving the pointer ownership
    /// @param updateRule_ pointer to update rule, not nullptr (will be nullptr after the call)
    void setUpdateRule(std::unique_ptr<UpdateRule> &updateRule_);

    const Condition* getCondition() const;
    void setCondition(std::unique_ptr<Condition> &condition_);

    /// @brief Collects all variables used in this modification rule
    /// @return set of pointers to variables
    std::set<std::shared_ptr<LogVariable>> getVariables() const;

    ModificationRule* clone() const;
    std::string toString() const;

    int64_t getSamplesCovered() const { return samplesCovered; }
    void setSamplesCovered(const int64_t &samplesCovered_) { samplesCovered = samplesCovered_; }
};
