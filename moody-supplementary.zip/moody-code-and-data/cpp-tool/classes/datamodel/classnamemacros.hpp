#pragma once
#include <typeinfo>
#include <string>

#define NAME_BASE_CLASS virtual std::string getClassName() const = 0;
#define NAME_DERIVED_CLASS std::string getClassName() const { return typeid(*this).name(); }
