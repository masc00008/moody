#include "modificationrule.hpp"
#include <stdexcept>
#include "../utils.hpp"

ModificationRule::ModificationRule(std::unique_ptr<Condition>& condition,
        std::unique_ptr<UpdateRule>& updateRule)
    : condition((Utils::checkNull(condition), std::move(condition))),
      updateRule((Utils::checkNull(updateRule), std::move(updateRule)))
{
}

ModificationRule::ModificationRule(std::unique_ptr<Condition>&& condition,
        std::unique_ptr<UpdateRule>&& updateRule)
    : condition((Utils::checkNull(condition), std::move(condition))),
      updateRule((Utils::checkNull(updateRule), std::move(updateRule)))
{
}

const UpdateRule* ModificationRule::getUpdateRule() const
{
    return this->updateRule.get();
}

void ModificationRule::setUpdateRule(std::unique_ptr<UpdateRule> &updateRule_)
{
    Utils::checkNull(updateRule_);
    this->updateRule = std::move(updateRule_);
}

const Condition* ModificationRule::getCondition() const
{
    return this->condition.get();
}

void ModificationRule::setCondition(std::unique_ptr<Condition> &condition_)
{
    Utils::checkNull(condition_);
    this->condition = std::move(condition_);
}

std::set<std::shared_ptr<LogVariable>> ModificationRule::getVariables() const
{
    std::set<std::shared_ptr<LogVariable>> result = this->condition->getVariables();
    result.insert(this->updateRule->getVariable());
    return result;
}

ModificationRule *ModificationRule::clone() const
{
    auto condition = std::unique_ptr<Condition>(this->condition->clone());
    auto updateRule = std::unique_ptr<UpdateRule>(this->updateRule->clone());
    return new ModificationRule(condition, updateRule);
}

std::string ModificationRule::toString() const
{
    return "IF " + this->condition->toString() + " THEN " + this->updateRule->toString();
}
