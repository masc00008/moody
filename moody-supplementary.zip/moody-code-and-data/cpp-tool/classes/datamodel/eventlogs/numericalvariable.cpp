#include "numericalvariable.hpp"
#include <stdexcept>

NumericalVariable::NumericalVariable(const std::string& name)
    : LogVariable(name)
{
}

bool NumericalVariable::isAccuracyInitialized() const
{
    return this->accuracy != -1.0;
}

double_t NumericalVariable::getAccuracy() const
{
    if (!this->isAccuracyInitialized())
    {
        throw std::invalid_argument("Accuracy not initialized");
    }
    return this->accuracy;
}

void NumericalVariable::setAccuracy(const double_t &accuracy)
{
    if (accuracy <= 0.0)
    {
        throw std::invalid_argument("Accuracy " + std::to_string(accuracy) +
            " has to be strictly positive");
    }
    this->accuracy = accuracy;
}
