#include "abstractlogcolumn.hpp"

AbstractLogColumn::~AbstractLogColumn()
{
}
