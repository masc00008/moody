#pragma once
#include "logvariable.hpp"
#include <cmath>

/// @brief Represents a numerical variable in the event log
class NumericalVariable : public LogVariable
{
    private:
    /// @brief The smallest meaningful difference of values of this variable,
    /// initially -1.0, otherwise > 0.0
    double_t accuracy = -1.0;

    public:
    NumericalVariable(const std::string& name);

    bool isAccuracyInitialized() const;
    double_t getAccuracy() const;
    void setAccuracy(const double_t &accuracy);
};
