#include "logvariable.hpp"

LogVariable::LogVariable(const std::string& name)
    : name(name)
{
}

LogVariable::~LogVariable()
{
}
