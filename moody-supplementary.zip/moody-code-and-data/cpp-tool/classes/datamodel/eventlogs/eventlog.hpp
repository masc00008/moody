#pragma once
#include "trace.hpp"
#include <map>
#include <memory>
#include <vector>

/// @brief Represent a complete process event log as a collection of its traces
class EventLog
{
    public:
    using TracesType = std::map<std::string, std::unique_ptr<Trace>>;

    private:
    /// @brief Traces with data of each case in the process event log
    TracesType traces;

    public:
    EventLog();
    /// @brief Creates a new object while transferring the pointer ownership
    /// @param traces the list of trace pointers, none of which are null
    /// (all will be null after the call)
    EventLog(TracesType& traces);

    const TracesType& getTraces() const;
    /// @brief Updates the list of traces while transferring the pointer ownership
    /// @param traces_ the list of trace pointers, none of which are null
    /// (all will be null after the call)
    void setTraces(TracesType &traces_);

    std::vector<std::shared_ptr<LogVariable>> getVariables() const;

    /// @brief Determines the number of entries in all traces
    /// @return total number of entries/events
    size_t size() const;
};
