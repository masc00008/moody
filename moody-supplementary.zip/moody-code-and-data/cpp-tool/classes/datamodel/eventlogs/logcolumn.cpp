#include "logcolumn.hpp"

template<typename T> LogColumn<T>::LogColumn()
{
}

template<typename T> LogColumn<T>::LogColumn(const std::vector<T>& entries)
    : entries(entries)
{
}

template<typename T> void LogColumn<T>::appendEntry(const T &entry)
{
    this->entries.push_back(entry);
}

std::string to_string(const std::string &value)
{
    return value;
}

template<typename T> std::string LogColumn<T>::toString() const
{
    using namespace std;
    string result;
    for (const auto& entry : this->entries)
    {
        result += to_string(entry) + ", ";
    }
    return result;
}

template class LogColumn<double_t>;
template class LogColumn<std::string>;
