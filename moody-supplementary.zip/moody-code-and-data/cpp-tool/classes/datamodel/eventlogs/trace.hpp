#pragma once
#include "abstractlogcolumn.hpp"
#include <map>
#include <memory>
#include <vector>

/// @brief Collects the sequence of data for one case in the process event log
class Trace
{
    public:
    using ColumnsType =
        std::map<std::shared_ptr<LogVariable>, std::unique_ptr<AbstractLogColumn>>;

    private:
    /// @brief Columns with data in the trace
    ColumnsType columns;
    /// @brief Throws an exception if the variable-column assignment is invalid in terms of data types
    void checkColumns();

    public:
    Trace();
    /// @brief Creates a new object while transferring the pointer ownership
    /// @param columns the list of log column pointers, none of which are null
    /// (all will be null after the call)
    Trace(ColumnsType& columns);
    Trace(const std::vector<std::shared_ptr<LogVariable>>& variables);

    const ColumnsType& getColumns() const;
    /// @brief Updates the list of log columns while transferring the pointer ownership
    /// @param columns_ the list of log column pointers, none of which are null
    /// (all will be null after the call)
    void setColumns(ColumnsType &columns_);

    /// @brief Determines the number of entries in the trace
    /// @return number of entries
    size_t size() const;
};
