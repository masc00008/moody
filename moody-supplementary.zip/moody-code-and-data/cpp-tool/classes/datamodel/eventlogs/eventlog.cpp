#include "eventlog.hpp"
#include "../../utils.hpp"

EventLog::EventLog()
    : traces()
{
}

EventLog::EventLog(EventLog::TracesType& traces)
    : traces((Utils::checkNull(traces.begin(), traces.end()), std::move(traces)))
{
}

const EventLog::TracesType& EventLog::getTraces() const
{
    return this->traces;
}

void EventLog::setTraces(EventLog::TracesType &traces_)
{
    Utils::checkNull(traces_.begin(), traces_.end());
    this->traces = std::move(traces_);
}

std::vector<std::shared_ptr<LogVariable>> EventLog::getVariables() const
{
    const Trace::ColumnsType& columns = this->traces.begin()->second->getColumns();
    const size_t numberOfVariables = columns.size();
    std::vector<std::shared_ptr<LogVariable>> result(numberOfVariables);
    auto it = columns.begin();
    for (size_t i = 0; i < numberOfVariables; i++)
    {
        result[i] = it->first;
        it++;
    }
    return result;
}

size_t EventLog::size() const
{
    size_t result = 0;
    for (const auto& [caseId, trace] : this->traces)
    {
        result += trace->size();
    }
    return result;
}
