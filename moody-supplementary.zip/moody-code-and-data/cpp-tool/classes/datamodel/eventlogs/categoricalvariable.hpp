#pragma once
#include "logvariable.hpp"
#include <set>

/// @brief Represents a categorical event log variable
class CategoricalVariable : public LogVariable
{
    private:
    /// @brief The possible values that the variable can take
    std::set<std::string> domain;

    public:
    CategoricalVariable(const std::string& name,
        const std::set<std::string> domain);

    const std::set<std::string>& getDomain() const { return domain; }
    void setDomain(const std::set<std::string> &domain_) { domain = domain_; }
};
