#pragma once
#include <string>
#include <cmath>

/// @brief Base class for variables in an event log
class LogVariable
{
    private:
    /// @brief The name of the variable
    std::string name;

    public:
    LogVariable(const std::string& name);
    virtual ~LogVariable() = 0;

    const std::string& getName() const { return name; }
    void setName(const std::string &name_) { name = name_; }
    /// @brief Returns the smallest meaningful absolute difference between two values of
    /// the variable, -1.0 by default
    /// @return the variable's accuracy or -1.0
    virtual double_t getAccuracy() const { return -1.0; }
};
