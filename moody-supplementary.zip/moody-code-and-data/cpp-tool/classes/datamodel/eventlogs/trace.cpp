#include "trace.hpp"
#include "numericalvariable.hpp"
#include "categoricalvariable.hpp"
#include "logcolumn.hpp"
#include "../../utils.hpp"
#include <stdexcept>

Trace::Trace()
    : columns()
{
}

Trace::Trace(Trace::ColumnsType& columns)
    : columns((Utils::checkNull(columns.begin(), columns.end()), std::move(columns)))
{
    checkColumns();
}

Trace::Trace(const std::vector<std::shared_ptr<LogVariable>> &variables)
{
    for (const auto& variable : variables)
    {
        auto catVariable = std::dynamic_pointer_cast<CategoricalVariable>(variable);
        if (catVariable != nullptr)
        {
            this->columns[catVariable] = std::make_unique<LogColumn<std::string>>();
        }

        auto numVariable = std::dynamic_pointer_cast<NumericalVariable>(variable);
        if (numVariable != nullptr)
        {
            this->columns[numVariable] = std::make_unique<LogColumn<double_t>>();
        }
    }
}

void Trace::checkColumns()
{
    size_t length = this->size();
    for (const auto& column : this->columns)
    {
        if (length != column.second->size())
        {
            throw std::invalid_argument("Columns do not have the same size");
        }

        std::shared_ptr<NumericalVariable> numVariable =
            std::dynamic_pointer_cast<NumericalVariable>(column.first);
        const LogColumn<double_t>* numColumn =
            dynamic_cast<const LogColumn<double_t>*>(column.second.get());

        if (numVariable != nullptr)
        {
            if (numColumn != nullptr)
            {
                continue;
            }
            else
            {
                throw std::invalid_argument("Numerical variable has categorical column");
            }
        }

        std::shared_ptr<CategoricalVariable> catVariable =
            std::dynamic_pointer_cast<CategoricalVariable>(column.first);
        const LogColumn<std::string>* catColumn =
            dynamic_cast<const LogColumn<std::string>*>(column.second.get());

        if (catVariable != nullptr)
        {
            if (catColumn == nullptr)
            {
                throw std::invalid_argument("Categorical variable has numerical column");
            }
        }
    }
}

const Trace::ColumnsType& Trace::getColumns() const
{
    return this->columns;
}

void Trace::setColumns(Trace::ColumnsType &columns_)
{
    Utils::checkNull(columns_.begin(), columns_.end());
    this->columns = std::move(columns_);
    this->checkColumns();
}

size_t Trace::size() const
{
    const size_t size = this->columns.begin()->second->size();
    for (const auto& [variable, column] : this->columns)
    {
        if (column->size() != size)
        {
            throw std::logic_error("Columns of the trace have inconsistent size: "
                + this->columns.begin()->first->getName() + " has size "
                + std::to_string(size) + ", "
                + variable->getName() + " has size "
                + std::to_string(column->size()));
        }
    }
    return size;
}
