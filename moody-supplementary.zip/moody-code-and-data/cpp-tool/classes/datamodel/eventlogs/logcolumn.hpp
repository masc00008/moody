#pragma once
#include "abstractlogcolumn.hpp"
#include "logvariable.hpp"
#include "numericalvariable.hpp"
#include "categoricalvariable.hpp"
#include <vector>
#include <cmath>
#include <memory>

/// @brief Represents a column of an event log that contains multiple values for a single variable
/// @tparam T type of the data to save in the column (double_t or std::string)
template<typename T> class LogColumn : public AbstractLogColumn
{
    private:
    /// @brief The data entries contained in the column of the log
    std::vector<T> entries;

    public:
    LogColumn();
    LogColumn(const std::vector<T>& entries);

    virtual size_t size() const { return entries.size(); };
    const std::vector<T>& getEntries() const { return entries; }
    void setEntries(const std::vector<T> &entries_) { entries = entries_; }
    
    /// @brief Appends the given value to the end of the entries
    /// @param entry value to append
    void appendEntry(const T& entry);

    /// @brief Converts the contents of the column into a string
    /// @return string with the entries of the column
    virtual std::string toString() const;
};
