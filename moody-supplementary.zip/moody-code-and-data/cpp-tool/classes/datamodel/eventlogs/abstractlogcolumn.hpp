#pragma once
#include "logvariable.hpp"
#include <memory>

/// @brief Base class for all log columns, regardless of their data type
class AbstractLogColumn
{
    public:
    virtual ~AbstractLogColumn() = 0;

    /// @brief Determines the number of entries in the column
    /// @return number of entries in the column
    virtual size_t size() const = 0;

    /// @brief Converts the contents of the column into a string
    /// @return string with the entries of the column
    virtual std::string toString() const = 0;
};
