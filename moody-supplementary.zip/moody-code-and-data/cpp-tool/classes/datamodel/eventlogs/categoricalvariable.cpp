#include "categoricalvariable.hpp"

CategoricalVariable::CategoricalVariable(const std::string& name,
                         const std::set<std::string> domain)
    : LogVariable(name),
      domain(domain)
{
}

