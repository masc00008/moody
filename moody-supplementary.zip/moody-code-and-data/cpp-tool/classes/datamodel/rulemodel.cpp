#include "rulemodel.hpp"
#include "../utils.hpp"
#include <algorithm>

RuleModel::RuleModel()
    : rules()
{
}

RuleModel::RuleModel(RulesType& rules)
    : rules((Utils::checkNull(rules.begin(), rules.end()), std::move(rules)))
{   
}

std::vector<const ModificationRule*> RuleModel::getRules() const
{
    std::vector<const ModificationRule*> result;
    std::transform(this->rules.begin(), this->rules.end(), std::back_inserter(result),
        [](const std::unique_ptr<ModificationRule>& rule){return rule.get();});
    return result;
}

void RuleModel::setRules(RulesType &rules_)
{
    Utils::checkNull(rules_.begin(), rules_.end());
    this->rules = std::move(rules_);
}

std::set<std::shared_ptr<LogVariable>> RuleModel::getVariables() const
{
    std::set<std::shared_ptr<LogVariable>> result;
    for (const auto& rule : this->rules)
    {
        auto ruleVariables = rule->getVariables();
        result.insert(ruleVariables.begin(), ruleVariables.end());
    }
    return result;
}

void RuleModel::addRule(std::unique_ptr<ModificationRule> &&rule)
{
    Utils::checkNull(rule);
    this->rules.push_back(std::move(rule));
}

void RuleModel::removeLastRule()
{
    this->rules.pop_back();
}

RuleModel *RuleModel::clone() const
{
    RulesType copiedRules;

    for (const auto& rule : this->rules)
    {
        copiedRules.push_back(std::unique_ptr<ModificationRule>(rule->clone()));
    }

    return new RuleModel(copiedRules);
}

std::string RuleModel::toString() const
{
    if (this->rules.size() == 0)
    {
        return "<empty model>";
    }

    std::string result = "";
    for (const auto& rule : this->rules)
    {
        result += rule->toString() + "\n";
    }
    return result;
}
