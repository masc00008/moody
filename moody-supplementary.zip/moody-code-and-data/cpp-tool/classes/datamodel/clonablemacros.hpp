#pragma once

#define CLONABLE_PARENT(CLASS_TYPE) virtual CLASS_TYPE* clone() const = 0;
#define CLONABLE_CHILD(CLASS_TYPE) CLASS_TYPE* clone() const { return new CLASS_TYPE(*this); }
