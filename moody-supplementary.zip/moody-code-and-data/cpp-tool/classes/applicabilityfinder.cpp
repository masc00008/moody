#include "applicabilityfinder.hpp"
#include "utils.hpp"
#include "scoring/rulefinder.hpp"

ApplicabilityFinder::EventLogPositions ApplicabilityFinder::findEventsWithApplicableRules(
    const EventLog *const log, const RuleModel *const model)
{
    Utils::checkNull(log);
    Utils::checkNull(model);

    RuleFinder ruleFinder;
    EventLogPositions result;

    for (const auto& [caseId, trace] : log->getTraces())
    {
        for (size_t i = 0; i < trace->size(); i++)
        {
            for (const auto& variable : log->getVariables())
            {
                if (ruleFinder.findRulesThatApply(model, variable.get(), trace.get(), i).size() > 0)
                {
                    result[variable].insert(std::make_pair(caseId, i));
                }
            }
        }
    }

    return result;
}
