#include "utils.hpp"
#include <stdexcept>
#include "datamodel/conditions/condition.hpp"
#include "datamodel/conditions/atomiccondition.hpp"
#include "datamodel/conditions/transitioncondition.hpp"
#include "datamodel/conditions/abstractvaluecondition.hpp"
#include "datamodel/conditions/conditionelement.hpp"
#include "datamodel/updaterules/updaterule.hpp"
#include "datamodel/updaterules/valuesetrule.hpp"
#include "datamodel/updaterules/abstractrangerule.hpp"
#include "datamodel/updaterules/abstractvaluerule.hpp"
#include "datamodel/rulemodel.hpp"
#include "datamodel/eventlogs/eventlog.hpp"
#include "datamodel/eventlogs/trace.hpp"
#include "scoring/mdlcalculator.hpp"
#include "datamodel/eventlogs/logcolumn.hpp"
#include "datamodel/eventlogs/eventlog.hpp"
#include "preprocessing/nmlhistogramwrapper.hpp"
#include "columncollector.hpp"
#include "scoring/rulefinder.hpp"
#include "scoring/updaterulematcher.hpp"
#include "preprocessing/distributionestimator.hpp"

template<typename T> void Utils::checkNull (const T& input)
{
    if (input == nullptr)
    {
        throw std::invalid_argument("pointer is null");
    }
}

template void Utils::checkNull<std::unique_ptr<HistogramEstimator>>(const std::unique_ptr<HistogramEstimator>& input);
template void Utils::checkNull<std::unique_ptr<ModificationRule>>(const std::unique_ptr<ModificationRule>& input);
template void Utils::checkNull<std::unique_ptr<ConditionElement>>(const std::unique_ptr<ConditionElement>& input);
template void Utils::checkNull<std::unique_ptr<Condition>>(const std::unique_ptr<Condition>& input);
template void Utils::checkNull<std::unique_ptr<UpdateRule>>(const std::unique_ptr<UpdateRule>& input);
template void Utils::checkNull<std::unique_ptr<NmlHistogramWrapper>>(const std::unique_ptr<NmlHistogramWrapper>& input);
template void Utils::checkNull<std::unique_ptr<ColumnCollector>>(const std::unique_ptr<ColumnCollector>& input);
template void Utils::checkNull<std::unique_ptr<RuleFinder>>(const std::unique_ptr<RuleFinder>& input);
template void Utils::checkNull<std::unique_ptr<UpdateRuleMatcher>>(const std::unique_ptr<UpdateRuleMatcher>& input);
template void Utils::checkNull<std::unique_ptr<DistributionEstimator>>(const std::unique_ptr<DistributionEstimator>& input);
template void Utils::checkNull<std::shared_ptr<LogVariable>>(const std::shared_ptr<LogVariable>& input);
template void Utils::checkNull<std::shared_ptr<CategoricalVariable>>(const std::shared_ptr<CategoricalVariable>& input);
template void Utils::checkNull<std::shared_ptr<NumericalVariable>>(const std::shared_ptr<NumericalVariable>& input);
template void Utils::checkNull<std::shared_ptr<MdlCalculator>>(const std::shared_ptr<MdlCalculator>& input);
template void Utils::checkNull<std::shared_ptr<DistributionEstimator>>(const std::shared_ptr<DistributionEstimator>& input);

template<typename T> void Utils::checkNull (const T* const input)
{
    if (input == nullptr)
    {
        throw std::invalid_argument("pointer is null");
    }
}

template void Utils::checkNull<LogVariable>(const LogVariable* const input);
template void Utils::checkNull<RuleModel>(const RuleModel* const input);
template void Utils::checkNull<ModificationRule>(const ModificationRule* const input);
template void Utils::checkNull<UpdateRule>(const UpdateRule* const input);
template void Utils::checkNull<Condition>(const Condition* const input);
template void Utils::checkNull<Trace>(const Trace* const input);
template void Utils::checkNull<AtomicCondition>(const AtomicCondition* const input);
template void Utils::checkNull<TransitionCondition<double_t>>(
    const TransitionCondition<double_t>* const input);
template void Utils::checkNull<TransitionCondition<std::string>>(
    const TransitionCondition<std::string>* const input);
template void Utils::checkNull<AbstractValueCondition<double_t>>(
    const AbstractValueCondition<double_t>* const input);
template void Utils::checkNull<AbstractValueCondition<std::string>>(
    const AbstractValueCondition<std::string>* const input);
template void Utils::checkNull<ValueSetRule>(const ValueSetRule* const input);
template void Utils::checkNull<AbstractRangeRule>(const AbstractRangeRule* const input);
template void Utils::checkNull<EventLog>(const EventLog* const input);
template void Utils::checkNull<AbstractLogColumn>(const AbstractLogColumn* const input);
template void Utils::checkNull<ConditionElement>(const ConditionElement* const input);
template void Utils::checkNull<AbstractValueRule>(const AbstractValueRule* const input);

template<typename T, typename U> void Utils::checkNull (const std::pair<T, U>& input)
{
    Utils::checkNull(input.second);
}

template<class iterator_type> void Utils::checkNull (iterator_type it, const iterator_type end)
{
    while (it != end)
    {
        Utils::checkNull(*(it++));
    }
}

template void Utils::checkNull<RuleModel::RulesType::iterator> (
    RuleModel::RulesType::iterator it, const RuleModel::RulesType::iterator end);
template void Utils::checkNull<Condition::ElementsType::iterator> (
    Condition::ElementsType::iterator it, const Condition::ElementsType::iterator end);
template void Utils::checkNull<EventLog::TracesType::iterator> (
    EventLog::TracesType::iterator it, const EventLog::TracesType::iterator end);
template void Utils::checkNull<Trace::ColumnsType::iterator> (
    Trace::ColumnsType::iterator it, const Trace::ColumnsType::iterator end);

void Utils::checkIndex(const Trace* const trace,
        const std::set<std::shared_ptr<LogVariable>>& variables, const size_t index)
{
    Utils::checkNull(trace);
    for (const auto& variable : variables)
    {
        if (index >= trace->getColumns().at(variable)->size())
        {
            throw std::out_of_range("Index " + std::to_string(index) + " for variable "
                + variable->getName() + " is out of range");
        }
    }
}

template<typename T> T Utils::retrieveValue(
        const std::shared_ptr<LogVariable>& variable, const Trace* const trace, size_t index)
{
    Utils::checkNull(variable);
    Utils::checkNull(trace);
    Utils::checkIndex(trace, std::set<std::shared_ptr<LogVariable>>{variable}, index);

    const LogColumn<T>* column = 
        dynamic_cast<const LogColumn<T>*>(trace->getColumns().at(variable).get());

    if (column == nullptr)
    {
        throw std::invalid_argument("Variable has the wrong type");
    }

    return column->getEntries()[index];
}

template double_t Utils::retrieveValue(
        const std::shared_ptr<LogVariable>& variable, const Trace* const trace, size_t index);
template std::string Utils::retrieveValue(
        const std::shared_ptr<LogVariable>& variable, const Trace* const trace, size_t index);

double_t Utils::round(const double_t input, const double_t precision)
{
    if (precision <= 0.0)
    {
        throw std::invalid_argument("Precision is 0 or negative");
    }
    return std::floor(input * (1.0 / precision) + 0.5) * precision;
}

template <typename T> bool Utils::variableTypeMatches(const std::shared_ptr<LogVariable>& variable)
{
    return (
        std::is_same_v<T, std::string> &&
        std::dynamic_pointer_cast<CategoricalVariable>(variable) != nullptr
    ) || (
        std::is_same_v<T, double_t> &&
        std::dynamic_pointer_cast<NumericalVariable>(variable) != nullptr
    );
}

template bool Utils::variableTypeMatches<double_t>(const std::shared_ptr<LogVariable>& variable);
template bool Utils::variableTypeMatches<std::string>(const std::shared_ptr<LogVariable>& variable);

template <typename T>
bool Utils::isMissingValue(const T &input)
{
    throw std::logic_error("Unsupported type for missing values check");
}

template<> bool Utils::isMissingValue<double_t>(const double_t &input)
{
    return std::isnan(input);
}

template<> bool Utils::isMissingValue<std::string>(const std::string &input)
{
    return input == "nan";
}

bool Utils::isMissingValue(const std::shared_ptr<LogVariable> &variable, const Trace *const trace,
    const size_t index)
{
    const auto numVariable = std::dynamic_pointer_cast<NumericalVariable>(variable);
    if (numVariable != nullptr)
    {
        return Utils::isMissingValue(Utils::retrieveValue<double_t>(variable, trace, index));
    }

    const auto catVariable = std::dynamic_pointer_cast<CategoricalVariable>(variable);
    if (catVariable != nullptr)
    {
        return Utils::isMissingValue(Utils::retrieveValue<std::string>(variable, trace, index));
    }

    throw std::invalid_argument("Neither numerical nor categorical variable given");
}

template <typename T>
bool Utils::hasMissingValue(const std::pair<T, T> &input)
{
    return Utils::isMissingValue(input.first) || Utils::isMissingValue(input.second);
}

template bool Utils::hasMissingValue<double_t>(const std::pair<double_t, double_t> &input);
template bool Utils::hasMissingValue<std::string>(const std::pair<std::string, std::string> &input);

template <typename T>
bool Utils::equals(const std::pair<T, T> &value1, const std::pair<T, T> &value2,
    const double_t& accuracy)
{
    return Utils::equals(value1.first, value1.second, accuracy) &&
        Utils::equals(value1.second, value2.second, accuracy);
}

template bool Utils::equals(const std::pair<double_t, double_t> &value1,
    const std::pair<double_t, double_t> &value2,
    const double_t& accuracy);
template bool Utils::equals(const std::pair<std::string, std::string> &value1,
    const std::pair<std::string, std::string> &value2,
    const double_t& accuracy);

bool Utils::equals(const double_t &value1, const double_t &value2,
    const double_t& accuracy)
{
    if (accuracy < 0.0)
    {
        throw std::invalid_argument("Negative accuracy given");
    }
    // prevent overlapping bins by only using half the accuracy
    return std::abs(value1 - value2) < accuracy / 2;
}

bool Utils::equals(const std::string &value1, const std::string &value2,
    const double_t& /*accuracy*/)
{
    return value1 == value2;
}

bool Utils::lessEqual(const double_t &value1, const double_t &value2,
    const double_t& accuracy)
{
    return value1 < value2 || Utils::equals(value1, value2, accuracy);
}

bool Utils::inRange(const double_t &value, const double_t &min, const double_t &max,
    const double_t& accuracy)
{
    return Utils::lessEqual(min, value, accuracy) && Utils::lessEqual(value, max, accuracy);
}
