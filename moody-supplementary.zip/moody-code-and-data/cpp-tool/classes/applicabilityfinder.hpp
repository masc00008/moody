#pragma once
#include <set>
#include <string>
#include <cmath>
#include "datamodel/eventlogs/eventlog.hpp"
#include "datamodel/rulemodel.hpp"

/// @brief Determines for which events there are applicable rules
class ApplicabilityFinder
{
    public:
    using EventLogPositions = std::map<
        std::shared_ptr<LogVariable>, std::set<std::pair<std::string, int64_t>>>;
    
    /// @brief Finds which events have applicable rules for all possible target variables
    /// @param log event log whose events should be checked
    /// @param model model of data modification rules whose applicability should be checked
    /// @return mapping of target variables to event indices, event indices identify which events
    /// have at least one applicable rule for the given target variable
    EventLogPositions findEventsWithApplicableRules (
        const EventLog* const log, const RuleModel* const model);
};
