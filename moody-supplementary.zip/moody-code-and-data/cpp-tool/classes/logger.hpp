#pragma once
#include <iostream>
#include <chrono>
#include "datamodel/modificationrule.hpp"
#include "preprocessing/histogram.hpp"

using namespace std::chrono;

/// @brief Used to output internals of the method in text form
class Logger
{
    private:
    static constexpr bool LOGGING = true;
    static constexpr bool LOG_STATUS = true;
    static constexpr bool LOG_TIME = true;
    static constexpr bool LOG_SCORE_ESTIMATE = false;
    static constexpr bool LOG_NON_OPTIMISM = false;
    static constexpr bool LOG_HISTOGRAM = false;

    std::ostream& outStream;
    std::chrono::time_point<std::chrono::steady_clock> startTime;

    double_t computeTimeDeltaInSeconds() const;

    public:
    Logger();
    Logger(std::ostream& outStream);

    void startTimer();
    void newVariable(const LogVariable* const variable);
    void modificationRulesGenerated(const int64_t numberOfRules);
    void rulesEstimated();
    void allRulesScored(const int64_t rulesSearched, const double_t bitsSaved,
        const ModificationRule* const bestRule);
    void ruleScored(const double_t bitsActuallySaved, const double_t estimateBitsSaved,
        const ModificationRule* const rule);
    void histogramCreated(const LogVariable* const variable, const Histogram& histogram);
    void allHistogramsCreated();
};
