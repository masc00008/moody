#include "statistics.hpp"
#include <string>
#include <stdexcept>
#include <algorithm>
#include <map>
#include "utils.hpp"

std::vector<double_t> Statistics::getQuantileDivisions(
    std::vector<double_t>& values, const double_t accuracy,
    const size_t numberOfCutpoints)
{
    // sort all values to enable interval division
    std::sort(values.begin(), values.end());
    
    // compute the size and the number of ranges to cover with the cutpoints
    // ranges are the values between cutpoints
    const size_t actualNumberOfCutpoints = std::min(values.size(), numberOfCutpoints);
    const size_t numberOfEqualRanges = actualNumberOfCutpoints + 1;
    const size_t rangeSize = (values.size() - actualNumberOfCutpoints) / numberOfEqualRanges;
    size_t leftoverValues = (values.size() - actualNumberOfCutpoints) % numberOfEqualRanges;

    // compute the cutpoints
    std::vector<double_t> result;
    for (size_t i = rangeSize; i < values.size(); i += rangeSize)
    {
        // increase initial range sizes if there was a remainder
        if (leftoverValues > 0)
        {
            i++;
            leftoverValues--;
        }
        // add cutpoint and skip value
        result.push_back(values[i]);
        i++;
    }

    // eliminate duplicates (within accuracy)
    auto prevIt = result.begin();
    for (auto it = ++result.begin(); prevIt != result.end() && it != result.end();)
    {
        if (*it - *prevIt < accuracy)
        {
            // remove duplicate
            it = result.erase(it);
        }
        else
        {
            // go to next value
            it++;
            prevIt++;
        }
    }

    return result;
}

Statistics::IntervalsType Statistics::getQuantileIntervals(
    std::vector<double_t> &values, const std::shared_ptr<NumericalVariable>& variable,
    const size_t numberOfIntervals)
{
    Utils::checkNull(variable);

    if (values.size() < 2)
    {
        throw std::invalid_argument("At least 2 values required to generate a quantile interval");
    }

    std::sort(values.begin(), values.end());
    IntervalsType result;

    // generate the desired number of ranges using quantiles
    size_t firstIndex = 0;
    size_t lastIndex = values.size() - 1;
    for (size_t i = 0; i < numberOfIntervals; i++)
    {
        // compute the range bounds from indices
        const double_t lowerBound = values.at(firstIndex);
        const double_t upperBound = values.at(lastIndex);

        // break out of the loop that creates tighter and tighter ranges if the range
        // already collapsed to the variable's accuracy
        if (Utils::equals(upperBound, lowerBound, variable->getAccuracy()))
        {
            break;
        }

        // add interval to result with the number of samples that it covers
        auto firstIt = std::lower_bound(values.begin(), values.end(), lowerBound);
        auto lastIt = std::upper_bound(values.begin(), values.end(), upperBound);
        result.push_back(std::make_pair(std::make_pair(lowerBound, upperBound), lastIt - firstIt));

        // tighten the interval by cutting the integer quantile in half
        const size_t size = lastIndex - firstIndex + 1;
        if (size >= 4)
        {
            firstIndex += size / 4;
            lastIndex -= size / 4;
        }
        else
        {
            break;
        }
    }

    return result;
}

template <typename T> Statistics::ValueFrequencies<T>
Statistics::getUniqueValuesSortedByFrequency(
    const std::vector<T> &input, const double_t& accuracy)
{
    auto compareWithinAccuracy = [accuracy](const T& lhs, const T& rhs)
        {
            return lhs < rhs && !Utils::equals(lhs, rhs, accuracy);
        };
    // get unique values
    std::set<T, decltype(compareWithinAccuracy)> uniqueValues(
        input.begin(), input.end(), compareWithinAccuracy);
    // get the unique values' frequencies
    std::map<T, int64_t> frequencies;
    for (const auto& value : uniqueValues)
    {
        frequencies[value] = std::count_if(input.begin(), input.end(),
            [accuracy, value](const auto& otherValue)
            {
                return Utils::equals(value, otherValue, accuracy);
            });
    }
    // sort unique values by frequency
    ValueFrequencies<T> valuesByFrequency(frequencies.begin(), frequencies.end());
    std::sort(valuesByFrequency.begin(), valuesByFrequency.end(),
        [](const std::pair<T, int64_t>& a, const std::pair<T, int64_t>& b){
            return a.second < b.second;
        });
    return valuesByFrequency;
}

template Statistics::ValueFrequencies<double_t> Statistics::getUniqueValuesSortedByFrequency(
    const std::vector<double_t> &input, const double_t& accuracy);
template Statistics::ValueFrequencies<std::string> Statistics::getUniqueValuesSortedByFrequency(
    const std::vector<std::string> &input, const double_t& accuracy);

template <typename T> Statistics::ValueFrequencies<T> Statistics::getMostFrequentValues(
    const std::vector<T> &input, const size_t amountLimit,
    const double_t& accuracy)
{
    // get unique values sorted by frequency
    const ValueFrequencies<T> sortedValues = this->getUniqueValuesSortedByFrequency(input, accuracy);

    // calculate how many elements can be returned
    const size_t correctedAmount =
        amountLimit <= sortedValues.size() ? amountLimit : sortedValues.size();

    // copy most frequent elements to the result in descending order
    ValueFrequencies<T> result(correctedAmount);
    std::reverse_copy(sortedValues.end() - correctedAmount, sortedValues.end(), result.begin());

    return result;
}

template Statistics::ValueFrequencies<std::string> Statistics::getMostFrequentValues(
    const std::vector<std::string> &input, const size_t amountLimit,
    const double_t& accuracy);
template Statistics::ValueFrequencies<double_t> Statistics::getMostFrequentValues(
    const std::vector<double_t> &input, const size_t amountLimit,
    const double_t& accuracy);
template Statistics::ValueFrequencies<std::pair<double_t, double_t>>
Statistics::getMostFrequentValues(
    const std::vector<std::pair<double_t, double_t>> &input, const size_t amountLimit,
    const double_t& accuracy);
template Statistics::ValueFrequencies<std::pair<std::string, std::string>>
Statistics::getMostFrequentValues(
    const std::vector<std::pair<std::string, std::string>> &input, const size_t amountLimit,
    const double_t& accuracy);

template <typename T> std::vector<T> Statistics::getMostFrequentValuesClean(
    const std::vector<T> &input, const size_t amountLimit,
    const double_t& accuracy)
{
    auto mostFrequentWithFrequencies = this->getMostFrequentValues(input, amountLimit, accuracy);
    std::vector<T> result (mostFrequentWithFrequencies.size());
    for (size_t i = 0; i < mostFrequentWithFrequencies.size(); i++)
    {
        result[i] = mostFrequentWithFrequencies[i].first;
    }
    return result;
}

template std::vector<std::string> Statistics::getMostFrequentValuesClean(
    const std::vector<std::string> &input, const size_t amountLimit,
    const double_t& accuracy);
template std::vector<double_t> Statistics::getMostFrequentValuesClean(
    const std::vector<double_t> &input, const size_t amountLimit,
    const double_t& accuracy);
template std::vector<std::pair<double_t, double_t>>
Statistics::getMostFrequentValuesClean(
    const std::vector<std::pair<double_t, double_t>> &input, const size_t amountLimit,
    const double_t& accuracy);
template std::vector<std::pair<std::string, std::string>>
Statistics::getMostFrequentValuesClean(
    const std::vector<std::pair<std::string, std::string>> &input, const size_t amountLimit,
    const double_t& accuracy);
