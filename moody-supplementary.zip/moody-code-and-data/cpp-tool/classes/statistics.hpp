#pragma once
#include <vector>
#include <cmath>
#include <set>
#include <memory>
#include "datamodel/eventlogs/numericalvariable.hpp"

/// @brief Contains functionality to collect statistics from lists of values
class Statistics
{
    public:
    using IntervalsType = std::vector<std::pair<std::pair<double_t, double_t>, int64_t>>;
    template<typename T> using ValueFrequencies = std::vector<std::pair<T, int64_t>>;

    /// @brief Divides the values space into (approximately) equal quantile parts
    /// without interpolation of quantiles
    /// @param values list of values to compute quantiles from
    /// @param accuracy to which resolution the values were recorded
    /// @param numberOfCutpoints how many cutpoints should be generated at maximum
    /// @return list of cutpoints
    std::vector<double_t> getQuantileDivisions (std::vector<double_t>& values,
        const double_t accuracy, const size_t numberOfCutpoints = 50);
    
    /// @brief Computes tighter and tighter quantile-based intervals around the median value
    /// @param values list of values to compute median and quantiles from
    /// @param variable event log variable for which the values occurred
    /// @param numberOfIntervals how many intervals should be generated at maximum
    /// @return list of intervals
    IntervalsType getQuantileIntervals (std::vector<double_t>& values,
        const std::shared_ptr<NumericalVariable>& variable, const size_t numberOfIntervals = 1);

    /// @brief Finds the unique values in a vector and ascendingly sorts them by their frequency
    /// @tparam T type of data in the vector
    /// @param input vector of values to analyze
    /// @param accuracy the smallest meaningful absolute difference between two values
    /// @return pairs of values and frequencies sorted by frequency
    template<typename T> ValueFrequencies<T> getUniqueValuesSortedByFrequency (
        const std::vector<T>& input, const double_t& accuracy);

    /// @brief Finds the most frequent values in a vector that are also descendingly sorted by their
    /// frequency
    /// @tparam T type of data in the vector
    /// @param input vector of values to analyze
    /// @param amountLimit how many (most frequent) values should be collected at maximum
    /// @param accuracy the smallest meaningful absolute difference between two values
    /// @return pairs of most frequent values and frequencies sorted descendingly by frequency
    template<typename T> ValueFrequencies<T> getMostFrequentValues (
        const std::vector<T>& input, const size_t amountLimit,
        const double_t& accuracy);

    /// @brief Finds the most frequent values in a vector that are also descendingly sorted by their
    /// frequency
    /// @tparam T type of data in the vector
    /// @param input vector of values to analyze
    /// @param amountLimit how many (most frequent) values should be collected at maximum
    /// @param accuracy the smallest meaningful absolute difference between two values
    /// @return most frequent values sorted descendingly by frequency
    template<typename T> std::vector<T> getMostFrequentValuesClean (
        const std::vector<T>& input, const size_t amountLimit,
        const double_t& accuracy);
};
