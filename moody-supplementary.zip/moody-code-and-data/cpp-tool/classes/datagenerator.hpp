#pragma once
#include <memory>
#include <cmath>
#include <random>
#include <unordered_map>
#include <unordered_set>
#include "datamodel/eventlogs/eventlog.hpp"
#include "datamodel/rulemodel.hpp"
#include "datamodel/updaterules/valuesetrule.hpp"
#include "preprocessing/distributionestimator.hpp"

/// @brief Generates synthetic data for experiments with randomness
class DataGenerator
{
    public:
    using UsageStatistics = std::unordered_map<const ModificationRule*, int64_t>;
    using EventLogUsageStatistics = std::pair<std::unique_ptr<EventLog>, UsageStatistics>;
    using SetPredictions = std::unordered_map<std::shared_ptr<CategoricalVariable>,
        std::vector<std::set<std::string>>>;
    using SamplingDistributions = std::unordered_map<std::shared_ptr<LogVariable>,
        std::discrete_distribution<int64_t>>;
    using MinValues = std::unordered_map<std::shared_ptr<NumericalVariable>, double_t>;

    private:
    using ReverseRuleGraphType =
        std::unordered_map<
            std::shared_ptr<LogVariable>, std::vector<const ModificationRule*>>;

    /// @brief Used to generate random values
    std::default_random_engine randomEngine;
    /// @brief Lower bound for generating numerical values without any rule
    double_t minNumerical;
    /// @brief Upper bound for generating numerical values without any rule
    double_t maxNumerical;
    /// @brief Maximum accuracy to which numerical values are generated
    double_t globalAccuracy;
    /// @brief Distributions estimated from the training set used to generate values globally
    SamplingDistributions samplingDistributions;
    /// @brief Smallest observed values for each numerical variable
    MinValues minValues;

    /// @brief Initializes the members needed to generate values from estimated distributions
    /// @param distributionEstimator class containing estimated distributions of variables in the
    /// event log
    /// @param variables all variables in the event log
    void initializeSamplingDistributions(
        const std::shared_ptr<DistributionEstimator> distributionEstimator,
        const std::vector<std::shared_ptr<LogVariable>>& variables);

    /// @brief Generates a numerical value using an update rule
    /// @param trace trace to generate the value for
    /// @param index position in the trace to generate the value for
    /// @param rule numerical update rule to generate the value from
    /// @param predictMeans whether to predict numerical values as the middle value of interval
    /// rules instead of a random value in the interval
    /// @return (potentially random) numerical value at desired accuracy
    double_t generateValue(
        const Trace* const trace, const size_t index, const UpdateRule* const rule,
        const bool predictMeans = false);
    /// @brief Generates a numerical value without any rule. Uses its sampling distribution if set.
    /// Otherweise generates values in the configured global range.
    /// @param variable numerical variable to generate the value for
    /// @param predictMeans whether to predict numerical values as the middle value of interval
    /// rules instead of a random value in the interval
    /// @return random numerical value at desired accuracy
    double_t generateValue(const std::shared_ptr<NumericalVariable>& variable,
        const bool predictMeans = false);
    /// @brief Generates a categorical value for a variable. Uses its sampling distribution if set.
    /// Otherwise generates values uniformly.
    /// @param variable categorical variable to generate the value for
    /// @return random categorical value in the domain
    std::string generateValue(const std::shared_ptr<CategoricalVariable>& variable);
    /// @brief Generates a categorical value using the given domain
    /// @param domain all possible and equally likely values that can be generated
    /// @return random categorical value in the domain
    std::string generateValue(const std::set<std::string>& domain);

    /// @brief Computes the rule graph showing which variable depends on which modification rules
    /// (if any)
    /// @param variables all variables to consider (even if not part of the model)
    /// @param model rule model to get modification rules from
    /// @return which variable depends on which modification rules
    ReverseRuleGraphType computeRuleGraph(
        const std::vector<std::shared_ptr<LogVariable>>& variables,
        const RuleModel* const model);

    /// @brief Generates a single event (row) in a trace
    /// @param reverseVariableGraph the variable graph showing which dependent variables can be
    /// generated using which rules
    /// @param trace trace to insert the row into
    /// @param statistics map to collect the number of usages of each modification rule
    void generateSingleEvent(const ReverseRuleGraphType& ruleGraph,
        const Trace* const trace,
        UsageStatistics& statistics);
    /// @brief Finds those variables that could not be set previously due to unset variables in the
    /// conditions of an update rule, but can be set after one additional variable is set
    /// @param reverseVariableGraph the variable graph showing which dependent variables can be
    /// generated using which rules
    /// @param previouslySetVariables the variables that were set previously
    /// @param newlySetVariable the variable that is set in addition to the previously set ones
    /// @return variables that can be set in the next iteration
    std::vector<std::shared_ptr<LogVariable>> findNewlyEnabledVariables(
        const ReverseRuleGraphType& ruleGraph,
        const std::set<std::shared_ptr<LogVariable>>& previouslySetVariables,
        const std::shared_ptr<LogVariable>& newlySetVariable);
    /// @brief Determines which modification rules are currently active to generate a variable's
    /// value in a trace. Rules are active if all their condition variables are set and they apply
    /// to the current values in the trace.
    /// @param reverseVariableGraph the variable graph showing which dependent variables can be
    /// generated using which rules
    /// @param trace trace to generate an event in
    /// @param index position in the trace to generate the value at
    /// @param targetVariable which variable to generate a value for
    /// @param setVariables which variables are already set at the current index
    /// @return active modification rules
    std::vector<const ModificationRule*> findActiveGenerationRules(
        const ReverseRuleGraphType& reverseVariableGraph,
        const Trace* const trace, size_t index,
        const std::shared_ptr<LogVariable> targetVariable,
        const std::set<std::shared_ptr<LogVariable>>& setVariables);
    /// @brief Appends a value to a trace
    /// @tparam T value's and log column's data type
    /// @param trace trace to append the value in
    /// @param variable log variable to append the value for
    /// @param value value to append
    template<typename T> void appendValueToTrace(
        const Trace* const trace, const std::shared_ptr<LogVariable> variable, const T value);

    /// @brief Generates a new value for the target variable and appends it to the target trace
    /// @param ruleGraph reverse graph of modification rules that shows which target variable can be
    /// set by which rules
    /// @param conditionTrace trace used to check which rules are applicable
    /// @param targetTrace trace to generate the new value into
    /// @param index position in the the trace to check applicability and generate new value
    /// @param targetVariable which variable to generate the new value for
    /// @param setVariables which variables in the condition trace were already set at the index
    /// @param statistics map to collect the number of usages of each modification rule
    /// @param predictMeans whether to predict numerical values as the middle value of interval
    /// rules instead of a random value in the interval
    /// @param modelIsOrderedList whether to interpret the model as an ordered list instead of an
    /// unordered set
    /// @param distributionEstimator distributions used to generate values when no rule applies
    /// (optional)
    void generateValueInTrace(const ReverseRuleGraphType& ruleGraph,
        const Trace* const conditionTrace, const Trace* const targetTrace, size_t index,
        const std::shared_ptr<LogVariable> targetVariable,
        const std::set<std::shared_ptr<LogVariable>>& setVariables,
        UsageStatistics& statistics, const bool predictMeans = false,
        const bool modelIsOrderedList = false,
         const std::shared_ptr<DistributionEstimator> distributionEstimator = nullptr);

    /// @brief Generates the set of categorical values that are possible at the current position in
    /// the trace
    /// @param ruleGraph reverse graph of modification rules that shows which target variable can be
    /// set by which rules
    /// @param conditionTrace trace used to check which rules are applicable
    /// @param index position in the the trace to check applicability of rules
    /// @param targetVariable which categorical variable to generate the value set for
    /// @param setVariables which variables in the condition trace were already set at the index
    /// @param modelIsOrderedList whether to interpret the model as an ordered list instead of an
    /// unordered set
    /// @return set of possible categorical values
    std::set<std::string> generateValueSet(const ReverseRuleGraphType& ruleGraph,
        const Trace* const conditionTrace, size_t index,
        const std::shared_ptr<CategoricalVariable> targetVariable,
        const std::set<std::shared_ptr<LogVariable>>& setVariables,
        const bool modelIsOrderedList);

    public:
    /// @brief Creates a new data generator
    /// @param minNumerical Lower bound for generating numerical values without any rule
    /// @param maxNumerical Upper bound for generating numerical values without any rule
    /// @param accuracy Maximum accuracy to which numerical values are generated
    DataGenerator(const double_t minNumerical = 0.0, const double_t maxNumerical = 100.0,
        const double_t accuracy = 0.1);
    /// @brief Creates a new data generator
    /// @param seed seed for the random number generator (for determinism)
    /// @param minNumerical Lower bound for generating numerical values without any rule
    /// @param maxNumerical Upper bound for generating numerical values without any rule
    /// @param accuracy Maximum accuracy to which numerical values are generated
    DataGenerator(const int64_t seed, const double_t minNumerical = 0.0,
        const double_t maxNumerical = 100.0, const double_t accuracy = 0.1);

    /// @brief Sets the seed of the random number generator
    /// @param seed seed for the random number generator (for determinism)
    void seed(const int64_t seed);

    /// @brief Generates an event log from a given model of data modification rules
    /// @param variables the variables that should be present in the event log
    /// (potentially more than those present in the model)
    /// @param model model of data modification rules to use for generation
    /// @param numberOfTraces how many traces should be generated for the event log
    /// @param traceLength how long each trace should be (number of events in the trace)
    /// @return event log and usage statistics specifying how many times each rule in the model was
    /// used to generate the log
    EventLogUsageStatistics generateEventLog(
        const std::vector<std::shared_ptr<LogVariable>>& variables,
        const RuleModel* const model, const int64_t numberOfTraces, const int64_t traceLength);

    /// @brief Generates an event log based on predictions made by the model. The source log is used
    /// to check which modification rules apply when. The resulting log is not intrinsically
    /// consistent as each column is the result of making predictions with the model using all
    /// other columns from the source log.
    /// @param sourceLog event log used to check which rules apply
    /// @param model model of modification rules to make predictions
    /// @param predictMeans whether to predict numerical values as the middle value of interval
    /// rules instead of a random value in the interval
    /// @param modelIsOrderedList whether to interpret the model as an ordered list instead of an
    /// unordered set
    /// @param distributionEstimator distributions used to generate values when no rule applies
    /// (optional)
    /// @return predicted event log
    std::unique_ptr<EventLog> predictEventLog(const EventLog* const sourceLog,
        const RuleModel* const model, const bool predictMeans = false,
        const bool modelIsOrderedList = false,
        const std::shared_ptr<DistributionEstimator> distributionEstimator = nullptr);

    /// @brief Generates predictions of value sets for each categorical variable/column
    /// @param sourceLog event log used to check which rules apply
    /// @param model model of modification rules to make predictions
    /// @param modelIsOrderedList whether to interpret the model as an ordered list instead of an
    /// unordered set
    /// @return predicted value sets for each sample/event and for each variable/column
    SetPredictions predictValueSets(const EventLog* const sourceLog, const RuleModel* const model,
        const bool modelIsOrderedList = false);
};
