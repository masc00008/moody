#pragma once
#include <capnp/message.h>
#include <memory>
#include <unordered_map>
#include "datamodel/eventlogs/logvariable.hpp"
#include "datamodel/eventlogs/abstractlogcolumn.hpp"
#include "datamodel/eventlogs/trace.hpp"
#include "datamodel/eventlogs/eventlog.hpp"
#include "datamodel/updaterules/updaterule.hpp"
#include "datamodel/conditions/conditionelement.hpp"
#include "datamodel/conditions/atomiccondition.hpp"
#include "datamodel/conditions/condition.hpp"
#include "datamodel/modificationrule.hpp"
#include "datamodel/rulemodel.hpp"
#include "../capnproto/interface.capnp.h"
#include "datagenerator.hpp"
#include "applicabilityfinder.hpp"

/// @brief Class to convert between the internal datamodel and the Cap'n Proto serialization.
/// Contains methods to convert in both directions for all classes and keeps track of LogVariables
/// to avoid multiple instances of the same variable in the internal datamodel. Only use one object
/// context i.e. event logs and models referring to the same variables.
class SerialObjectConverter {
    private:
    /// @brief Lookup table used to find LogVariable instances that were already created
    std::unordered_map<std::string, std::shared_ptr<LogVariable>> variableLookup;

    std::pair<std::string, std::unique_ptr<AbstractLogColumn>> logColumnFromSerial (
        serial::LogColumn::Reader& reader);
    void logColumnToSerial (const std::string& variableName,
        const AbstractLogColumn* const column, serial::LogColumn::Builder& builder);

    std::pair<std::string, std::unique_ptr<Trace>> traceFromSerial (serial::Trace::Reader& reader);
    void traceToSerial (
        const std::string& caseId, const Trace* const trace, serial::Trace::Builder& builder);

    std::unique_ptr<UpdateRule> updateRuleFromSerial (serial::UpdateRule::Reader& reader);
    void updateRuleToSerial (const UpdateRule* const rule, serial::UpdateRule::Builder& builder);

    std::unique_ptr<ConditionElement> conditionElementFromSerial (
        serial::ConditionElement::Reader& reader);
    void conditionElementToSerial (
        const ConditionElement* const element, serial::ConditionElement::Builder& builder);

    std::unique_ptr<AtomicCondition> atomicConditionFromSerial (
        serial::AtomicCondition::Reader& reader);
    void atomicConditionToSerial (
        const AtomicCondition* const condition, serial::AtomicCondition::Builder& builder);

    std::unique_ptr<Condition> conditionFromSerial (serial::Condition::Reader& reader);
    void conditionToSerial (const Condition* const condition, serial::Condition::Builder& builder);

    void fillVariableLookup (capnp::List<serial::LogVariable, capnp::Kind::STRUCT>::Reader reader);
    template<typename T> void variablesToSerial (
        T builder, const std::vector<std::shared_ptr<LogVariable>>& variables);
    std::shared_ptr<LogVariable> getVariableFromLookup(const std::string& name);
 
    public:
    std::unique_ptr<EventLog> eventLogFromSerial (serial::EventLog::Reader& reader);
    void eventLogToSerial (const EventLog* const log, serial::EventLog::Builder& builder);

    std::unique_ptr<RuleModel> ruleModelFromSerial (serial::RuleModel::Reader& reader);
    void ruleModelToSerial (const RuleModel* const model, serial::RuleModel::Builder& builder);

    std::vector<std::shared_ptr<LogVariable>> variablesFromSerial (
        capnp::List<serial::LogVariable, capnp::Kind::STRUCT>::Reader& reader);
    std::vector<std::shared_ptr<LogVariable>> variableReferencesFromSerial (
        capnp::List<capnp::Text, capnp::Kind::BLOB>::Reader& reader);
    void usageStatisticsToSerial (const DataGenerator::UsageStatistics& statistics,
        capnp::List<serial::RuleUsageStatistic, capnp::Kind::STRUCT>::Builder& builder);

    std::unique_ptr<ModificationRule> modificationRuleFromSerial (
        serial::ModificationRule::Reader& reader);
    void modificationRuleToSerial (
        const ModificationRule* const rule, serial::ModificationRule::Builder& builder);

    void setPredictionsToSerial (const DataGenerator::SetPredictions& setPredictions,
        capnp::List<serial::SetPrediction, capnp::Kind::STRUCT>::Builder& builder);
    void eventLogPositionsToSerial (const ApplicabilityFinder::EventLogPositions& positions,
        capnp::List<serial::ApplicabilityMapping, capnp::Kind::STRUCT>::Builder& builder);
};
